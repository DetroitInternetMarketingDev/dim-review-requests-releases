<?php
/**
 * Public side: branded review links (/review/{location}/[{token}/]), the
 * Twilio delivery-status webhook, and the [dim_review_page] and
 * [dim_review_sender] shortcodes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Public {

	const QR_JS  = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
	const QR_SRI = 'sha384-3zSEDfvllQohrq0PHL1fOXJuC/jSOO34H46t6UQfobFOmxE5BpjjaIJY5F2/bMnU';

	/**
	 * Subresource Integrity: the browser refuses the CDN file if it was altered.
	 */
	public static function sri( $tag, $handle ) {
		if ( 'dim-rr-qrcode' === $handle && false === strpos( $tag, 'integrity=' ) ) {
			$tag = str_replace( ' src=', ' integrity="' . esc_attr( self::QR_SRI ) . '" crossorigin="anonymous" referrerpolicy="no-referrer" src=', $tag );
		}
		return $tag;
	}

	public static function init() {
		self::add_rewrite();
		if ( get_option( 'dim_rr_flush_rewrite' ) ) {
			delete_option( 'dim_rr_flush_rewrite' );
			flush_rewrite_rules( false );
		}
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_redirect' ), 1 );
		add_shortcode( 'dim_review_page', array( __CLASS__, 'shortcode_page' ) );
		add_shortcode( 'dim_review_sender', array( __CLASS__, 'shortcode_sender' ) );
		add_shortcode( 'dim_sms_terms', array( __CLASS__, 'shortcode_sms_terms' ) );
		add_shortcode( 'dim_sms_privacy', array( __CLASS__, 'shortcode_sms_privacy' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
		add_filter( 'script_loader_tag', array( __CLASS__, 'sri' ), 10, 2 );
		add_filter( 'generate_element_display', array( __CLASS__, 'hide_layout_elements' ), 20, 2 );
	}

	public static function add_rewrite() {
		$slug = DIM_RR_Settings::get( 'branded_slug' );
		$slug = preg_quote( $slug ? $slug : 'review', '/' );
		// /review/{location}/ or /review/{token}/ (told apart at redirect time).
		add_rewrite_rule( '^' . $slug . '/([A-Za-z0-9-]+)/?$', 'index.php?dim_rr_go=1&dim_rr_loc=$matches[1]', 'top' );
		add_rewrite_rule( '^' . $slug . '/?$', 'index.php?dim_rr_go=1', 'top' );
	}

	public static function query_vars( $vars ) {
		return array_merge( $vars, array( 'dim_rr_go', 'dim_rr_loc' ) );
	}

	/**
	 * Redirect a branded link to that location's Google review form.
	 */
	public static function maybe_redirect() {
		if ( ! get_query_var( 'dim_rr_go' ) ) {
			return;
		}
		$slug  = (string) get_query_var( 'dim_rr_loc' );
		$token = '';
		$row   = null;
		if ( $slug && ! isset( DIM_RR_Settings::locations()[ $slug ] ) ) {
			$row = DIM_RR_Log::by_token( $slug );
			if ( $row ) {
				$token = $slug;
				$slug  = $row->location;
			}
		}
		$locs = DIM_RR_Settings::locations();
		if ( $slug && ! isset( $locs[ $slug ] ) ) {
			// Not a location and not a known token: behave like any missing page.
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
			return;
		}
		$loc = DIM_RR_Settings::location( $slug );
		$url = $loc && $loc['review_url'] ? $loc['review_url'] : home_url( '/' );

		$ua      = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : ''; // phpcs:ignore
		$method  = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : 'GET'; // phpcs:ignore
		$is_bot  = (bool) preg_match( '/bot|crawler|spider|facebookexternalhit|preview|slurp|curl|wget|python|scanner|proofpoint|mimecast|barracuda|whatsapp|skype/i', $ua );
		if ( $row && ! $is_bot && 'GET' === $method ) {
			DIM_RR_Log::mark_clicked( $token );
		}
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		wp_redirect( $url, 302, 'DIM Review Requests' ); // phpcs:ignore WordPress.Security.SafeRedirect -- external Google URL by design.
		exit;
	}

	/**
	 * On the staff send page, skip GeneratePress Elements that add site
	 * chrome (custom header, page hero, sidebars, footer). Hook elements
	 * such as analytics keep running.
	 */
	public static function hide_layout_elements( $display, $element_id ) {
		if ( ! $display ) {
			return $display;
		}
		$page = (int) DIM_RR_Settings::get( 'sender_page_id' );
		if ( ! $page || ! is_page( $page ) ) {
			return $display;
		}
		$block = (string) get_post_meta( $element_id, '_generate_block_type', true );
		$type  = (string) get_post_meta( $element_id, '_generate_element_type', true );
		if ( 'header' === $type || in_array( $block, array( 'site-header', 'site-footer', 'page-hero', 'right-sidebar', 'left-sidebar' ), true ) ) {
			return false;
		}
		return $display;
	}

	public static function register_rest() {
		register_rest_route(
			'dim-rr/v1',
			'/status',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'status_callback' ),
				'permission_callback' => '__return_true', // Authenticated by the secret "k" parameter.
			)
		);
	}

	/**
	 * Twilio delivery status webhook.
	 */
	public static function status_callback( WP_REST_Request $req ) {
		$secret = (string) DIM_RR_Settings::get( 'callback_secret' );
		if ( ! $secret || ! hash_equals( $secret, (string) $req->get_param( 'k' ) ) ) {
			return new WP_REST_Response( null, 403 );
		}
		$sid    = sanitize_text_field( (string) $req->get_param( 'MessageSid' ) );
		$status = sanitize_key( (string) $req->get_param( 'MessageStatus' ) );
		$code   = preg_replace( '/\D/', '', (string) $req->get_param( 'ErrorCode' ) );
		if ( ! $sid || ! $status ) {
			return new WP_REST_Response( null, 400 );
		}
		// Defense in depth: the callback must name this site's Twilio account.
		$acct = (string) DIM_RR_Settings::get( 'twilio_account_sid' );
		if ( $acct && ! hash_equals( $acct, (string) $req->get_param( 'AccountSid' ) ) ) {
			return new WP_REST_Response( null, 403 );
		}

		global $wpdb;
		$current = $wpdb->get_var( $wpdb->prepare( 'SELECT status FROM ' . DIM_RR_Log::table() . ' WHERE provider_id = %s', $sid ) );
		$rank    = array( 'accepted' => 1, 'queued' => 1, 'sending' => 2, 'sent' => 3, 'delivered' => 4, 'read' => 5, 'undelivered' => 5, 'failed' => 5 );
		$cur     = isset( $rank[ $current ] ) ? $rank[ $current ] : 0;
		$new     = isset( $rank[ $status ] ) ? $rank[ $status ] : 0;
		if ( null !== $current && $new && $new >= $cur ) { // Callbacks can arrive out of order.
			$data = array( 'status' => $status );
			if ( $code && in_array( $status, array( 'failed', 'undelivered' ), true ) ) {
				$data['error_code']    = $code;
				$data['error_message'] = DIM_RR_Twilio::explain( $code );
				DIM_RR_Alerts::maybe( $code );
			}
			DIM_RR_Log::update_by_provider_id( $sid, $data );
		}
		return new WP_REST_Response( null, 204 );
	}

	public static function register_assets() {
		wp_register_style( 'dim-rr-public', DIM_RR_URL . 'assets/public.css', array(), DIM_RR_VERSION );
		wp_register_script( 'dim-rr-qrcode', self::QR_JS, array(), '1.0.0', true );
		wp_register_script( 'dim-rr-public', DIM_RR_URL . 'assets/public.js', array( 'dim-rr-qrcode' ), DIM_RR_VERSION, true );
	}

	public static function robots( $robots ) {
		if ( is_singular() ) {
			$post = get_post();
			if ( $post && has_shortcode( $post->post_content, 'dim_review_sender' ) ) {
				$robots['noindex']  = true;
				$robots['nofollow'] = true;
			}
		}
		return $robots;
	}

	/**
	 * [dim_review_page location="roseville" qr="yes" map="yes"]
	 * Leave location out to show every location (one card each).
	 */
	public static function shortcode_page( $atts ) {
		$atts = shortcode_atts(
			array(
				'location' => '',
				'qr'       => 'yes',
				'map'      => 'yes',
				'heading'  => DIM_RR_Settings::get( 'page_heading' ),
				'intro'    => DIM_RR_Settings::get( 'page_intro' ),
			),
			$atts,
			'dim_review_page'
		);
		$locs = DIM_RR_Settings::locations();
		if ( $atts['location'] ) {
			$one  = DIM_RR_Settings::location( sanitize_title( $atts['location'] ) );
			$locs = $one ? array( $one['slug'] => $one ) : array();
		}
		$locs = array_filter(
			$locs,
			function ( $l ) {
				return ! empty( $l['review_url'] );
			}
		);
		if ( ! $locs ) {
			return current_user_can( 'manage_options' ) ? '<p><strong>Review page:</strong> add a location with a Google review link in Review Requests &gt; Settings.</p>' : '';
		}

		wp_enqueue_style( 'dim-rr-public' );
		if ( 'yes' === $atts['qr'] ) {
			wp_enqueue_script( 'dim-rr-public' );
		}
		$s     = DIM_RR_Settings::all();
		$st    = DIM_RR_Settings::style();
		$multi = count( $locs ) > 1;

		ob_start();
		echo '<div class="dim-rr-page' . ( $multi ? ' is-multi' : '' ) . '" style="--dim-rr-color:' . esc_attr( $st['brand'] ) . ';--dim-rr-on:' . esc_attr( $st['button_text'] ) . ';--dim-rr-radius:' . esc_attr( $st['radius'] ) . ';--dim-rr-stars:' . esc_attr( $st['stars'] ) . ';--dim-rr-accent:' . esc_attr( $st['accent'] ) . ';">';
		if ( $multi ) {
			if ( $s['logo_url'] ) {
				echo '<img class="dim-rr-logo" src="' . esc_url( $s['logo_url'] ) . '" alt="' . esc_attr( $s['business_name'] ) . '">';
			}
			echo '<h2 class="dim-rr-heading">' . esc_html( DIM_RR_Settings::render( $atts['heading'], array( 'location' => array( 'name' => $s['business_name'] ) ) ) ) . '</h2>';
			echo '<p class="dim-rr-intro">' . esc_html( $atts['intro'] ) . ' Choose the office you worked with:</p>';
		}
		foreach ( $locs as $loc ) {
			$tel = preg_replace( '/[^\d+]/', '', $loc['phone'] );
			?>
			<section class="dim-rr-card">
				<?php if ( ! $multi ) : ?>
					<?php if ( $s['logo_url'] ) : ?>
						<img class="dim-rr-logo" src="<?php echo esc_url( $s['logo_url'] ); ?>" alt="<?php echo esc_attr( $loc['name'] ); ?>">
					<?php endif; ?>
					<h2 class="dim-rr-heading"><?php echo esc_html( DIM_RR_Settings::render( $atts['heading'], array( 'location' => $loc ) ) ); ?></h2>
					<p class="dim-rr-intro"><?php echo esc_html( $atts['intro'] ); ?></p>
				<?php else : ?>
					<h3 class="dim-rr-loc-name"><?php echo esc_html( $loc['name'] ); ?></h3>
				<?php endif; ?>

				<a class="dim-rr-stars" href="<?php echo esc_url( $loc['review_url'] ); ?>" target="_blank" rel="noopener" aria-label="Rate <?php echo esc_attr( $loc['name'] ); ?> on Google">&#9733;&#9733;&#9733;&#9733;&#9733;</a>
				<a class="dim-rr-button" href="<?php echo esc_url( $loc['review_url'] ); ?>" target="_blank" rel="noopener">Leave a Google review</a>

				<div class="dim-rr-grid<?php echo ( 'yes' === $atts['map'] && $loc['map_embed_url'] ) ? ' has-map' : ''; ?>">
					<?php if ( 'yes' === $atts['map'] && $loc['map_embed_url'] ) : ?>
						<div class="dim-rr-map"><iframe src="<?php echo esc_url( $loc['map_embed_url'] ); ?>" title="<?php echo esc_attr( $loc['name'] . ' on Google Maps' ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe></div>
					<?php endif; ?>
					<div class="dim-rr-info">
						<?php if ( $loc['address'] ) : ?>
							<p class="dim-rr-address"><?php echo nl2br( esc_html( $loc['address'] ) ); ?></p>
						<?php endif; ?>
						<?php if ( $loc['phone'] ) : ?>
							<p><a class="dim-rr-phone" href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo esc_html( $loc['phone'] ); ?></a></p>
						<?php endif; ?>
						<?php if ( 'yes' === $atts['qr'] ) : ?>
							<div class="dim-rr-qr" data-dim-rr-qr="<?php echo esc_url( DIM_RR_Settings::review_link( $loc ) ); ?>" data-size="150" role="img" aria-label="QR code for the <?php echo esc_attr( $loc['name'] ); ?> Google review form"></div>
							<p class="dim-rr-qr-caption">Scan with your phone camera</p>
						<?php endif; ?>
						<?php if ( $loc['feedback_url'] ) : ?>
							<p class="dim-rr-feedback"><?php echo esc_html( DIM_RR_Settings::render( $s['email_feedback'], array( 'location' => $loc ) ) ); ?></p>
							<p><a class="dim-rr-button dim-rr-button-secondary" href="<?php echo esc_url( $loc['feedback_url'] ); ?>"><?php echo esc_html( $s['contact_button'] ? $s['contact_button'] : 'Contact us' ); ?></a></p>
						<?php endif; ?>
					</div>
				</div>
			</section>
			<?php
		}
		$foot = array();
		if ( ! empty( $s['show_socials'] ) ) {
			foreach ( DIM_RR_Settings::SOCIALS as $k => $label ) {
				if ( ! empty( $s['socials'][ $k ] ) ) {
					$foot[] = '<a href="' . esc_url( $s['socials'][ $k ] ) . '" target="_blank" rel="noopener">' . esc_html( $label ) . '</a>';
				}
			}
		}
		if ( $s['privacy_url'] ) {
			$foot[] = '<a href="' . esc_url( $s['privacy_url'] ) . '">Privacy policy</a>';
		}
		if ( $foot ) {
			echo '<p class="dim-rr-foot">' . implode( ' &middot; ', $foot ) . '</p>'; // phpcs:ignore
		}
		echo '</div>';
		return (string) ob_get_clean();
	}

	/**
	 * [dim_sms_terms] SMS program terms page (needed for A2P 10DLC registration).
	 */
	public static function shortcode_sms_terms() {
		$s     = DIM_RR_Settings::all();
		$biz   = esc_html( $s['business_name'] );
		$who   = esc_html( DIM_RR_Settings::audience_word( true ) );
		$phone = $s['business_phone'];
		if ( ! $phone ) {
			$first = DIM_RR_Settings::location();
			$phone = $first ? $first['phone'] : '';
		}
		$contact = array();
		if ( $phone ) {
			$contact[] = 'calling ' . esc_html( $phone );
		}
		if ( $s['business_email'] ) {
			$contact[] = 'emailing <a href="mailto:' . esc_attr( $s['business_email'] ) . '">' . esc_html( $s['business_email'] ) . '</a>';
		}
		$contact = $contact ? implode( ' or ', $contact ) : 'contacting our office';
		ob_start();
		?>
		<div class="dim-rr-terms">
			<h2><?php echo $biz; // phpcs:ignore ?> SMS Terms</h2>
			<p><strong>Program description.</strong> After we complete a service or appointment, <?php echo $biz; // phpcs:ignore ?> may send <?php echo $who; // phpcs:ignore ?> who agree to receive texts a one-time text message asking for feedback or an online review. Messages are not marketing and are not sent on a recurring schedule.</p>
			<p><strong>How you opt in.</strong> You agree to receive this text when you give us your mobile number and consent in person, by phone, or on a form, for the purpose of receiving service updates and a feedback request.</p>
			<p><strong>Message frequency.</strong> Usually one message per service or visit.</p>
			<p><strong>Cost.</strong> Message and data rates may apply. Check with your mobile carrier.</p>
			<p><strong>Opt out.</strong> Reply <strong>STOP</strong> to any message to stop receiving texts from us. You will receive one final confirmation message. Reply <strong>START</strong> to opt back in.</p>
			<p><strong>Help.</strong> Reply <strong>HELP</strong> for help, or reach us by <?php echo $contact; // phpcs:ignore ?>.</p>
			<p><strong>Carriers.</strong> Mobile carriers are not liable for delayed or undelivered messages.</p>
			<p><strong>Privacy.</strong> We do not sell, rent or share your mobile number or text messaging consent with third parties or affiliates for their marketing purposes.<?php if ( $s['privacy_url'] ) : ?> See our <a href="<?php echo esc_url( $s['privacy_url'] ); ?>">Privacy Policy</a>.<?php endif; ?></p>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * [dim_sms_privacy] Wording carriers look for in the privacy policy.
	 */
	public static function shortcode_sms_privacy() {
		$biz = esc_html( DIM_RR_Settings::get( 'business_name' ) );
		return '<div class="dim-rr-terms"><h3>Text messaging</h3><p>If you give ' . $biz . ' your mobile number, we use it only to contact you about your service, appointment or feedback. No mobile information will be shared with third parties or affiliates for marketing or promotional purposes. Text messaging originator opt-in data and consent will not be shared with any third parties. Reply STOP to any message to opt out.</p></div>';
	}

	/**
	 * [dim_review_sender] Front-end sender for a phone or tablet.
	 */
	public static function shortcode_sender() {
		if ( ! is_user_logged_in() ) {
			wp_enqueue_style( 'dim-rr-admin', DIM_RR_URL . 'assets/admin.css', array(), DIM_RR_VERSION );
			$s = DIM_RR_Settings::all();
			$f = wp_login_form(
				array(
					'echo'           => false,
					'redirect'       => get_permalink(),
					'remember'       => true,
					'value_remember' => true,
					'label_username' => 'Username or email',
					'label_log_in'   => 'Sign in',
				)
			);
			return '<div class="dimrr-app is-frontend" style="--dimrr-brand:' . esc_attr( $s['brand_color'] ) . ';"><div class="dimrr-card dimrr-login">'
				. ( $s['logo_url'] ? '<img class="dimrr-login-logo" src="' . esc_url( $s['logo_url'] ) . '" alt="">' : '' )
				. '<h2 class="dimrr-h2">Staff sign-in</h2><p class="dimrr-help">Sign in to send Google review requests.</p>' . $f . '</div></div>';
		}
		if ( ! current_user_can( DIM_RR_CAP ) ) {
			return '<p>Your account does not have permission to send review requests.</p>';
		}
		$user = wp_get_current_user();
		$bar  = '<div class="dimrr-userbar">Signed in as <strong>' . esc_html( $user->display_name ) . '</strong> &middot; <a href="' . esc_url( wp_logout_url( get_permalink() ) ) . '">Sign out</a></div>';
		return $bar . DIM_RR_Admin::sender_app( true );
	}
}
