<?php
/**
 * Review request email.
 * Table layout that holds up in Gmail, Outlook (incl. desktop Word engine) and
 * Apple Mail; PNG/JPG logo (SVG does not show in Gmail/Outlook); clickable
 * star row (every star goes to the same Google form, so no review gating);
 * bulletproof button with Outlook VML; plain-text alternative.
 * All colours, fonts, logo and wording come from Settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Email {

	private static $alt_body   = '';
	private static $last_error = '';

	private static function brand_name( $loc ) {
		$s = DIM_RR_Settings::all();
		return $s['business_name'] ? $s['business_name'] : $loc['name'];
	}

	public static function send( $to, $first_name, $loc, $token = '' ) {
		$s    = DIM_RR_Settings::all();
		$vars = array(
			'first_name' => $first_name,
			'link'       => DIM_RR_Settings::review_link( $loc, $token ),
			'location'   => $loc,
		);

		$subject  = DIM_RR_Settings::render( $s['email_subject'], $vars );
		$headers  = array( 'Content-Type: text/html; charset=UTF-8' );
		if ( $s['from_email'] ) {
			$headers[] = sprintf( 'From: %s <%s>', self::header_safe( $s['from_name'] ? $s['from_name'] : self::brand_name( $loc ) ), $s['from_email'] );
		}
		$reply = ! empty( $loc['reply_to'] ) ? $loc['reply_to'] : ( $s['reply_to'] ? $s['reply_to'] : $s['business_email'] );
		if ( $reply ) {
			$headers[] = 'Reply-To: ' . $reply;
		}

		self::$alt_body   = self::text( $vars );
		self::$last_error = '';
		add_action( 'phpmailer_init', array( __CLASS__, 'add_alt_body' ) );
		add_action( 'wp_mail_failed', array( __CLASS__, 'capture_error' ) );
		$ok = wp_mail( $to, $subject, self::html( $vars ), $headers );
		remove_action( 'phpmailer_init', array( __CLASS__, 'add_alt_body' ) );
		remove_action( 'wp_mail_failed', array( __CLASS__, 'capture_error' ) );
		self::$alt_body = '';

		return array(
			'ok'    => (bool) $ok,
			'error' => $ok ? '' : ( self::$last_error ? self::$last_error : 'WordPress could not send the email. Check WP Mail SMTP (see Diagnostics).' ),
		);
	}

	public static function add_alt_body( $phpmailer ) {
		if ( self::$alt_body ) {
			$phpmailer->AltBody = self::$alt_body; // phpcs:ignore WordPress.NamingConventions.ValidVariableName
		}
	}

	public static function capture_error( $wp_error ) {
		if ( is_wp_error( $wp_error ) ) {
			self::$last_error = $wp_error->get_error_message();
		}
	}

	private static function header_safe( $str ) {
		return trim( str_replace( array( "\r", "\n", '<', '>', '"' ), '', (string) $str ) );
	}

	private static function socials() {
		$s = DIM_RR_Settings::all();
		if ( empty( $s['show_socials'] ) ) {
			return array();
		}
		$out = array();
		foreach ( DIM_RR_Settings::SOCIALS as $k => $label ) {
			if ( ! empty( $s['socials'][ $k ] ) ) {
				$out[ $label ] = $s['socials'][ $k ];
			}
		}
		return $out;
	}

	public static function text( $vars ) {
		$s   = DIM_RR_Settings::all();
		$loc = $vars['location'];
		$l   = array(
			DIM_RR_Settings::render( $s['email_heading'], $vars ),
			'',
			DIM_RR_Settings::render( $s['email_body'], $vars ),
			'',
			DIM_RR_Settings::render( $s['email_button'], $vars ) . ': ' . $vars['link'],
			'',
		);
		if ( $s['signoff'] ) {
			$l[] = DIM_RR_Settings::render( $s['signoff'], $vars );
			$l[] = '';
		}
		$l[] = DIM_RR_Settings::render( $s['email_feedback'], $vars );
		if ( ! empty( $loc['feedback_url'] ) ) {
			$l[] = ( $s['contact_button'] ? $s['contact_button'] : 'Contact us' ) . ': ' . $loc['feedback_url'];
		}
		$phone = ! empty( $loc['phone'] ) ? $loc['phone'] : $s['business_phone'];
		if ( $phone ) {
			$l[] = $phone;
		}
		$l[] = '';
		$l[] = '--';
		$l[] = self::brand_name( $loc ) . ( self::brand_name( $loc ) !== $loc['name'] ? ' - ' . $loc['name'] : '' );
		if ( ! empty( $loc['address'] ) ) {
			$l[] = preg_replace( '/\s*\n\s*/', ', ', $loc['address'] );
		}
		if ( $s['website_url'] ) {
			$l[] = $s['website_url'];
		}
		if ( $s['footer_note'] ) {
			$l[] = DIM_RR_Settings::render( $s['footer_note'], $vars );
		}
		return implode( "\n", $l );
	}

	public static function html( $vars ) {
		$s      = DIM_RR_Settings::all();
		$st     = DIM_RR_Settings::style();
		$loc    = $vars['location'];
		$font   = 'font-family:' . $st['font'] . ';';
		$brand  = esc_html( self::brand_name( $loc ) );
		$lname  = esc_html( $loc['name'] );
		$head   = esc_html( DIM_RR_Settings::render( $s['email_heading'], $vars ) );
		$button = esc_html( DIM_RR_Settings::render( $s['email_button'], $vars ) );
		$link   = esc_url( $vars['link'] );
		$accent = esc_attr( $st['accent'] );
		$phone  = ! empty( $loc['phone'] ) ? $loc['phone'] : $s['business_phone'];

		$body = '';
		foreach ( preg_split( "/\n\s*\n/", DIM_RR_Settings::render( $s['email_body'], $vars ) ) as $para ) {
			$body .= '<p style="margin:0 0 16px;' . $font . 'font-size:16px;line-height:26px;color:#3c4043;">' . nl2br( esc_html( trim( $para ) ) ) . '</p>';
		}
		$pre = mb_substr( preg_replace( '/\s+/', ' ', wp_strip_all_tags( DIM_RR_Settings::render( $s['email_body'], $vars ) ) ), 0, 110 );

		$w = (int) $st['logo_width'];
		if ( $st['logo'] && ! preg_match( '/\.svg(\?|$)/i', $st['logo'] ) ) {
			$logo = '<img src="' . esc_url( $st['logo'] ) . '" width="' . $w . '" alt="' . $brand . '" style="display:block;margin:0 auto;width:' . $w . 'px;max-width:75%;height:auto;border:0;outline:none;">';
		} else {
			$logo = '<div style="' . $font . 'font-size:22px;font-weight:700;color:' . esc_attr( $st['header_on'] ) . ';text-align:center;">' . $brand . '</div>';
		}

		$stars = '';
		if ( ! empty( $s['show_stars'] ) ) {
			$stars = '<div style="' . $font . 'font-size:13px;line-height:18px;color:#5f6368;margin:0 0 4px;">Tap a star to rate us on Google</div><div style="margin:0 0 18px;">';
			for ( $i = 1; $i <= 5; $i++ ) {
				$stars .= '<a href="' . $link . '" target="_blank" style="text-decoration:none;color:' . esc_attr( $st['stars'] ) . ';font-size:38px;line-height:44px;padding:0 3px;" aria-label="Review on Google">&#9733;</a>';
			}
			$stars .= '</div>';
		}

		$signoff = $s['signoff'] ? '<p style="margin:8px 0 0;' . $font . 'font-size:16px;line-height:26px;color:#3c4043;">' . nl2br( esc_html( DIM_RR_Settings::render( $s['signoff'], $vars ) ) ) . '</p>' : '';

		$contact = '<p style="margin:0 0 6px;' . $font . 'font-size:14px;line-height:22px;color:#5f6368;">' . esc_html( DIM_RR_Settings::render( $s['email_feedback'], $vars ) ) . '</p>';
		$bits    = array();
		if ( $phone ) {
			$bits[] = '<a href="tel:' . esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ) . '" style="color:' . $accent . ';font-weight:600;text-decoration:none;">' . esc_html( $phone ) . '</a>';
		}
		if ( $bits ) {
			$contact .= '<p style="margin:0;' . $font . 'font-size:14px;line-height:22px;">' . implode( ' &nbsp;&middot;&nbsp; ', $bits ) . '</p>';
		}
		if ( ! empty( $loc['feedback_url'] ) ) {
			// Secondary, outlined button: offered to everyone, below the Google button, never instead of it.
			$label    = esc_html( $s['contact_button'] ? $s['contact_button'] : 'Contact us' );
			$brandcol = esc_attr( $st['brand'] );
			$contact .= '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:12px 0 0;"><tr>'
				. '<td style="border:2px solid ' . $brandcol . ';border-radius:' . esc_attr( $st['radius'] ) . ';background-color:#ffffff;">'
				. '<a href="' . esc_url( $loc['feedback_url'] ) . '" target="_blank" style="display:inline-block;padding:9px 22px;' . $font . 'font-size:15px;line-height:20px;font-weight:700;color:' . $brandcol . ';text-decoration:none;">' . $label . '</a>'
				. '</td></tr></table>';
		}

		$social = '';
		$soc    = self::socials();
		if ( $soc ) {
			$links = array();
			foreach ( $soc as $label => $url ) {
				$links[] = '<a href="' . esc_url( $url ) . '" style="color:#5f6368;text-decoration:none;font-weight:600;">' . esc_html( $label ) . '</a>';
			}
			$social = '<p style="margin:0 0 10px;' . $font . 'font-size:12px;line-height:18px;">' . implode( ' &nbsp;&middot;&nbsp; ', $links ) . '</p>';
		}

		$footer = $social . '<strong style="color:#5f6368;">' . $brand . '</strong>' . ( $brand !== $lname ? ' &middot; ' . $lname : '' );
		if ( ! empty( $loc['address'] ) ) {
			$footer .= '<br>' . esc_html( preg_replace( '/\s*\n\s*/', ', ', $loc['address'] ) );
		}
		if ( $s['website_url'] ) {
			$footer .= '<br><a href="' . esc_url( $s['website_url'] ) . '" style="color:#9aa0a6;">' . esc_html( preg_replace( '#^https?://(www\.)?|/$#', '', $s['website_url'] ) ) . '</a>';
		}
		if ( $s['footer_note'] ) {
			$footer .= '<br><br>' . esc_html( DIM_RR_Settings::render( $s['footer_note'], $vars ) );
		}
		if ( $s['privacy_url'] ) {
			$footer .= '<br><a href="' . esc_url( $s['privacy_url'] ) . '" style="color:#9aa0a6;">Privacy policy</a>';
		}
		if ( $s['show_credit'] ) {
			$footer .= '<br>Powered by <a href="https://detroitinternetmarketing.com/" style="color:#9aa0a6;">Detroit Internet Marketing</a>';
		}

		$bg      = esc_attr( $st['bg'] );
		$hdr     = esc_attr( $st['header'] );
		$is_band = '#ffffff' !== strtolower( $st['header'] );

		ob_start();
		?>
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="x-apple-disable-message-reformatting">
<meta name="color-scheme" content="light">
<meta name="supported-color-schemes" content="light">
<title><?php echo $brand; // phpcs:ignore ?></title>
<!--[if mso]><style>table,td,a,p,h1,div{font-family:Arial,sans-serif !important;}</style><![endif]-->
</head>
<body style="margin:0;padding:0;background-color:<?php echo $bg; // phpcs:ignore ?>;-webkit-text-size-adjust:100%;">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;mso-hide:all;"><?php echo esc_html( $pre ); ?>&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;&#847;&zwnj;&nbsp;</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:<?php echo $bg; // phpcs:ignore ?>;">
<tr><td align="center" style="padding:28px 12px;">
	<!--[if mso]><table role="presentation" width="560" cellpadding="0" cellspacing="0" border="0"><tr><td><![endif]-->
	<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;background-color:#ffffff;border-radius:12px;overflow:hidden;<?php echo $is_band ? '' : 'border-top:6px solid ' . $accent . ';'; // phpcs:ignore ?>">
		<tr><td align="center" bgcolor="<?php echo $hdr; // phpcs:ignore ?>" style="background-color:<?php echo $hdr; // phpcs:ignore ?>;padding:<?php echo $is_band ? '28px 32px' : '32px 32px 8px'; ?>;"><?php echo $logo; // phpcs:ignore ?></td></tr>
		<tr><td style="padding:24px 36px 8px;">
			<h1 style="margin:0 0 18px;<?php echo $font; // phpcs:ignore ?>font-size:26px;line-height:34px;font-weight:700;color:#202124;text-align:center;"><?php echo $head; // phpcs:ignore ?></h1>
			<?php echo $body; // phpcs:ignore ?>
		</td></tr>
		<tr><td align="center" style="padding:4px 36px 0;">
			<?php echo $stars; // phpcs:ignore ?>
			<!--[if mso]>
			<v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="<?php echo $link; // phpcs:ignore ?>" style="height:52px;v-text-anchor:middle;width:300px;" arcsize="<?php echo 'pill' === $s['button_shape'] ? '50%' : ( 'square' === $s['button_shape'] ? '6%' : '16%' ); ?>" stroke="f" fillcolor="<?php echo esc_attr( $st['brand'] ); ?>">
			<w:anchorlock/><center style="color:<?php echo esc_attr( $st['button_text'] ); ?>;font-family:Arial,sans-serif;font-size:17px;font-weight:bold;"><?php echo $button; // phpcs:ignore ?></center>
			</v:roundrect>
			<![endif]-->
			<!--[if !mso]><!-- -->
			<a href="<?php echo $link; // phpcs:ignore ?>" target="_blank" style="display:inline-block;background-color:<?php echo esc_attr( $st['brand'] ); ?>;color:<?php echo esc_attr( $st['button_text'] ); ?>;<?php echo $font; // phpcs:ignore ?>font-size:17px;font-weight:700;line-height:22px;text-decoration:none;padding:15px 34px;border-radius:<?php echo esc_attr( $st['radius'] ); ?>;"><?php echo $button; // phpcs:ignore ?> &rarr;</a>
			<!--<![endif]-->
			<div style="<?php echo $font; // phpcs:ignore ?>font-size:13px;line-height:18px;color:#80868b;margin:12px 0 0;">Takes about a minute. Opens Google on your phone or computer.</div>
		</td></tr>
		<?php if ( $signoff ) : ?>
		<tr><td style="padding:22px 36px 0;"><?php echo $signoff; // phpcs:ignore ?></td></tr>
		<?php endif; ?>
		<tr><td style="padding:24px 36px 32px;">
			<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f8f9fa;border-radius:8px;">
				<tr><td style="padding:16px 18px;"><?php echo $contact; // phpcs:ignore ?></td></tr>
			</table>
		</td></tr>
	</table>
	<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;">
		<tr><td style="padding:18px 24px;<?php echo $font; // phpcs:ignore ?>font-size:12px;line-height:18px;color:#9aa0a6;text-align:center;"><?php echo $footer; // phpcs:ignore ?></td></tr>
	</table>
	<!--[if mso]></td></tr></table><![endif]-->
</td></tr>
</table>
</body>
</html>
		<?php
		return (string) ob_get_clean();
	}
}
