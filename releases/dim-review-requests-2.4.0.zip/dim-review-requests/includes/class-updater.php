<?php
/**
 * Self-hosted updates. WordPress shows the normal "Update available" notice
 * and one-click Update button, using a small manifest (update.json) published
 * in DIM's public releases repository. The plugin's source code stays in the
 * private repository; only the built zip and manifest are public.
 *
 * Safety:
 * - The plugin's "Update URI" header means WordPress.org is never asked about
 *   this plugin, so nothing else can be installed over it.
 * - The manifest and zip are fetched over HTTPS from fixed hosts only.
 * - Every downloaded zip is checked against the SHA-256 in the manifest
 *   before WordPress installs it; a mismatch aborts the update.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Updater {

	/** Where release builds are published. Override with DIM_RR_UPDATE_MANIFEST in wp-config.php if ever needed. */
	const MANIFEST  = 'https://raw.githubusercontent.com/DetroitInternetMarketingDev/dim-review-requests-releases/main/update.json';
	const SLUG      = 'dim-review-requests';
	const CACHE_KEY = 'dim_rr_update_manifest';

	/** The only place a package may be downloaded from. */
	const PACKAGE_PREFIX = 'https://raw.githubusercontent.com/DetroitInternetMarketingDev/dim-review-requests-releases/main/releases/';

	public static function init() {
		$host = wp_parse_url( self::update_uri(), PHP_URL_HOST );
		if ( $host ) {
			add_filter( 'update_plugins_' . $host, array( __CLASS__, 'check' ), 10, 4 );
		}
		add_filter( 'plugins_api', array( __CLASS__, 'details' ), 10, 3 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verified_download' ), 10, 4 );
		add_action( 'load-update-core.php', array( __CLASS__, 'maybe_flush' ) );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'flush' ) );
	}

	/** Must match the "Update URI" header in dim-review-requests.php. */
	private static function update_uri() {
		return self::MANIFEST;
	}

	private static function manifest_url() {
		return defined( 'DIM_RR_UPDATE_MANIFEST' ) && DIM_RR_UPDATE_MANIFEST ? DIM_RR_UPDATE_MANIFEST : self::MANIFEST;
	}

	public static function flush() {
		delete_site_transient( self::CACHE_KEY );
	}

	/** "Check again" on Dashboard > Updates also refreshes our manifest. */
	public static function maybe_flush() {
		if ( isset( $_GET['force-check'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			self::flush();
		}
	}

	/**
	 * Fetch and validate the manifest (cached for 3 hours).
	 *
	 * @return array|null
	 */
	public static function manifest( $force = false ) {
		if ( ! $force ) {
			$cached = get_site_transient( self::CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached ? $cached : null;
			}
		}
		$res  = wp_remote_get( add_query_arg( 'nocache', time(), self::manifest_url() ), array( 'timeout' => 10, 'headers' => array( 'Accept' => 'application/json' ) ) );
		$data = null;
		if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
			$json = json_decode( wp_remote_retrieve_body( $res ), true );
			$data = self::validate( $json );
		}
		// Cache failures briefly too, so a GitHub outage doesn't slow wp-admin.
		set_site_transient( self::CACHE_KEY, $data ? $data : array(), $data ? 3 * HOUR_IN_SECONDS : 30 * MINUTE_IN_SECONDS );
		return $data;
	}

	/**
	 * Strict manifest check. Anything unexpected means "no update offered".
	 *
	 * @return array|null
	 */
	public static function validate( $json ) {
		if ( ! is_array( $json ) ) {
			return null;
		}
		foreach ( array( 'version', 'package', 'sha256', 'requires', 'tested', 'requires_php', 'released', 'homepage', 'changelog' ) as $k ) {
			if ( isset( $json[ $k ] ) && ! is_string( $json[ $k ] ) ) {
				return null;
			}
		}
		if ( ! isset( $json['version'], $json['package'], $json['sha256'] )
			|| ! preg_match( '/^\d{1,3}\.\d{1,3}\.\d{1,3}\z/', $json['version'] )
			|| ! preg_match( '/^[a-f0-9]{64}\z/', $json['sha256'] )
			|| ! self::allowed( $json['package'] ) ) {
			return null;
		}
		foreach ( array( 'requires', 'tested', 'requires_php' ) as $k ) {
			if ( isset( $json[ $k ] ) && ! preg_match( '/^\d+(\.\d+){0,2}\z/', $json[ $k ] ) ) {
				unset( $json[ $k ] );
			}
		}
		if ( isset( $json['homepage'] ) && 0 !== strpos( $json['homepage'], 'https://' ) ) {
			unset( $json['homepage'] );
		}
		return array_intersect_key( $json, array_flip( array( 'version', 'package', 'sha256', 'requires', 'tested', 'requires_php', 'released', 'homepage', 'changelog' ) ) );
	}

	/** Package must be a zip inside DIM's releases folder, nothing else. */
	public static function allowed( $url ) {
		$url = (string) $url;
		return 0 === strpos( $url, self::PACKAGE_PREFIX )
			&& preg_match( '#^[a-z0-9._-]+\.zip\z#i', substr( $url, strlen( self::PACKAGE_PREFIX ) ) )
			&& false === strpos( $url, '..' );
	}

	/**
	 * update_plugins_{host}: tell WordPress whether a newer version exists.
	 */
	public static function check( $update, $plugin_data, $plugin_file, $locales ) {
		if ( plugin_basename( DIM_RR_FILE ) !== $plugin_file ) {
			return $update;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $update;
		}
		return array(
			'id'           => self::update_uri(),
			'slug'         => self::SLUG,
			'plugin'       => $plugin_file,
			'version'      => $m['version'],
			'new_version'  => $m['version'],
			'url'          => isset( $m['homepage'] ) ? $m['homepage'] : '',
			'package'      => $m['package'],
			'tested'       => isset( $m['tested'] ) ? $m['tested'] : '',
			'requires'     => isset( $m['requires'] ) ? $m['requires'] : '',
			'requires_php' => isset( $m['requires_php'] ) ? $m['requires_php'] : '',
		);
	}

	/**
	 * "View details" popup on the Plugins and Updates screens.
	 */
	public static function details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! isset( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $result;
		}
		return (object) array(
			'name'          => 'DIM Review Requests',
			'slug'          => self::SLUG,
			'version'       => $m['version'],
			'author'        => 'Detroit Internet Marketing',
			'homepage'      => isset( $m['homepage'] ) ? $m['homepage'] : '',
			'requires'      => isset( $m['requires'] ) ? $m['requires'] : '',
			'tested'        => isset( $m['tested'] ) ? $m['tested'] : '',
			'requires_php'  => isset( $m['requires_php'] ) ? $m['requires_php'] : '',
			'last_updated'  => isset( $m['released'] ) ? $m['released'] : '',
			'download_link' => $m['package'],
			'sections'      => array(
				'changelog' => isset( $m['changelog'] ) ? wp_kses_post( $m['changelog'] ) : '',
			),
		);
	}

	/**
	 * Download our package ourselves and verify its SHA-256 before WordPress
	 * unpacks it. Any other plugin's download is left alone.
	 */
	public static function verified_download( $reply, $package, $upgrader, $hook_extra = array() ) {
		if ( false !== $reply ) {
			return $reply;
		}
		$ours = ( is_array( $hook_extra ) && isset( $hook_extra['plugin'] ) && plugin_basename( DIM_RR_FILE ) === $hook_extra['plugin'] )
			|| 0 === strpos( (string) $package, self::PACKAGE_PREFIX );
		if ( ! $ours ) {
			return $reply; // Another plugin's update: leave it alone.
		}
		// From here on, anything we can't verify is refused, never waved through.
		if ( ! self::allowed( $package ) ) {
			return new WP_Error( 'dim_rr_host', 'Update blocked: the download address is not DIM\'s releases folder. Nothing was changed.' );
		}
		$m = self::manifest( true );
		if ( ! $m || (string) $package !== (string) $m['package'] ) {
			return new WP_Error( 'dim_rr_manifest', 'Update blocked: could not confirm this download against DIM\'s published release. Nothing was changed. Try again later.' );
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $package, 120 );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		$hash = hash_file( 'sha256', $tmp );
		if ( ! hash_equals( strtolower( $m['sha256'] ), (string) $hash ) ) {
			wp_delete_file( $tmp );
			return new WP_Error( 'dim_rr_checksum', 'Update blocked: the downloaded file did not match its published checksum. Nothing was changed.' );
		}
		return $tmp;
	}
}
