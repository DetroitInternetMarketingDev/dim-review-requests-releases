<?php
/**
 * Staff agreement. Before a login can send its first review request, the
 * person must read the client's terms of use and tick "I agree". The plugin
 * records who agreed, when, from which IP address, and the exact wording they
 * saw. Changing the wording asks everyone to agree again.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Terms {

	const META = 'dim_rr_terms';

	const DEFAULT_TEXT = "Before you send review requests for {business}, please confirm:\n\n- I will only send requests to customers who gave {business} their mobile number or email address.\n- I will ask customers in the same way whether or not I think they had a good experience, and I will never offer anything in exchange for a review.\n- I will send during business hours, and I will not contact anyone who has opted out.\n- I will not add health, treatment, financial or other private details to any message.\n- I understand that {business} is responsible for how this tool is used, including having customers' permission to contact them, and for following texting, email, privacy and review laws and Google's review policies. Detroit Internet Marketing provides the tool and technical support only and does not decide who is contacted or when.";

	public static function init() {
		add_action( 'admin_post_dim_rr_accept_terms', array( __CLASS__, 'handle_accept' ) );
	}

	/** Terms as shown to staff, with {business} filled in. */
	public static function text() {
		$s    = DIM_RR_Settings::all();
		$text = isset( $s['staff_terms'] ) ? (string) $s['staff_terms'] : '';
		return trim( str_replace( '{business}', (string) $s['business_name'], $text ) );
	}

	public static function required() {
		return (bool) DIM_RR_Settings::get( 'terms_required' ) && '' !== self::text();
	}

	/** Short fingerprint of the current wording. */
	public static function version() {
		return substr( hash( 'sha256', self::text() ), 0, 12 );
	}

	public static function record( $user_id ) {
		$m = get_user_meta( (int) $user_id, self::META, true );
		return is_array( $m ) ? $m : array();
	}

	public static function accepted( $user_id = 0 ) {
		if ( ! self::required() ) {
			return true;
		}
		$m = self::record( $user_id ? $user_id : get_current_user_id() );
		return isset( $m['version'] ) && hash_equals( self::version(), (string) $m['version'] );
	}

	public static function handle_accept() {
		if ( ! is_user_logged_in() || ! current_user_can( DIM_RR_CAP ) ) {
			wp_die( 'You do not have permission to do this.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'dim_rr_accept_terms' );
		$back = wp_get_referer();
		$back = $back ? $back : DIM_RR_Settings::sender_page_url();

		$posted = isset( $_POST['version'] ) ? sanitize_key( wp_unslash( $_POST['version'] ) ) : '';
		if ( empty( $_POST['agree'] ) || ! hash_equals( self::version(), $posted ) ) {
			// Not ticked, or the wording changed while the page was open: show the current terms again.
			wp_safe_redirect( $back );
			exit;
		}

		$user = wp_get_current_user();
		$ip   = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$rec  = array(
			'version' => self::version(),
			'at'      => current_time( 'mysql', true ),
			'ip'      => filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '',
			'name'    => $user->display_name,
			'login'   => $user->user_login,
			'text'    => self::text(),
		);
		// Keep earlier agreements too, so there is a history when the wording changes.
		$old     = self::record( $user->ID );
		$history = isset( $old['history'] ) && is_array( $old['history'] ) ? $old['history'] : array();
		if ( isset( $old['version'] ) ) {
			unset( $old['history'] );
			array_unshift( $history, $old );
		}
		$rec['history'] = array_slice( $history, 0, 10 );
		update_user_meta( $user->ID, self::META, $rec );

		wp_safe_redirect( $back );
		exit;
	}

	/** The agreement screen shown in place of the send form. */
	public static function gate() {
		$s    = DIM_RR_Settings::all();
		$prev = self::record( get_current_user_id() );
		ob_start();
		?>
		<div class="dimrr-card dimrr-terms">
			<h2 class="dimrr-h2"><?php echo isset( $prev['version'] ) ? 'The terms of use have changed' : 'Before you start'; ?></h2>
			<p class="dimrr-help">Please read and agree to these terms of use. You only need to do this once<?php echo isset( $prev['version'] ) ? ', and again whenever they change' : ''; ?>.</p>
			<div class="dimrr-terms-text"><?php echo self::format( self::text() ); // phpcs:ignore -- escaped in format(). ?></div>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="dim_rr_accept_terms">
				<input type="hidden" name="version" value="<?php echo esc_attr( self::version() ); ?>">
				<?php wp_nonce_field( 'dim_rr_accept_terms' ); ?>
				<label class="dimrr-terms-agree"><input type="checkbox" name="agree" value="1" required> I have read and agree to these terms of use for <?php echo esc_html( $s['business_name'] ); ?>.</label>
				<p><button type="submit" class="dimrr-btn is-primary">I agree</button></p>
			</form>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/** Paragraphs and "- " bullet lines to safe HTML. */
	public static function format( $text ) {
		$html = '';
		foreach ( preg_split( "/\n\s*\n/", (string) $text ) as $block ) {
			$lines = array_filter( array_map( 'trim', explode( "\n", $block ) ), 'strlen' );
			if ( ! $lines ) {
				continue;
			}
			$bullets = array_filter(
				$lines,
				function ( $l ) {
					return 0 === strpos( $l, '- ' );
				}
			);
			if ( count( $bullets ) === count( $lines ) ) {
				$html .= '<ul>';
				foreach ( $lines as $l ) {
					$html .= '<li>' . esc_html( substr( $l, 2 ) ) . '</li>';
				}
				$html .= '</ul>';
			} else {
				$html .= '<p>' . implode( '<br>', array_map( 'esc_html', $lines ) ) . '</p>';
			}
		}
		return $html;
	}

	/** Everyone who can send, with their agreement status (for the Settings screen). */
	public static function senders() {
		global $wp_roles;
		$roles = array();
		if ( $wp_roles instanceof WP_Roles ) {
			foreach ( $wp_roles->roles as $name => $role ) {
				if ( ! empty( $role['capabilities'][ DIM_RR_CAP ] ) ) {
					$roles[] = $name;
				}
			}
		}
		if ( ! $roles ) {
			return array();
		}
		$out = array();
		foreach ( get_users( array( 'role__in' => $roles, 'number' => 200, 'orderby' => 'display_name' ) ) as $u ) {
			$out[] = array(
				'user'    => $u,
				'record'  => self::record( $u->ID ),
				'current' => self::accepted( $u->ID ),
			);
		}
		return $out;
	}
}
