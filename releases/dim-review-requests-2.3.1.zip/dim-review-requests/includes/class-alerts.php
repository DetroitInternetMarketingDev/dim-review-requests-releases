<?php
/**
 * Emails the agency when a problem would stop every request from going out.
 * Per-recipient failures (landline, opted out, phone off) never alert: they
 * are normal and are shown to staff instead.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Alerts {

	/** Twilio codes that affect every send, not one recipient. */
	const ACCOUNT_LEVEL = array( '20003', '20404', '21606', '21608', '21703', '30007', '30032', '30034', 'http', 'mail' );

	public static function maybe( $code, $message = '' ) {
		$code = (string) $code;
		$to   = DIM_RR_Settings::get( 'alert_email' );
		if ( ! $to || ! in_array( $code, self::ACCOUNT_LEVEL, true ) ) {
			return;
		}
		$key = 'dim_rr_alert_' . md5( $code );
		if ( get_transient( $key ) ) {
			return; // Already alerted for this problem recently.
		}
		set_transient( $key, 1, 6 * HOUR_IN_SECONDS );

		$site    = wp_parse_url( home_url(), PHP_URL_HOST );
		$subject = '[Review requests] Problem on ' . $site . ': ' . ( 'mail' === $code ? 'emails are not sending' : 'texts are failing (' . $code . ')' );
		$body    = "The review request tool on {$site} hit a problem that will affect every request until it is fixed.\n\n"
			. 'What happened: ' . DIM_RR_Twilio::explain( $code, $message ) . "\n"
			. ( $message ? 'Details: ' . $message . "\n" : '' )
			. "\nDiagnostics: " . admin_url( 'admin.php?page=dim-review-diagnostics' ) . "\n"
			. 'Activity: ' . admin_url( 'admin.php?page=dim-review-activity' ) . "\n\n"
			. "You will get at most one alert every 6 hours for this problem.\n";
		wp_mail( $to, $subject, $body );
	}
}
