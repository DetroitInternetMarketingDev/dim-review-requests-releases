<?php
/**
 * Send log. Stores a hash and a masked copy of each recipient, never the
 * full phone number, email address or name (keeps patient data out of the
 * database while still allowing duplicate checks).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Log {

	const DB_VERSION = '2';

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'dim_rr_log';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE $table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			channel varchar(10) NOT NULL,
			location varchar(64) NOT NULL DEFAULT '',
			recipient_hash char(64) NOT NULL,
			recipient_masked varchar(64) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT '',
			provider_id varchar(64) NOT NULL DEFAULT '',
			error_code varchar(16) NOT NULL DEFAULT '',
			error_message text NULL,
			token varchar(16) NOT NULL DEFAULT '',
			clicked_at datetime NULL,
			PRIMARY KEY  (id),
			KEY recipient_hash (recipient_hash),
			KEY provider_id (provider_id),
			KEY token (token),
			KEY created_at (created_at)
		) $charset;";
		dbDelta( $sql );
		update_option( 'dim_rr_db_version', self::DB_VERSION, true );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'dim_rr_db_version' ) !== self::DB_VERSION ) {
			self::install();
			DIM_RR_Settings::ensure_defaults();
		}
	}

	public static function hash( $recipient ) {
		return hash_hmac( 'sha256', strtolower( trim( $recipient ) ), DIM_RR_Settings::hash_key() );
	}

	public static function mask( $channel, $recipient ) {
		if ( 'email' === $channel ) {
			$parts = explode( '@', $recipient );
			$local = $parts[0];
			$dom   = isset( $parts[1] ) ? $parts[1] : '';
			return substr( $local, 0, 1 ) . str_repeat( '*', max( 2, min( 6, strlen( $local ) - 1 ) ) ) . '@' . $dom;
		}
		$digits = preg_replace( '/\D/', '', $recipient );
		return '***-***-' . substr( $digits, -4 );
	}

	public static function insert( $data ) {
		global $wpdb;
		$now  = current_time( 'mysql', true );
		$row  = array_merge(
			array(
				'created_at'       => $now,
				'updated_at'       => $now,
				'user_id'          => get_current_user_id(),
				'channel'          => '',
				'location'         => '',
				'recipient_hash'   => '',
				'recipient_masked' => '',
				'status'           => '',
				'provider_id'      => '',
				'error_code'       => '',
				'error_message'    => '',
				'token'            => '',
			),
			$data
		);
		$wpdb->insert( self::table(), $row );
		return (int) $wpdb->insert_id;
	}

	public static function update( $id, $data ) {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql', true );
		return $wpdb->update( self::table(), $data, array( 'id' => (int) $id ) );
	}

	public static function update_by_provider_id( $provider_id, $data ) {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql', true );
		return $wpdb->update( self::table(), $data, array( 'provider_id' => $provider_id ) );
	}

	/**
	 * Most recent successful (or in-flight) send to this recipient on this channel.
	 */
	public static function last_success( $channel, $hash, $since_days ) {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS * (int) $since_days );
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table() . " WHERE channel = %s AND recipient_hash = %s AND created_at >= %s AND status IN ('queued','accepted','sent','delivered','read','clicked') ORDER BY id DESC LIMIT 1",
				$channel,
				$hash,
				$since
			)
		);
	}

	/**
	 * Has this number ever come back as opted-out (STOP)?
	 */
	public static function is_opted_out( $hash ) {
		global $wpdb;
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id FROM ' . self::table() . " WHERE channel = 'sms' AND recipient_hash = %s AND error_code = '21610' LIMIT 1",
				$hash
			)
		);
	}

	/**
	 * Did an earlier text to this number fail because the number cannot
	 * receive texts (landline, invalid, disconnected)? Returns the code or ''.
	 */
	public static function bad_number_code( $hash ) {
		global $wpdb;
		return (string) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT error_code FROM ' . self::table() . " WHERE channel = 'sms' AND recipient_hash = %s AND error_code IN ('21211','21612','21614','30005','30006') ORDER BY id DESC LIMIT 1",
				$hash
			)
		);
	}

	public static function count_since( $seconds, $user_id = 0, $channel = '' ) {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - (int) $seconds );
		$sql   = 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE created_at >= %s';
		$args  = array( $since );
		if ( $user_id ) {
			$sql   .= ' AND user_id = %d';
			$args[] = $user_id;
		}
		if ( $channel ) {
			$sql   .= ' AND channel = %s';
			$args[] = $channel;
		}
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) );
	}

	public static function mark_clicked( $token ) {
		global $wpdb;
		if ( ! preg_match( '/^[A-Za-z0-9]{6,16}$/', $token ) ) {
			return;
		}
		$wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . self::table() . ' SET clicked_at = %s WHERE token = %s AND clicked_at IS NULL',
				current_time( 'mysql', true ),
				$token
			)
		);
	}

	public static function recent( $limit = 200, $user_id = 0 ) {
		global $wpdb;
		if ( $user_id ) {
			return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE user_id = %d ORDER BY id DESC LIMIT %d', $user_id, $limit ) );
		}
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' ORDER BY id DESC LIMIT %d', $limit ) );
	}

	public static function recent_failures( $limit = 5, $user_id = 0 ) {
		global $wpdb;
		if ( $user_id ) {
			return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . " WHERE user_id = %d AND status IN ('failed','undelivered','error','blocked') ORDER BY id DESC LIMIT %d", $user_id, $limit ) );
		}
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . " WHERE status IN ('failed','undelivered','error','blocked') ORDER BY id DESC LIMIT %d", $limit ) );
	}

	public static function by_token( $token ) {
		global $wpdb;
		if ( ! preg_match( '/^[A-Za-z0-9]{6,16}$/', $token ) ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE token = %s LIMIT 1', $token ) );
	}

	public static function stats( $days = 30, $user_id = 0 ) {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS * $days );
		$where = $user_id ? $wpdb->prepare( ' AND user_id = %d', $user_id ) : '';
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT channel, status, COUNT(*) AS n, SUM(clicked_at IS NOT NULL) AS clicks FROM ' . self::table() . ' WHERE created_at >= %s' . $where . ' GROUP BY channel, status', // phpcs:ignore
				$since
			)
		);
		$out = array(
			'sms'   => array( 'total' => 0, 'ok' => 0, 'failed' => 0, 'clicks' => 0 ),
			'email' => array( 'total' => 0, 'ok' => 0, 'failed' => 0, 'clicks' => 0 ),
		);
		foreach ( $rows as $r ) {
			if ( ! isset( $out[ $r->channel ] ) ) {
				continue;
			}
			$out[ $r->channel ]['total']  += (int) $r->n;
			$out[ $r->channel ]['clicks'] += (int) $r->clicks;
			if ( in_array( $r->status, array( 'failed', 'undelivered', 'error', 'blocked' ), true ) ) {
				$out[ $r->channel ]['failed'] += (int) $r->n;
			} else {
				$out[ $r->channel ]['ok'] += (int) $r->n;
			}
		}
		return $out;
	}
}
