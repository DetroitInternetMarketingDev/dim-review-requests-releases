<?php
/**
 * Brands the WordPress login screen (wp-login.php or a custom login URL such
 * as /narrowgate/) with the client's logo and colours instead of WordPress's.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Login {

	public static function init() {
		add_action( 'login_enqueue_scripts', array( __CLASS__, 'styles' ) );
		add_filter( 'login_headerurl', array( __CLASS__, 'logo_url' ) );
		add_filter( 'login_headertext', array( __CLASS__, 'logo_text' ) );
		add_filter( 'login_title', array( __CLASS__, 'title' ), 10, 2 );
	}

	private static function on() {
		return (bool) DIM_RR_Settings::get( 'brand_login' );
	}

	public static function logo_url( $url ) {
		return self::on() ? home_url( '/' ) : $url;
	}

	public static function logo_text( $text ) {
		$name = DIM_RR_Settings::get( 'business_name' );
		return self::on() && $name ? $name : $text;
	}

	public static function title( $title, $original ) {
		$name = DIM_RR_Settings::get( 'business_name' );
		return self::on() && $name ? $original . ' | ' . $name : $title;
	}

	public static function styles() {
		if ( ! self::on() ) {
			return;
		}
		$s    = DIM_RR_Settings::all();
		$st   = DIM_RR_Settings::style();
		$logo = $s['logo_url'];
		$bg   = $st['bg'];
		$btn  = $st['brand'];
		$on   = $st['button_text'];
		$acc  = $st['accent'];
		$css  = 'body.login{background:' . $bg . ';font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;}'
			. '#login{width:360px;max-width:92vw;padding:6vh 0 0;}'
			. '.login form{border:1px solid #e3e6ea;border-radius:14px;box-shadow:0 1px 2px rgba(16,24,40,.06),0 10px 30px rgba(16,24,40,.08);padding:26px 24px;}'
			. '.login label{font-weight:600;color:#1f2328;}'
			. '.login form .input,.login input[type=text],.login input[type=password]{border-radius:8px;border-color:#cfd4da;min-height:46px;font-size:16px;}'
			. '.login form .input:focus,.login input:focus{border-color:' . $btn . ';box-shadow:0 0 0 3px ' . $btn . '33;}'
			. '.wp-core-ui .button-primary{background:' . $btn . ';border-color:' . $btn . ';color:' . $on . ';border-radius:8px;min-height:42px;padding:0 22px;font-size:15px;font-weight:600;text-shadow:none;box-shadow:none;}'
			. '.wp-core-ui .button-primary:hover,.wp-core-ui .button-primary:focus{background:' . $btn . ';border-color:' . $btn . ';color:' . $on . ';filter:brightness(1.08);}'
			. '.login #nav a,.login #backtoblog a,.login .privacy-policy-page-link a{color:' . $acc . ';}'
			. '.login .button.wp-hide-pw .dashicons{color:' . $acc . ';}'
			. '.login .message,.login .notice,.login .success{border-left-color:' . $btn . ';border-radius:8px;}'
			. '.language-switcher{display:none;}';
		if ( $logo && ! preg_match( '/\.svg(\?|$)/i', $logo ) ) {
			$css .= '.login h1 a{background-image:url("' . esc_url( $logo ) . '");background-size:contain;background-position:center;width:100%;max-width:300px;height:96px;margin:0 auto 22px;}';
		} elseif ( $s['business_name'] ) {
			// No usable logo: show the business name instead of the WordPress mark.
			$css .= '.login h1 a{background:none;width:auto;height:auto;text-indent:0;font-size:24px;font-weight:700;color:#1f2328;line-height:1.3;margin-bottom:20px;text-decoration:none;text-align:center;display:block;}';
		}
		wp_register_style( 'dim-rr-login', false, array(), DIM_RR_VERSION );
		wp_enqueue_style( 'dim-rr-login' );
		wp_add_inline_style( 'dim-rr-login', wp_strip_all_tags( $css ) );
	}
}
