<?php
/**
 * Minimal Twilio REST client using the WordPress HTTP API.
 * Replaces the old bundled Twilio SDK (v5.30, 2019, ~1,500 files).
 * Authenticates with an API Key (SK...) + secret, so each site can have its
 * own key and be revoked on its own without touching the main Auth Token.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Twilio {

	/**
	 * Plain-English explanations for the errors front-desk staff will actually see.
	 * Full list: https://www.twilio.com/docs/api/errors
	 */
	const ERRORS = array(
		'20003' => 'Twilio rejected the login. The API Key or secret is wrong or was revoked (Settings > Twilio).',
		'20404' => 'Twilio could not find that resource. Check the Account SID and Messaging Service SID.',
		'20429' => 'Too many requests to Twilio at once. Wait a minute and try again.',
		'21211' => 'That phone number is not valid. Check it for typos.',
		'21408' => 'Texting to that country is not enabled in Twilio (Messaging > Settings > Geo permissions).',
		'21606' => 'The sending number cannot send texts, or it is not in this Twilio account.',
		'21608' => 'This is a Twilio trial account. It can only text verified numbers.',
		'21610' => 'This person replied STOP and is opted out. They can reply START to opt back in. Use email instead.',
		'21612' => 'Twilio cannot send between these two numbers (often a landline or unsupported number). Use email instead.',
		'21614' => 'That number cannot receive texts (landline or invalid mobile). Use email instead.',
		'21617' => 'The message is too long. Shorten the text template in Settings.',
		'21703' => 'The Messaging Service has no phone numbers in its sender pool.',
		'30003' => 'The phone was unreachable (off, out of service, or no signal).',
		'30004' => 'The message was blocked by the recipient or their carrier.',
		'30005' => 'Unknown or inactive number. It may be disconnected.',
		'30006' => 'Landline or unreachable carrier. This number cannot receive texts. Use email instead.',
		'30007' => 'The carrier filtered the message as possible spam. Check A2P 10DLC registration and the message wording.',
		'30008' => 'Unknown carrier error. Try again later or use email.',
		'30032' => 'The toll-free sending number is not verified, so texts are blocked.',
		'30034' => 'The sending number is not registered for A2P 10DLC, so US carriers block every text. Finish A2P registration in Twilio.',
		'30035' => 'This number was recently registered and is not ready for full volume yet.',
		'mail'  => 'The email could not be sent. Check WP Mail SMTP on this site.',
		'http'  => 'The website could not reach Twilio. Try again in a minute.',
	);

	public static function explain( $code, $fallback = '' ) {
		$code = (string) $code;
		if ( isset( self::ERRORS[ $code ] ) ) {
			return self::ERRORS[ $code ];
		}
		return $fallback ? $fallback : ( $code ? 'Twilio error ' . $code . '.' : 'Unknown error.' );
	}

	private static function auth_header() {
		$s = DIM_RR_Settings::all();
		return 'Basic ' . base64_encode( $s['twilio_api_key_sid'] . ':' . $s['twilio_api_key_secret'] ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * @return array{ok:bool,code:int,body:array,error_code:string,error_message:string}
	 */
	private static function request( $method, $url, $params = array() ) {
		$args = array(
			'method'  => $method,
			'timeout' => 12,
			'headers' => array(
				'Authorization' => self::auth_header(),
				'Accept'        => 'application/json',
			),
		);
		if ( 'POST' === $method ) {
			$args['body'] = $params;
		} elseif ( $params ) {
			$url = add_query_arg( array_map( 'rawurlencode', $params ), $url );
		}

		$res = wp_remote_request( $url, $args );
		if ( is_wp_error( $res ) ) {
			return array(
				'ok'            => false,
				'code'          => 0,
				'body'          => array(),
				'error_code'    => 'http',
				'error_message' => 'Could not reach Twilio: ' . $res->get_error_message(),
			);
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		$body = is_array( $body ) ? $body : array();
		$ok   = $code >= 200 && $code < 300;

		return array(
			'ok'            => $ok,
			'code'          => $code,
			'body'          => $body,
			'error_code'    => $ok ? '' : (string) ( isset( $body['code'] ) ? $body['code'] : $code ),
			'error_message' => $ok ? '' : ( isset( $body['message'] ) ? $body['message'] : 'HTTP ' . $code ),
		);
	}

	private static function api( $path ) {
		$sid = DIM_RR_Settings::get( 'twilio_account_sid' );
		return 'https://api.twilio.com/2010-04-01/Accounts/' . rawurlencode( $sid ) . $path;
	}

	/**
	 * Send a text. Uses the Messaging Service when set (recommended: it is
	 * what the A2P 10DLC campaign is attached to), otherwise the From number.
	 */
	public static function send_sms( $to, $body, $status_callback = '' ) {
		$s      = DIM_RR_Settings::all();
		$params = array(
			'To'   => $to,
			'Body' => $body,
		);
		if ( $s['twilio_messaging_service_sid'] ) {
			$params['MessagingServiceSid'] = $s['twilio_messaging_service_sid'];
		} else {
			$params['From'] = $s['twilio_from_number'];
		}
		if ( $status_callback ) {
			$params['StatusCallback'] = $status_callback;
		}
		return self::request( 'POST', self::api( '/Messages.json' ), $params );
	}

	/**
	 * Line type check (Twilio Lookup v2, Line Type Intelligence, paid per lookup).
	 *
	 * @return array{valid:?bool,type:string,error:string}
	 */
	public static function lookup( $e164 ) {
		$r = self::request(
			'GET',
			'https://lookups.twilio.com/v2/PhoneNumbers/' . rawurlencode( $e164 ),
			array( 'Fields' => 'line_type_intelligence' )
		);
		if ( ! $r['ok'] ) {
			return array( 'valid' => null, 'type' => '', 'error' => $r['error_message'] );
		}
		$type = '';
		if ( isset( $r['body']['line_type_intelligence']['type'] ) ) {
			$type = (string) $r['body']['line_type_intelligence']['type'];
		}
		return array(
			'valid' => isset( $r['body']['valid'] ) ? (bool) $r['body']['valid'] : null,
			'type'  => $type,
			'error' => '',
		);
	}

	public static function account() {
		return self::request( 'GET', self::api( '.json' ) );
	}

	public static function recent_messages( $limit = 100 ) {
		$params = array( 'PageSize' => (string) (int) $limit );
		$from   = DIM_RR_Settings::get( 'twilio_from_number' );
		if ( $from && ! DIM_RR_Settings::get( 'twilio_messaging_service_sid' ) ) {
			$params['From'] = $from;
		}
		return self::request( 'GET', self::api( '/Messages.json' ), $params );
	}

	public static function messaging_service() {
		$mg = DIM_RR_Settings::get( 'twilio_messaging_service_sid' );
		return self::request( 'GET', 'https://messaging.twilio.com/v1/Services/' . rawurlencode( $mg ) );
	}

	public static function messaging_service_numbers() {
		$mg = DIM_RR_Settings::get( 'twilio_messaging_service_sid' );
		return self::request( 'GET', 'https://messaging.twilio.com/v1/Services/' . rawurlencode( $mg ) . '/PhoneNumbers' );
	}

	public static function a2p_campaigns() {
		$mg = DIM_RR_Settings::get( 'twilio_messaging_service_sid' );
		return self::request( 'GET', 'https://messaging.twilio.com/v1/Services/' . rawurlencode( $mg ) . '/Compliance/Usa2p' );
	}

	public static function find_number( $e164 ) {
		return self::request( 'GET', self::api( '/IncomingPhoneNumbers.json' ), array( 'PhoneNumber' => $e164 ) );
	}
}
