<?php
/**
 * Admin screens: Send, Activity, QR codes & links, Settings, Diagnostics.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( DIM_RR_FILE ), array( __CLASS__, 'action_links' ) );
		add_action( 'admin_post_dim_rr_export', array( __CLASS__, 'handle_export' ) );
		add_action( 'admin_post_dim_rr_import', array( __CLASS__, 'handle_import' ) );
		add_action( 'admin_post_dim_rr_create_sender_page', array( __CLASS__, 'create_sender_page' ) );
		add_action( 'admin_post_dim_rr_create_page', array( __CLASS__, 'create_page' ) );
		add_action( 'admin_post_dim_rr_trash_pages', array( __CLASS__, 'trash_pages' ) );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard_widget' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Dashboard widget                                                   */
	/* ------------------------------------------------------------------ */

	public static function dashboard_widget() {
		if ( current_user_can( DIM_RR_CAP ) ) {
			wp_add_dashboard_widget( 'dim_rr_dashboard', 'Google review requests', array( __CLASS__, 'render_dashboard_widget' ) );
		}
	}

	public static function render_dashboard_widget() {
		$stats = DIM_RR_Log::stats( 30, current_user_can( 'manage_options' ) ? 0 : get_current_user_id() );
		$fails = DIM_RR_Log::recent_failures( 5, current_user_can( 'manage_options' ) ? 0 : get_current_user_id() );
		$total = $stats['sms']['total'] + $stats['email']['total'];
		$click = $stats['sms']['clicks'] + $stats['email']['clicks'];
		echo '<p style="display:flex;gap:18px;margin:0 0 10px;">';
		echo '<span><strong style="font-size:20px;">' . (int) $total . '</strong><br>sent in 30 days</span>';
		echo '<span><strong style="font-size:20px;">' . (int) $click . '</strong><br>opened the link</span>';
		echo '<span><strong style="font-size:20px;color:' . ( ( $stats['sms']['failed'] + $stats['email']['failed'] ) ? '#c62828' : 'inherit' ) . ';">' . (int) ( $stats['sms']['failed'] + $stats['email']['failed'] ) . '</strong><br>failed</span>';
		echo '</p>';
		if ( $fails ) {
			echo '<p style="margin:12px 0 4px;"><strong>Recent problems</strong></p><ul style="margin:0;">';
			foreach ( $fails as $f ) {
				echo '<li style="margin:0 0 6px;">' . esc_html( get_date_from_gmt( $f->created_at, 'M j' ) . ' · ' . ( 'sms' === $f->channel ? 'Text to ' : 'Email to ' ) . $f->recipient_masked ) . '<br><span style="color:#c62828;">' . esc_html( DIM_RR_Twilio::explain( $f->error_code, $f->error_message ) ) . '</span></li>';
			}
			echo '</ul>';
		}
		echo '<p style="margin:12px 0 0;"><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=dim-review-requests' ) ) . '">Send a review request</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=dim-review-activity' ) ) . '">Activity</a></p>';
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=dim-review-settings' ) ) . '">Settings</a>' );
		return $links;
	}

	public static function menu() {
		add_menu_page( 'Review Requests', 'Review Requests', DIM_RR_CAP, 'dim-review-requests', array( __CLASS__, 'page_send' ), 'dashicons-star-filled', 26 );
		add_submenu_page( 'dim-review-requests', 'Send a review request', 'Send request', DIM_RR_CAP, 'dim-review-requests', array( __CLASS__, 'page_send' ) );
		add_submenu_page( 'dim-review-requests', 'Activity', 'Activity', DIM_RR_CAP, 'dim-review-activity', array( __CLASS__, 'page_activity' ) );
		add_submenu_page( 'dim-review-requests', 'QR codes & links', 'QR codes & links', DIM_RR_CAP, 'dim-review-qr', array( __CLASS__, 'page_qr' ) );
		add_submenu_page( 'dim-review-requests', 'Review Request Settings', 'Settings', 'manage_options', 'dim-review-settings', array( __CLASS__, 'page_settings' ) );
		add_submenu_page( 'dim-review-requests', 'Diagnostics', 'Diagnostics', 'manage_options', 'dim-review-diagnostics', array( __CLASS__, 'page_diagnostics' ) );
	}

	public static function register_settings() {
		register_setting(
			'dim_rr',
			DIM_RR_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'DIM_RR_Settings', 'sanitize' ),
			)
		);
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'dim-review' ) ) {
			return;
		}
		self::enqueue_app_assets();
		if ( false !== strpos( (string) $hook, 'dim-review-settings' ) && current_user_can( 'upload_files' ) ) {
			wp_enqueue_media();
		}
		if ( false !== strpos( (string) $hook, 'dim-review-qr' ) ) {
			wp_enqueue_script( 'dim-rr-qrcode', DIM_RR_Public::QR_JS, array(), null, true ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- version in URL; SRI added.
			wp_enqueue_script( 'dim-rr-public', DIM_RR_URL . 'assets/public.js', array( 'dim-rr-qrcode' ), DIM_RR_VERSION, true );
		}
	}

	public static function enqueue_app_assets() {
		wp_enqueue_style( 'dim-rr-admin', DIM_RR_URL . 'assets/admin.css', array(), DIM_RR_VERSION );
		wp_enqueue_script( 'dim-rr-admin', DIM_RR_URL . 'assets/admin.js', array(), DIM_RR_VERSION, true );

		$s      = DIM_RR_Settings::all();
		$locs   = array();
		foreach ( DIM_RR_Settings::locations() as $slug => $loc ) {
			$locs[ $slug ] = array(
				'name'    => $loc['name'],
				'sms'     => DIM_RR_Settings::sms_safe( DIM_RR_Settings::render( $s['sms_template'], array( 'first_name' => '__NAME__', 'link' => DIM_RR_Settings::review_link( $loc, 'Ab3dE7gH' ), 'location' => $loc, 'sms' => true ) ) ),
				'subject' => DIM_RR_Settings::render( $s['email_subject'], array( 'first_name' => '__NAME__', 'location' => $loc ) ),
				'ready'   => ! empty( $loc['review_url'] ),
			);
		}
		wp_localize_script(
			'dim-rr-admin',
			'DIM_RR',
			array(
				'ajax'      => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'dim_rr_send' ),
				'locations' => $locs,
				'origin'    => home_url(),
				'presets'   => DIM_RR_Settings::presets(),
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Send                                                               */
	/* ------------------------------------------------------------------ */

	public static function sender_app( $frontend = false ) {
		if ( $frontend ) {
			self::enqueue_app_assets();
		}
		$s        = DIM_RR_Settings::all();
		$locs     = DIM_RR_Settings::locations();
		$sms_on   = DIM_RR_Settings::twilio_ready();
		$is_admin = current_user_can( 'manage_options' );
		$who      = DIM_RR_Settings::audience_word();
		$recent   = DIM_RR_Sender::recent_rows( $is_admin ? 0 : get_current_user_id() );
		$first    = $locs ? reset( $locs ) : null;

		ob_start();
		?>
		<div class="dimrr-app<?php echo $frontend ? ' is-frontend' : ''; ?>" style="--dimrr-brand: <?php echo esc_attr( $s['brand_color'] ); ?>;">
			<header class="dimrr-top">
				<?php if ( $s['logo_url'] ) : ?>
					<img class="dimrr-top-logo" src="<?php echo esc_url( $s['logo_url'] ); ?>" alt="">
				<?php endif; ?>
				<div>
					<h1 class="dimrr-title">Ask for a Google review</h1>
					<p class="dimrr-sub"><?php echo esc_html( $s['business_name'] ); ?></p>
				</div>
			</header>

			<?php if ( ! $locs ) : ?>
				<div class="dimrr-alert is-error">No locations are set up yet. <?php echo $is_admin ? '<a href="' . esc_url( admin_url( 'admin.php?page=dim-review-settings#locations' ) ) . '">Add a location</a>' : 'Ask an administrator to finish setup.'; ?></div>
			<?php else : ?>

			<div class="dimrr-layout">
				<form class="dimrr-card dimrr-form" novalidate>
					<?php if ( count( $locs ) > 1 ) : ?>
						<fieldset class="dimrr-locs">
							<legend>Which location did they work with?</legend>
							<div class="dimrr-loc-grid">
								<?php foreach ( $locs as $slug => $loc ) : ?>
									<label class="dimrr-loc">
										<input type="radio" name="location" value="<?php echo esc_attr( $slug ); ?>" <?php checked( $first && $first['slug'] === $slug ); ?>>
										<span class="dimrr-loc-body">
											<span class="dimrr-loc-name"><?php echo esc_html( $loc['name'] ); ?></span>
											<?php if ( $loc['address'] ) : ?>
												<span class="dimrr-loc-meta"><?php echo esc_html( strtok( preg_replace( '/\s*\n\s*/', ', ', $loc['address'] ), "\n" ) ); ?></span>
											<?php endif; ?>
											<?php if ( ! $loc['review_url'] ) : ?>
												<span class="dimrr-loc-meta is-warn">No review link yet</span>
											<?php endif; ?>
										</span>
									</label>
								<?php endforeach; ?>
							</div>
						</fieldset>
					<?php else : ?>
						<input type="hidden" name="location" value="<?php echo esc_attr( $first['slug'] ); ?>">
					<?php endif; ?>

					<div class="dimrr-field">
						<label for="dimrr-first"><?php echo esc_html( ucfirst( $who ) ); ?>'s first name <span class="dimrr-opt">optional</span></label>
						<input id="dimrr-first" name="first_name" type="text" autocomplete="off" autocapitalize="words" maxlength="30" placeholder="Jane">
					</div>

					<div class="dimrr-pair">
						<div class="dimrr-field">
							<label for="dimrr-phone">Mobile number</label>
							<div class="dimrr-input-icon">
								<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 2h10a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm0 3v13h10V5H7zm5 14.2a1 1 0 1 0 0 .01z"/></svg>
								<input id="dimrr-phone" name="phone" type="tel" inputmode="tel" autocomplete="off" placeholder="(586) 555-1234" <?php disabled( ! $sms_on ); ?>>
							</div>
							<?php if ( ! $sms_on ) : ?>
								<p class="dimrr-note">Texting is not set up yet.</p>
							<?php endif; ?>
						</div>
						<div class="dimrr-field">
							<label for="dimrr-email">Email address</label>
							<div class="dimrr-input-icon">
								<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm1 2.4V17h16V7.4l-8 5.3-8-5.3zM5.2 7 12 11.5 18.8 7H5.2z"/></svg>
								<input id="dimrr-email" name="email" type="email" inputmode="email" autocomplete="off" placeholder="name@example.com">
							</div>
						</div>
					</div>
					<p class="dimrr-hint">Fill in a mobile number, an email, or both. Each person is asked at most once every <?php echo (int) $s['cooldown_days']; ?> days.</p>

					<?php if ( $is_admin ) : ?>
						<label class="dimrr-check"><input type="checkbox" name="force" value="1"> Send even if they were asked recently <span class="dimrr-opt">admins only</span></label>
					<?php endif; ?>

					<button type="submit" class="dimrr-submit">
						<span class="dimrr-submit-label">Send review request</span>
					</button>
					<div class="dimrr-results" aria-live="polite"></div>
				</form>

				<aside class="dimrr-side">
					<section class="dimrr-card dimrr-preview">
						<h2 class="dimrr-h2">What they'll get</h2>
						<div class="dimrr-phone-mock">
							<div class="dimrr-bubble" data-preview="sms"></div>
						</div>
						<p class="dimrr-subject"><span>Email subject</span> <strong data-preview="subject"></strong></p>
					</section>

					<section class="dimrr-card dimrr-recent">
						<div class="dimrr-recent-head">
							<h2 class="dimrr-h2"><?php echo $is_admin ? 'Recent requests' : 'Your recent requests'; ?></h2>
							<?php if ( ! $frontend && ! DIM_RR_Settings::is_sender_only() ) : ?>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=dim-review-activity' ) ); ?>" class="dimrr-link">All activity</a>
							<?php endif; ?>
						</div>
						<ul class="dimrr-recent-list" data-recent='<?php echo esc_attr( wp_json_encode( $recent ) ); ?>'></ul>
						<button type="button" class="dimrr-btn dimrr-more" data-recent-more hidden>Show more</button>
					</section>
				</aside>
			</div>
			<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	public static function page_send() {
		echo '<div class="wrap dimrr-wrap">';
		echo self::sender_app( false ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside.
		echo '</div>';
	}

	/* ------------------------------------------------------------------ */
	/* Activity                                                           */
	/* ------------------------------------------------------------------ */

	public static function page_activity() {
		$mine  = ! current_user_can( 'manage_options' );
		$rows  = DIM_RR_Log::recent( 300, $mine ? get_current_user_id() : 0 );
		$stats = DIM_RR_Log::stats( 30, $mine ? get_current_user_id() : 0 );
		$locs  = DIM_RR_Settings::locations();
		$users = array();
		?>
		<div class="wrap dimrr-wrap">
			<div class="dimrr-app">
				<header class="dimrr-top"><div><h1 class="dimrr-title">Activity</h1><p class="dimrr-sub">Every request, with delivery status from Twilio and whether the review link was opened.</p></div></header>
				<div class="dimrr-stats">
					<?php foreach ( array( 'sms' => 'Texts', 'email' => 'Emails' ) as $ch => $label ) : ?>
						<?php $st = $stats[ $ch ]; ?>
						<div class="dimrr-card dimrr-stat">
							<span class="dimrr-stat-label"><?php echo esc_html( $label ); ?> &middot; 30 days</span>
							<span class="dimrr-stat-num"><?php echo (int) $st['total']; ?></span>
							<span class="dimrr-stat-meta"><?php echo (int) $st['failed']; ?> failed &middot; <?php echo (int) $st['clicks']; ?> opened link<?php echo $st['total'] ? ' (' . esc_html( round( 100 * $st['clicks'] / $st['total'] ) ) . '%)' : ''; ?></span>
						</div>
					<?php endforeach; ?>
				</div>
				<div class="dimrr-card dimrr-table-wrap">
					<table class="dimrr-table">
						<thead><tr><th>When</th><th>Type</th><th>To</th><th>Location</th><th>Sent by</th><th>Status</th><th>Opened</th></tr></thead>
						<tbody>
						<?php if ( ! $rows ) : ?>
							<tr><td colspan="7" class="dimrr-empty">Nothing sent yet.</td></tr>
						<?php endif; ?>
						<?php foreach ( $rows as $r ) : ?>
							<?php
							if ( ! isset( $users[ $r->user_id ] ) ) {
								$u                    = get_userdata( $r->user_id );
								$users[ $r->user_id ] = $u ? $u->display_name : '-';
							}
							$bad  = in_array( $r->status, array( 'failed', 'undelivered', 'error', 'blocked' ), true );
							$good = in_array( $r->status, array( 'delivered', 'read' ), true );
							?>
							<tr>
								<td><?php echo esc_html( get_date_from_gmt( $r->created_at, 'M j, g:i a' ) ); ?></td>
								<td><?php echo 'sms' === $r->channel ? 'Text' : 'Email'; ?></td>
								<td><?php echo esc_html( $r->recipient_masked ); ?></td>
								<td><?php echo esc_html( isset( $locs[ $r->location ] ) ? $locs[ $r->location ]['name'] : $r->location ); ?></td>
								<td><?php echo esc_html( $users[ $r->user_id ] ); ?></td>
								<td>
									<span class="dimrr-pill <?php echo $bad ? 'is-bad' : ( $good ? 'is-good' : '' ); ?>"><?php echo esc_html( $r->status ); ?></span>
									<?php if ( $r->error_code ) : ?>
										<div class="dimrr-detail"><?php echo esc_html( DIM_RR_Twilio::explain( $r->error_code, $r->error_message ) ); ?></div>
									<?php endif; ?>
								</td>
								<td><?php echo $r->clicked_at ? '<span class="dimrr-pill is-good">' . esc_html( get_date_from_gmt( $r->clicked_at, 'M j' ) ) . '</span>' : ''; ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<p class="dimrr-hint">Numbers and emails are stored masked. "Opened" is approximate: some phones and email filters open links automatically.</p>
			</div>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* QR & links                                                         */
	/* ------------------------------------------------------------------ */

	public static function page_qr() {
		$s    = DIM_RR_Settings::all();
		$locs = array_filter(
			DIM_RR_Settings::locations(),
			function ( $l ) {
				return ! empty( $l['review_url'] );
			}
		);
		?>
		<div class="wrap dimrr-wrap">
			<div class="dimrr-app">
				<header class="dimrr-top"><div><h1 class="dimrr-title">QR codes &amp; review links</h1><p class="dimrr-sub">Print a counter card or truck sticker, or paste the link on invoices, estimates and email signatures.</p></div></header>
				<?php if ( ! $locs ) : ?>
					<div class="dimrr-alert is-error">Add a location with a Google review link in Settings first.</div>
				<?php endif; ?>
				<div class="dimrr-qr-grid">
				<?php foreach ( $locs as $loc ) : ?>
					<?php $link = DIM_RR_Settings::review_link( $loc ); ?>
					<section class="dimrr-card dimrr-qr-item">
						<div class="dimrr-print-card" id="dimrr-card-<?php echo esc_attr( $loc['slug'] ); ?>">
							<?php if ( $s['logo_url'] ) : ?>
								<img src="<?php echo esc_url( $s['logo_url'] ); ?>" alt="" class="dimrr-print-logo">
							<?php endif; ?>
							<p class="dimrr-print-title"><?php echo esc_html( DIM_RR_Settings::render( $s['qr_title'], array( 'location' => $loc ) ) ); ?></p>
							<div class="dim-rr-qr" data-dim-rr-qr="<?php echo esc_url( $link ); ?>" data-size="240"></div>
							<p class="dimrr-print-sub">Scan to leave us a Google review</p>
							<p class="dimrr-print-loc"><?php echo esc_html( $loc['name'] ); ?></p>
						</div>
						<label class="dimrr-label">Link to share</label>
						<div class="dimrr-copy">
							<input type="text" readonly value="<?php echo esc_attr( $link ); ?>">
							<button type="button" class="dimrr-btn" data-copy>Copy</button>
						</div>
						<div class="dimrr-actions">
							<button type="button" class="dimrr-btn is-primary" data-print="dimrr-card-<?php echo esc_attr( $loc['slug'] ); ?>">Print card</button>
							<button type="button" class="dimrr-btn" data-dim-rr-download="dimrr-card-<?php echo esc_attr( $loc['slug'] ); ?>" data-filename="google-review-qr-<?php echo esc_attr( $loc['slug'] ); ?>.png">Download QR (PNG)</button>
						</div>
					</section>
				<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* Settings                                                           */
	/* ------------------------------------------------------------------ */

	private static function name( $key ) {
		return DIM_RR_Settings::OPTION . '[' . $key . ']';
	}

	private static function field( $key, $label, $type = 'text', $help = '', $extra = array() ) {
		$s     = DIM_RR_Settings::all();
		$value = isset( $s[ $key ] ) ? $s[ $key ] : '';
		$id    = 'dim-rr-' . $key;
		echo '<div class="dimrr-field">';
		if ( 'checkbox' !== $type ) {
			echo '<label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
		}
		if ( DIM_RR_Settings::is_constant( $key ) ) {
			echo '<div class="dimrr-locked"><code>' . esc_html( 'twilio_api_key_secret' === $key ? '••••••••••••' : $value ) . '</code> set in wp-config.php</div>';
		} elseif ( 'textarea' === $type ) {
			echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( self::name( $key ) ) . '" rows="' . (int) ( isset( $extra['rows'] ) ? $extra['rows'] : 4 ) . '">' . esc_textarea( $value ) . '</textarea>';
		} elseif ( 'checkbox' === $type ) {
			echo '<label class="dimrr-check"><input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( self::name( $key ) ) . '" value="1" ' . checked( ! empty( $value ), true, false ) . '> ' . esc_html( $label ) . '</label>';
		} elseif ( 'select' === $type ) {
			echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( self::name( $key ) ) . '">';
			foreach ( $extra['options'] as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '" ' . selected( $value, $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'media' === $type ) {
			echo '<div class="dimrr-media"><input type="url" id="' . esc_attr( $id ) . '" name="' . esc_attr( self::name( $key ) ) . '" value="' . esc_attr( $value ) . '" placeholder="https://">';
			echo '<button type="button" class="dimrr-btn" data-media-target="' . esc_attr( $id ) . '">Choose</button></div>';
			echo '<div class="dimrr-media-preview" data-media-preview="' . esc_attr( $id ) . '">' . ( $value ? '<img src="' . esc_url( $value ) . '" alt="">' : '' ) . '</div>';
		} elseif ( 'color' === $type ) {
			echo '<div class="dimrr-color"><input type="color" data-color-for="' . esc_attr( $id ) . '" value="' . esc_attr( $value ? $value : '#ffffff' ) . '" aria-label="' . esc_attr( $label ) . ' picker"><input type="text" id="' . esc_attr( $id ) . '" name="' . esc_attr( self::name( $key ) ) . '" value="' . esc_attr( $value ) . '" placeholder="#rrggbb" maxlength="7" class="dimrr-hex"></div>';
		} elseif ( 'secret' === $type ) {
			echo '<input type="password" id="' . esc_attr( $id ) . '" name="' . esc_attr( self::name( $key ) ) . '" value="" autocomplete="new-password" placeholder="' . ( $value ? 'Saved. Leave blank to keep it.' : '' ) . '">';
		} else {
			echo '<input type="' . esc_attr( $type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( self::name( $key ) ) . '" value="' . esc_attr( $value ) . '"' . ( isset( $extra['attrs'] ) ? ' ' . $extra['attrs'] : '' ) . '>'; // phpcs:ignore
		}
		if ( $help ) {
			echo '<p class="dimrr-help">' . wp_kses_post( $help ) . '</p>';
		}
		echo '</div>';
	}

	private static function location_card( $i, $loc ) {
		$loc  = array_merge( array_fill_keys( DIM_RR_Settings::LOCATION_FIELDS, '' ), (array) $loc );
		$base = self::name( 'locations' ) . '[' . $i . ']';
		$f    = function ( $key, $label, $type = 'text', $help = '', $attrs = '' ) use ( $loc, $base, $i ) {
			$id = 'dimrr-loc-' . $i . '-' . $key;
			echo '<div class="dimrr-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
			if ( 'textarea' === $type ) {
				echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $base . '[' . $key . ']' ) . '" rows="2"' . $attrs . '>' . esc_textarea( $loc[ $key ] ) . '</textarea>'; // phpcs:ignore
			} else {
				echo '<input type="' . esc_attr( $type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $base . '[' . $key . ']' ) . '" value="' . esc_attr( $loc[ $key ] ) . '"' . $attrs . '>'; // phpcs:ignore
			}
			if ( $help ) {
				echo '<p class="dimrr-help">' . wp_kses_post( $help ) . '</p>';
			}
			echo '</div>';
		};
		?>
		<div class="dimrr-card dimrr-loc-card" data-loc-card>
			<div class="dimrr-loc-card-head">
				<strong data-loc-title><?php echo esc_html( $loc['name'] ? $loc['name'] : 'New location' ); ?></strong>
				<button type="button" class="dimrr-btn is-ghost" data-loc-remove>Remove</button>
			</div>
			<div class="dimrr-grid-2">
				<?php
				$f( 'name', 'Location name', 'text', 'What staff pick on the send screen, e.g. "Roseville". Also shown in the email footer.', ' data-loc-name required' );
				$f( 'slug', 'Short ID', 'text', 'Used in the review link, e.g. <code>roseville</code>. Leave blank to create one.' );
				$f( 'review_url', 'Google review link', 'url', 'Google Business Profile &gt; <em>Ask for reviews</em> &gt; copy link (g.page/r/&hellip;/review).' );
				$f( 'sms_name', 'Short name for texts', 'text', 'Optional, keeps texts to one 160-character segment, e.g. "Neighborhood Masonry".' );
				$f( 'phone', 'Phone', 'text' );
				$f( 'feedback_url', 'Contact page', 'url', 'Offered next to the Google button, never instead of it.' );
				$f( 'reply_to', 'Reply-to email for this location', 'email', 'Optional. Replies to this location\'s emails go here.' );
				$f( 'address', 'Address', 'textarea' );
				$f( 'map_embed_url', 'Google Map embed', 'textarea', 'Google Maps &gt; the listing &gt; Share &gt; Embed a map &gt; copy HTML, paste here.' );
				?>
			</div>
		</div>
		<?php
	}

	public static function page_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s    = DIM_RR_Settings::all();
		$locs = array_values( (array) $s['locations'] );
		$tabs = array(
			'brand'     => 'Brand & style',
			'locations' => 'Business & locations',
			'messages'  => 'Messages',
			'email'     => 'Email delivery',
			'twilio'    => 'Twilio',
			'limits'    => 'Limits & alerts',
			'tools'     => 'Import / export / remove',
		);
		$notice = isset( $_GET['dimrr_notice'] ) ? sanitize_key( wp_unslash( $_GET['dimrr_notice'] ) ) : ''; // phpcs:ignore
		?>
		<div class="wrap dimrr-wrap">
			<div class="dimrr-app" style="--dimrr-brand: <?php echo esc_attr( $s['brand_color'] ); ?>;">
				<header class="dimrr-top"><div><h1 class="dimrr-title">Review request settings</h1><p class="dimrr-sub">Everything that changes from client to client lives here.</p></div></header>
				<?php if ( 'imported' === $notice ) : ?>
					<div class="dimrr-alert is-success">Settings imported. This site's Twilio, email sender, privacy/terms links and alert email were left unchanged.</div>
				<?php elseif ( 'import_error' === $notice ) : ?>
					<div class="dimrr-alert is-error">That file or text is not a DIM Review Requests export.</div>
				<?php endif; ?>
				<?php settings_errors( DIM_RR_Settings::OPTION ); ?>
				<?php self::setup_checklist(); ?>
				<form method="post" action="options.php" class="dimrr-settings">
					<?php settings_fields( 'dim_rr' ); ?>
					<input type="hidden" name="<?php echo esc_attr( self::name( '_form' ) ); ?>" value="1">
					<nav class="dimrr-tabs" role="tablist">
						<?php foreach ( $tabs as $k => $l ) : ?>
							<a href="#<?php echo esc_attr( $k ); ?>" class="dimrr-tab" role="tab" data-tab="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $l ); ?></a>
						<?php endforeach; ?>
					</nav>

					<section class="dimrr-panel" data-panel="brand">
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Logo</h2>
							<div class="dimrr-grid-2">
								<?php
								self::field( 'logo_url', 'Logo', 'media', 'PNG or JPG, about 400px wide, on a transparent or white background. <strong>SVG does not show in Gmail or Outlook.</strong>' );
								self::field( 'email_logo_url', 'Logo for a colored header (optional)', 'media', 'A white or light version, used only when the email header is set to "Brand color band".' );
								self::field( 'logo_width', 'Logo width in emails (px)', 'number', '160–240 works for most logos.', array( 'attrs' => 'min="80" max="400" step="10"' ) );
								?>
							</div>
						</div>
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Colors</h2>
							<div class="dimrr-grid-3">
								<?php
								self::field( 'brand_color', 'Button color', 'color', 'Email button, review page button, send screen.' );
								self::field( 'accent_color', 'Accent color', 'color', 'Top bar and links. Blank = button color.' );
								self::field( 'header_bg_color', 'Header band color', 'color', 'Used with the color band header. Blank = button color.' );
								self::field( 'email_bg_color', 'Email background', 'color' );
								self::field( 'star_color', 'Star color', 'color', 'Google yellow is #fbbc04.' );
								self::field( 'button_text', 'Button text color', 'select', 'Auto picks white or black for the best contrast.', array( 'options' => array( 'auto' => 'Auto', 'light' => 'White', 'dark' => 'Black' ) ) );
								?>
							</div>
						</div>
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Email style</h2>
							<div class="dimrr-grid-3">
								<?php
								self::field( 'header_style', 'Header', 'select', '', array( 'options' => array( 'white' => 'Logo on white, accent bar on top', 'color' => 'Logo on a brand color band' ) ) );
								self::field( 'button_shape', 'Button shape', 'select', '', array( 'options' => array( 'rounded' => 'Rounded', 'square' => 'Square', 'pill' => 'Pill' ) ) );
								self::field( 'email_font', 'Font', 'select', 'Email-safe fonts only.', array( 'options' => array( 'system' => 'Modern system font', 'arial' => 'Arial', 'helvetica' => 'Helvetica', 'georgia' => 'Georgia (serif)', 'verdana' => 'Verdana', 'trebuchet' => 'Trebuchet' ) ) );
								?>
							</div>
							<?php
							self::field( 'show_stars', 'Show the clickable 5-star row', 'checkbox' );
							self::field( 'show_socials', 'Show social links in the email footer and on the review page', 'checkbox' );
							self::field( 'show_credit', 'Show "Powered by Detroit Internet Marketing"', 'checkbox' );
							self::field( 'brand_login', 'Brand the WordPress login page with this logo and colors', 'checkbox', 'Replaces the WordPress logo and colors on the login screen (including a custom login address) for everyone who signs in.' );
							?>
						</div>
						<?php self::email_preview( $locs ); ?>
					</section>

					<section class="dimrr-panel" data-panel="locations">
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Business</h2>
							<div class="dimrr-grid-2">
								<?php
								self::field( 'business_name', 'Business name', 'text', 'Used for <code>{business}</code> in emails and on the review page.' );
								self::field( 'audience', 'Call the people you serve', 'select', '', array( 'options' => array( 'customer' => 'Customers', 'client' => 'Clients', 'patient' => 'Patients' ) ) );
								self::field( 'website_url', 'Website', 'url' );
								self::field( 'business_phone', 'Main phone', 'text', 'Used when a location has no phone of its own.' );
								self::field( 'business_email', 'Main email', 'email', 'Used as the reply-to when nothing more specific is set.' );
								self::field( 'privacy_url', 'Privacy policy page', 'url', 'Linked in the email and review page footers. Required for A2P texting registration. Paste the <code>[dim_sms_privacy]</code> wording into it.' );
								self::field( 'terms_url', 'SMS terms page', 'url', 'Create a page containing <code>[dim_sms_terms]</code> and paste its address here. Required for A2P texting registration.' );
								?>
							</div>
						</div>
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Social profiles <span class="dimrr-opt">optional, shown as links</span></h2>
							<div class="dimrr-grid-3">
								<?php foreach ( DIM_RR_Settings::SOCIALS as $k => $label ) : ?>
									<div class="dimrr-field">
										<label for="dimrr-soc-<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $label ); ?></label>
										<input type="url" id="dimrr-soc-<?php echo esc_attr( $k ); ?>" name="<?php echo esc_attr( self::name( 'socials' ) . '[' . $k . ']' ); ?>" value="<?php echo esc_attr( isset( $s['socials'][ $k ] ) ? $s['socials'][ $k ] : '' ); ?>" placeholder="https://">
									</div>
								<?php endforeach; ?>
							</div>
						</div>
						<h2 class="dimrr-h2 dimrr-section-title">Locations <span class="dimrr-opt">one per Google Business Profile</span></h2>
						<div class="dimrr-locs-list" data-locs>
							<?php
							if ( ! $locs ) {
								$locs = array( array( 'name' => $s['business_name'] ) );
							}
							foreach ( $locs as $i => $loc ) {
								self::location_card( $i, $loc );
							}
							?>
						</div>
						<template data-loc-template><?php self::location_card( '__i__', array() ); ?></template>
						<button type="button" class="dimrr-btn" data-loc-add>+ Add location</button>
					</section>

					<section class="dimrr-panel" data-panel="messages">
						<div class="dimrr-card dimrr-preset">
							<div>
								<h2 class="dimrr-h2">Start from a preset</h2>
								<p class="dimrr-help">Fills in the wording below for the type of business. Review it, then save.</p>
							</div>
							<div class="dimrr-preset-row">
								<select data-preset-select aria-label="Wording preset">
									<?php foreach ( DIM_RR_Settings::presets() as $k => $p ) : ?>
										<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $p['label'] ); ?></option>
									<?php endforeach; ?>
								</select>
								<button type="button" class="dimrr-btn" data-preset-apply>Apply wording</button>
							</div>
						</div>
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Text message</h2>
							<?php
							self::field( 'sms_template', 'Message', 'textarea', 'Placeholders: <code>{first_name}</code> <code>{business}</code> <code>{link}</code> <code>{phone}</code>. Keep the business name near the start, avoid emoji, keep "Reply STOP to opt out". <strong data-sms-count></strong>', array( 'rows' => 3 ) );
							self::field( 'lookup_line_type', 'Check for landlines before texting (Twilio Lookup, about a penny each)', 'checkbox', 'Stops the most common failure: texts sent to home or office landlines.' );
							?>
						</div>
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Email</h2>
							<div class="dimrr-grid-2">
								<?php
								self::field( 'email_subject', 'Subject', 'text', '<code>{first_name}</code> is dropped cleanly when no name is entered.' );
								self::field( 'email_heading', 'Heading', 'text', '<code>{name_comma}</code> becomes ", Jane" or nothing.' );
								?>
							</div>
							<?php self::field( 'email_body', 'Message', 'textarea', 'Separate paragraphs with a blank line.', array( 'rows' => 5 ) ); ?>
							<div class="dimrr-grid-2">
								<?php
								self::field( 'email_button', 'Button text' );
								self::field( 'signoff', 'Sign-off', 'textarea', 'Press Enter for a new line, e.g. "Thank you," then "Mike and the team". Leave blank for none.', array( 'rows' => 2 ) );
								self::field( 'email_feedback', 'Contact line', 'text', 'Shown in the grey box with the phone number and contact link.' );
								self::field( 'footer_note', 'Footer note', 'text', 'Why they got the email.' );
								?>
							</div>
						</div>
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Review page &amp; QR card</h2>
							<p class="dimrr-help">Used by the <code>[dim_review_page]</code> shortcode and the printable QR cards.</p>
							<?php
							self::field( 'page_heading', 'Review page heading' );
							self::field( 'page_intro', 'Review page intro', 'textarea', '', array( 'rows' => 2 ) );
							self::field( 'qr_title', 'QR card title', 'text', 'e.g. "Enjoyed your visit?" or "Happy with your project?"' );
							?>
						</div>
						<?php self::email_preview( $locs ); ?>
					</section>

					<section class="dimrr-panel" data-panel="email">
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Email delivery</h2>
							<p class="dimrr-help">Emails go out through WordPress, so they use the site's SMTP plugin (WP Mail SMTP). If that plugin has "Force From Email" on, its address wins.</p>
							<div class="dimrr-grid-2">
								<?php
								self::field( 'from_name', 'From name', 'text', 'Blank = business name.' );
								self::field( 'from_email', 'From address', 'email', 'Must be on a domain the SMTP service is set up for (SPF/DKIM). Blank = SMTP plugin setting.' );
								self::field( 'reply_to', 'Reply-to address', 'email', 'Where replies go. A location can override this. Blank = main email.' );
								?>
							</div>
						</div>
					</section>

					<section class="dimrr-panel" data-panel="twilio">
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Twilio</h2>
							<p class="dimrr-help"><strong>Recommended:</strong> a Restricted API Key made just for this website (Twilio Console &gt; API keys &amp; tokens &gt; Create API key &gt; Restricted), stored in <code>wp-config.php</code>. <strong>Temporary:</strong> you can enter the Account SID in "API Key SID" and the Auth Token as the secret while you switch over; Diagnostics will remind you.</p>
							<div class="dimrr-grid-2">
								<?php
								self::field( 'twilio_account_sid', 'Account SID', 'text', 'Starts with AC.' );
								self::field( 'twilio_messaging_service_sid', 'Messaging Service SID', 'text', 'Starts with MG. The service linked to your A2P campaign.' );
								self::field( 'twilio_api_key_sid', 'API Key SID', 'text', 'Starts with SK.' );
								self::field( 'twilio_api_key_secret', 'API Key secret', 'secret' );
								self::field( 'twilio_from_number', 'From number', 'text', 'Only used when no Messaging Service SID is set.' );
								?>
							</div>
						</div>
					</section>

					<section class="dimrr-panel" data-panel="limits">
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Limits &amp; links</h2>
							<div class="dimrr-grid-2">
								<?php
								self::field( 'cooldown_days', 'Don\'t ask the same person again for (days)', 'number', '', array( 'attrs' => 'min="0" max="3650"' ) );
								self::field( 'daily_limit', 'Daily limit, whole site', 'number', 'Caps cost if a login is ever misused.', array( 'attrs' => 'min="1"' ) );
								self::field( 'user_hourly_limit', 'Hourly limit per staff login', 'number', '', array( 'attrs' => 'min="1"' ) );
								self::field( 'link_mode', 'Link in texts & emails', 'select', 'The branded link shows this website\'s domain and records who opened it.', array( 'options' => array( 'branded' => 'Branded link on this site (recommended)', 'direct' => 'Direct Google link' ) ) );
								self::field( 'branded_slug', 'Branded link path', 'text', 'QR codes use <code>' . esc_html( home_url( '/' . $s['branded_slug'] . '/{location}/' ) ) . '</code>; messages use a short tracked link like <code>' . esc_html( home_url( '/' . $s['branded_slug'] . '/Ab3dE7gH/' ) ) . '</code>.' );
								?>
							</div>
						</div>
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Staff send page</h2>
							<p class="dimrr-help">Front-desk staff (role "Review Request Sender") sign in on this page and never see the WordPress dashboard. If they open wp-admin, they are sent back here. Admins and editors are not affected.</p>
							<?php
							$page_id = (int) $s['sender_page_id'];
							$page_ok = $page_id && 'publish' === get_post_status( $page_id );
							?>
							<div class="dimrr-field">
								<label for="dim-rr-sender_page_id">Page</label>
								<?php
								wp_dropdown_pages(
									array(
										'name'              => self::name( 'sender_page_id' ),
										'id'                => 'dim-rr-sender_page_id',
										'selected'          => $page_id,
										'show_option_none'  => '— None (staff use the send screen in wp-admin) —',
										'option_none_value' => '0',
									)
								); // phpcs:ignore
								?>
								<p class="dimrr-help">
									<?php if ( $page_ok ) : ?>
										Staff page: <a href="<?php echo esc_url( get_permalink( $page_id ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( get_permalink( $page_id ) ); ?></a>. Give staff this address and bookmark it on the front-desk computer.
									<?php else : ?>
										<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=dim_rr_create_page&type=sender' ), 'dim_rr_create_page_sender' ) ); ?>">Create the staff page for me</a> (a hidden, noindexed page containing <code>[dim_review_sender]</code>).
									<?php endif; ?>
								</p>
							</div>
						</div>
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Problem alerts</h2>
							<p class="dimrr-help">Failed sends always show on the send screen, in Activity and on the WordPress dashboard. Alerts email you only for problems that stop <em>every</em> text (bad API key, unregistered number, carrier spam blocking, empty sender pool, email not sending), at most once every 6 hours per problem.</p>
							<div class="dimrr-grid-2">
								<?php self::field( 'alert_email', 'Send alerts to', 'email', 'e.g. your agency support inbox. Blank = no alert emails.' ); ?>
							</div>
						</div>
					</section>

					<div class="dimrr-savebar" data-savebar><?php submit_button( 'Save settings', 'primary', 'submit', false ); ?></div>
				</form>

				<section class="dimrr-panel" data-panel="tools">
					<div class="dimrr-grid-2">
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Export settings</h2>
							<p class="dimrr-help">Download this site's setup as a file to reuse on another client site. Twilio details, email sender addresses, privacy/terms links and the alert email are never included.</p>
							<div class="dimrr-actions">
								<a class="dimrr-btn is-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=dim_rr_export&full=1' ), 'dim_rr_export' ) ); ?>">Export everything</a>
								<a class="dimrr-btn" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=dim_rr_export&full=0' ), 'dim_rr_export' ) ); ?>">Export style &amp; wording only</a>
							</div>
							<p class="dimrr-help">"Style &amp; wording only" leaves out the business name, logo, locations and contact details, so it works as a starting template for a new client.</p>
						</div>
						<div class="dimrr-card">
							<h2 class="dimrr-h2">Import settings</h2>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
								<input type="hidden" name="action" value="dim_rr_import">
								<?php wp_nonce_field( 'dim_rr_import' ); ?>
								<div class="dimrr-field">
									<label for="dimrr-import-file">Export file (.json)</label>
									<input type="file" id="dimrr-import-file" name="dimrr_file" accept=".json,application/json">
								</div>
								<label class="dimrr-check"><input type="checkbox" name="dimrr_keep_locations" value="1" checked> Keep this site's existing locations and business details</label>
								<button type="submit" class="dimrr-btn is-primary">Import</button>
							</form>
						</div>
					</div>
									<?php self::removal_checklist(); ?>
				</section>
			</div>
		</div>
		<?php
	}

	private static function email_preview( $locs ) {
		if ( ! $locs || empty( $locs[0]['name'] ) || ! DIM_RR_Settings::location() ) {
			return;
		}
		?>
		<details class="dimrr-card dimrr-email-preview">
			<summary>Preview the email <span class="dimrr-opt">saved settings, first location. Save to refresh.</span></summary>
			<iframe title="Email preview" sandbox="" srcdoc="<?php echo esc_attr( DIM_RR_Email::html( array( 'first_name' => 'Jane', 'link' => '#', 'location' => DIM_RR_Settings::location() ) ) ); ?>"></iframe>
		</details>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* Import / export                                                    */
	/* ------------------------------------------------------------------ */

	/** Pages the plugin can create, keyed by type. */
	const PAGE_TYPES = array(
		'sender' => array( 'title' => 'Review Requests', 'slug' => 'staff-review-requests', 'code' => '[dim_review_sender]', 'setting' => 'sender_page_id' ),
		'review' => array( 'title' => 'Leave a Review', 'slug' => 'leave-a-review', 'code' => '[dim_review_page]', 'setting' => '' ),
		'terms'  => array( 'title' => 'SMS Terms', 'slug' => 'sms-terms', 'code' => '[dim_sms_terms]', 'setting' => 'terms_url' ),
	);

	public static function create_sender_page() {
		$_GET['type'] = 'sender'; // Back-compat with the 2.1.0 link.
		self::create_page();
	}

	/**
	 * Create one of the plugin's pages. Pages are remembered so they can be
	 * removed automatically if the plugin is ever deleted.
	 */
	public static function create_page() {
		$type  = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '';
		$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
		$valid = isset( self::PAGE_TYPES[ $type ] ) && ( wp_verify_nonce( $nonce, 'dim_rr_create_page_' . $type ) || ( 'sender' === $type && wp_verify_nonce( $nonce, 'dim_rr_create_sender_page' ) ) );
		if ( ! current_user_can( 'manage_options' ) || ! $valid ) {
			wp_die( 'Not allowed.' );
		}
		$def  = self::PAGE_TYPES[ $type ];
		$slug = $def['slug'];
		$args = array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'post_title'     => $def['title'],
			'post_name'      => get_page_by_path( $slug ) ? $slug . '-' . wp_generate_password( 4, false, false ) : $slug,
			'post_content'   => "<!-- wp:shortcode -->\n" . $def['code'] . "\n<!-- /wp:shortcode -->",
			'comment_status' => 'closed',
			'ping_status'    => 'closed',
		);
		if ( 'terms' === $type ) {
			$legal = get_page_by_path( 'legal' );
			if ( $legal ) {
				$args['post_parent'] = $legal->ID;
			}
		}
		$id = wp_insert_post( $args, true );
		if ( ! is_wp_error( $id ) ) {
			if ( 'sender' === $type ) {
				update_post_meta( $id, 'rank_math_robots', array( 'noindex', 'nofollow' ) ); // Rank Math: noindex + out of sitemap.
				update_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', '1' );
				// GeneratePress: a clean, app-like page (no sidebar, header, menu, title or footer).
				update_post_meta( $id, '_generate-sidebar-layout-meta', 'no-sidebar' );
				foreach ( array( '_generate-disable-top-bar', '_generate-disable-header', '_generate-disable-nav', '_generate-disable-headline', '_generate-disable-footer', '_generate-disable-post-image' ) as $gp_key ) {
					update_post_meta( $id, $gp_key, 'true' );
				}
				update_post_meta( $id, '_generate-footer-widget-meta', '0' );
			}
			update_post_meta( $id, '_dim_rr_page', $type ); // Marks it as a plugin page.
			$created   = (array) get_option( 'dim_rr_created_pages', array() );
			$created[] = (int) $id;
			update_option( 'dim_rr_created_pages', array_values( array_unique( array_map( 'intval', $created ) ) ), false );
			if ( $def['setting'] ) {
				$opt                     = get_option( DIM_RR_Settings::OPTION );
				$opt[ $def['setting'] ] = 'terms_url' === $def['setting'] ? get_permalink( $id ) : (int) $id;
				DIM_RR_Settings::raw_update( $opt );
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=dim-review-settings' ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Setup checklist & removal                                          */
	/* ------------------------------------------------------------------ */

	/**
	 * Published pages that use one of this plugin's shortcodes.
	 *
	 * @return array<int,array{id:int,title:string,url:string,only:bool,code:string}>
	 */
	public static function plugin_pages() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT ID, post_title, post_content, post_status FROM {$wpdb->posts} WHERE post_type IN ('page','post') AND post_status IN ('publish','draft','private','pending','future') AND post_content LIKE '%[dim\\_%'" ); // phpcs:ignore
		$out  = array();
		foreach ( (array) $rows as $r ) {
			if ( ! preg_match( '/\[(dim_review_page|dim_review_sender|dim_sms_terms|dim_sms_privacy)\b/', $r->post_content, $m ) ) {
				continue;
			}
			$out[] = array(
				'id'     => (int) $r->ID,
				'title'  => $r->post_title,
				'url'    => get_permalink( $r->ID ),
				'status' => $r->post_status,
				'only'   => self::only_shortcode( $r->post_content ),
				'code'   => $m[1],
			);
		}
		return $out;
	}

	/** True when the page contains nothing but one of our shortcodes. */
	public static function only_shortcode( $content ) {
		$c = preg_replace( '/<!--.*?-->/s', '', (string) $content );
		$c = trim( wp_strip_all_tags( $c ) );
		return (bool) preg_match( '/^\[dim_[a-z_]+[^\]]*\]$/', $c );
	}

	private static function step( $done, $label, $detail = '', $action = '' ) {
		echo '<li class="dimrr-step ' . ( $done ? 'is-done' : 'is-todo' ) . '"><span class="dimrr-step-dot">' . ( $done ? '&#10003;' : '' ) . '</span><div><strong>' . esc_html( $label ) . '</strong>' . ( $detail ? '<span>' . wp_kses_post( $detail ) . '</span>' : '' ) . '</div>' . ( $action && ! $done ? '<div class="dimrr-step-action">' . $action . '</div>' : '' ) . '</li>'; // phpcs:ignore
	}

	public static function setup_checklist() {
		global $wpdb;
		$s     = DIM_RR_Settings::all();
		$locs  = array_filter(
			DIM_RR_Settings::locations(),
			function ( $l ) {
				return ! empty( $l['review_url'] );
			}
		);
		$pages = self::plugin_pages();
		$has   = function ( $code ) use ( $pages ) {
			foreach ( $pages as $p ) {
				if ( $code === $p['code'] && 'publish' === $p['status'] ) {
					return $p;
				}
			}
			return null;
		};
		$smtp     = class_exists( 'WPMailSMTP\Core' ) || defined( 'WPMS_PLUGIN_VER' ) || defined( 'FLUENTMAIL' ) || defined( 'POST_SMTP_VER' ) || class_exists( 'PostmanOptions' ) || class_exists( 'Easy_WP_SMTP' );
		$staff    = count( get_users( array( 'role' => 'dim_review_sender', 'fields' => 'ID' ) ) );
		$t        = DIM_RR_Log::table();
		$sms_ok   = (bool) $wpdb->get_var( "SELECT id FROM {$t} WHERE channel='sms' AND status IN ('delivered','read') LIMIT 1" ); // phpcs:ignore
		$mail_ok  = (bool) $wpdb->get_var( "SELECT id FROM {$t} WHERE channel='email' AND status='sent' LIMIT 1" ); // phpcs:ignore
		$old      = false;
		foreach ( array( 'googlereviews.php', 'googlereviews-gp.php', 'googlereviews-gr.php', 'sendmail.php', 'sendmail-gp.php', 'sendmail-gr.php', 'twilio' ) as $f ) {
			$old = $old || file_exists( ABSPATH . $f );
		}
		$mk = function ( $type, $label ) {
			return '<a class="dimrr-btn" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=dim_rr_create_page&type=' . $type ), 'dim_rr_create_page_' . $type ) ) . '">' . esc_html( $label ) . '</a>';
		};
		$tab = function ( $tab, $label ) {
			return '<a class="dimrr-btn" href="#' . esc_attr( $tab ) . '" data-goto-tab="' . esc_attr( $tab ) . '">' . esc_html( $label ) . '</a>';
		};
		$review = $has( 'dim_review_page' );
		$sender = DIM_RR_Settings::sender_page_url();
		$steps  = array(
			array( $s['business_name'] && $s['logo_url'] && ! preg_match( '/\.svg(\?|$)/i', $s['logo_url'] ), 'Business name and PNG/JPG logo', '', $tab( 'brand', 'Brand & style' ) ),
			array( (bool) $locs, 'At least one location with its Google review link', $locs ? count( $locs ) . ' location(s)' : '', $tab( 'locations', 'Add location' ) ),
			array( DIM_RR_Settings::twilio_ready(), 'Twilio connected', DIM_RR_Settings::is_constant( 'twilio_api_key_secret' ) ? 'Restricted key in wp-config.php' : ( DIM_RR_Settings::twilio_ready() ? 'Saved in settings (wp-config.php is safer)' : '' ), $tab( 'twilio', 'Twilio' ) ),
			array( $smtp, 'Email sending plugin (WP Mail SMTP) active', '', '' ),
			array( (bool) $s['alert_email'], 'Problem alert email set', $s['alert_email'] ? esc_html( $s['alert_email'] ) : '', $tab( 'limits', 'Limits & alerts' ) ),
			array( (bool) $s['privacy_url'], 'Privacy policy linked (with the SMS wording added)', '', $tab( 'locations', 'Business' ) ),
			array( (bool) $s['terms_url'], 'SMS terms page', $s['terms_url'] ? '<a href="' . esc_url( $s['terms_url'] ) . '" target="_blank">' . esc_html( $s['terms_url'] ) . '</a>' : '', $mk( 'terms', 'Create SMS terms page' ) ),
			array( (bool) $review, 'Public "Leave a Review" page', $review ? '<a href="' . esc_url( $review['url'] ) . '" target="_blank">' . esc_html( $review['url'] ) . '</a>' : '', $mk( 'review', 'Create review page' ) ),
			array( (bool) $sender, 'Staff send page', $sender ? '<a href="' . esc_url( $sender ) . '" target="_blank">' . esc_html( $sender ) . '</a>' : '', $mk( 'sender', 'Create staff page' ) ),
			array( $staff > 0, 'Staff login(s) with the "Review Request Sender" role', $staff ? $staff . ' login(s)' : 'Users &gt; Add New. Leave "Send the new user an email" unticked.', '<a class="dimrr-btn" href="' . esc_url( admin_url( 'user-new.php' ) ) . '">Add user</a>' ),
			array( $sms_ok && $mail_ok, 'Test text delivered and test email sent', ( $sms_ok ? 'Text ✓ ' : 'Text pending · ' ) . ( $mail_ok ? 'Email ✓' : 'Email pending' ), '<a class="dimrr-btn" href="' . esc_url( admin_url( 'admin.php?page=dim-review-requests' ) ) . '">Send a test</a>' ),
			array( ! $old, 'Old review files removed from the server', $old ? 'See Diagnostics for the list.' : '', '' ),
		);
		$done = count( array_filter( wp_list_pluck( $steps, 0 ) ) );
		?>
		<details class="dimrr-card dimrr-setup" <?php echo $done < count( $steps ) ? 'open' : ''; ?>>
			<summary><span class="dimrr-h2">Setup checklist</span> <span class="dimrr-pill <?php echo $done === count( $steps ) ? 'is-good' : ''; ?>"><?php echo (int) $done; ?> of <?php echo count( $steps ); ?> done</span></summary>
			<ol class="dimrr-steps">
				<?php
				foreach ( $steps as $st ) {
					self::step( $st[0], $st[1], $st[2], $st[3] );
				}
				?>
			</ol>
		</details>
		<?php
	}

	/**
	 * Admin-post: move the plugin's pages to the Trash (removal checklist).
	 */
	public static function trash_pages() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dim_rr_trash_pages' ) ) {
			wp_die( 'Not allowed.' );
		}
		$ids = isset( $_POST['page_ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['page_ids'] ) ) : array();
		foreach ( self::plugin_pages() as $p ) {
			if ( in_array( $p['id'], $ids, true ) ) {
				wp_trash_post( $p['id'] );
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=dim-review-settings#tools' ) );
		exit;
	}

	public static function removal_checklist() {
		$pages = self::plugin_pages();
		$staff = get_users( array( 'role' => 'dim_review_sender' ) );
		$consts = array();
		foreach ( DIM_RR_Settings::CONSTANTS as $c ) {
			if ( defined( $c ) ) {
				$consts[] = $c;
			}
		}
		?>
		<div class="dimrr-card">
			<h2 class="dimrr-h2">Remove from this site</h2>
			<p class="dimrr-help">Use this when you stop providing the service. Work down the list, then go to Plugins, <strong>Deactivate</strong> and <strong>Delete</strong> the plugin. Deleting removes its settings, send log, staff role and any page that contains only one of its shortcodes. To update the plugin, use "Replace current with uploaded" instead; never delete it to update, or the settings are lost.</p>
			<ol class="dimrr-steps">
				<li class="dimrr-step is-todo"><span class="dimrr-step-dot">1</span><div><strong>Pages that use the plugin</strong>
					<?php if ( $pages ) : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Move the selected pages to the Trash? You can restore them from Pages > Trash.');">
							<input type="hidden" name="action" value="dim_rr_trash_pages">
							<?php wp_nonce_field( 'dim_rr_trash_pages' ); ?>
							<ul class="dimrr-plainlist">
							<?php foreach ( $pages as $p ) : ?>
								<li><label><input type="checkbox" name="page_ids[]" value="<?php echo (int) $p['id']; ?>" <?php checked( $p['only'] ); ?>> <a href="<?php echo esc_url( get_edit_post_link( $p['id'] ) ); ?>"><?php echo esc_html( $p['title'] ); ?></a> <code><?php echo esc_html( '[' . $p['code'] . ']' ); ?></code> <?php echo $p['only'] ? '' : '<em>also has other content: remove just the shortcode instead</em>'; ?></label></li>
							<?php endforeach; ?>
							</ul>
							<button class="dimrr-btn">Move selected to Trash</button>
						</form>
					<?php else : ?>
						<span>None found.</span>
					<?php endif; ?>
					<span>Also remove any menu links to these pages, and set up a redirect (e.g. Rank Math &gt; Redirections) if the review page was shared publicly.</span>
				</div></li>
				<li class="dimrr-step is-todo"><span class="dimrr-step-dot">2</span><div><strong>Staff logins</strong>
					<span><?php echo $staff ? esc_html( count( $staff ) . ' login(s) with the Review Request Sender role: ' . implode( ', ', wp_list_pluck( $staff, 'user_login' ) ) . '. Deleting the plugin removes these logins automatically (they own no content).' ) : 'None.'; ?></span>
				</div></li>
				<li class="dimrr-step is-todo"><span class="dimrr-step-dot">3</span><div><strong>Twilio key</strong>
					<span><?php echo $consts ? 'Remove these lines from wp-config.php (WP File Manager or SFTP): <code>' . esc_html( implode( '</code> <code>', $consts ) ) . '</code>.' : 'Nothing in wp-config.php.'; ?> Then revoke this site's API key in Twilio Console &gt; API keys &amp; tokens<?php echo DIM_RR_Settings::get( 'twilio_api_key_sid' ) ? ' (<code>' . esc_html( substr( DIM_RR_Settings::get( 'twilio_api_key_sid' ), 0, 10 ) ) . '…</code>)' : ''; ?>.</span>
				</div></li>
				<li class="dimrr-step is-todo"><span class="dimrr-step-dot">4</span><div><strong>Privacy policy</strong><span>If you added review-request or SMS wording to the client's privacy policy for this service, remove it.</span></div></li>
				<li class="dimrr-step is-todo"><span class="dimrr-step-dot">5</span><div><strong>Deactivate and Delete the plugin</strong><span>Plugins &gt; DIM Review Requests &gt; Deactivate &gt; Delete. Its database table, settings, scheduled alerts and rewrite rules are removed automatically. Nothing else on the site depends on it.</span></div></li>
			</ol>
		</div>
		<?php
	}

		public static function handle_export() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dim_rr_export' ) ) {
			wp_die( 'Not allowed.' );
		}
		$full = ! empty( $_GET['full'] );
		$host = preg_replace( '/[^a-z0-9.-]/', '', strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="review-requests-' . $host . ( $full ? '' : '-template' ) . '-' . gmdate( 'Y-m-d' ) . '.json"' );
		echo wp_json_encode( DIM_RR_Settings::export_data( $full ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		exit;
	}

	public static function handle_import() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dim_rr_import' ) ) {
			wp_die( 'Not allowed.' );
		}
		$back = admin_url( 'admin.php?page=dim-review-settings' );
		$raw  = '';
		if ( ! empty( $_FILES['dimrr_file']['tmp_name'] ) && is_uploaded_file( $_FILES['dimrr_file']['tmp_name'] ) ) { // phpcs:ignore
			$raw = file_get_contents( $_FILES['dimrr_file']['tmp_name'] ); // phpcs:ignore
		}
		$data = json_decode( (string) $raw, true );
		if ( ! is_array( $data ) || ( isset( $data['plugin'] ) && 'dim-review-requests' !== $data['plugin'] ) || empty( $data['settings'] ) || ! is_array( $data['settings'] ) ) {
			wp_safe_redirect( add_query_arg( 'dimrr_notice', 'import_error', $back ) );
			exit;
		}
		$in   = $data['settings'];
		$keep = ! empty( $_POST['dimrr_keep_locations'] );
		$cur  = get_option( DIM_RR_Settings::OPTION );
		$cur  = is_array( $cur ) ? $cur : array();
		// Never import another site's sending setup (Twilio, From/Reply-To, legal pages, alerts).
		foreach ( DIM_RR_Settings::SITE_ONLY as $k ) {
			unset( $in[ $k ] );
		}
		if ( $keep ) {
			foreach ( DIM_RR_Settings::CLIENT_FIELDS as $k ) {
				unset( $in[ $k ] );
			}
		}
		$in['_form'] = 1;
		foreach ( array( 'show_credit', 'lookup_line_type', 'show_stars', 'show_socials', 'brand_login' ) as $k ) {
			if ( ! isset( $in[ $k ] ) && isset( $cur[ $k ] ) ) {
				$in[ $k ] = $cur[ $k ];
			}
		}
		if ( isset( $in['locations'] ) ) {
			$in['locations'] = array_values( (array) $in['locations'] );
		}
		update_option( DIM_RR_Settings::OPTION, wp_slash( $in ) );
		wp_safe_redirect( add_query_arg( 'dimrr_notice', 'imported', $back ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Diagnostics                                                        */
	/* ------------------------------------------------------------------ */

	private static function row( $state, $label, $detail = '' ) {
		$icons = array( 'ok' => '&#10003;', 'warn' => '!', 'bad' => '&#10007;', 'info' => 'i' );
		echo '<li class="dimrr-check-row is-' . esc_attr( $state ) . '"><span class="dimrr-dot">' . $icons[ $state ] . '</span><div><strong>' . esc_html( $label ) . '</strong>' . ( $detail ? '<p>' . wp_kses_post( $detail ) . '</p>' : '' ) . '</div></li>'; // phpcs:ignore
	}

	public static function page_diagnostics() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s      = DIM_RR_Settings::all();
		$locs   = DIM_RR_Settings::locations();
		$action = isset( $_POST['dim_rr_diag'] ) ? sanitize_key( wp_unslash( $_POST['dim_rr_diag'] ) ) : '';
		if ( $action ) {
			check_admin_referer( 'dim_rr_diag' );
		}
		$host = preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		?>
		<div class="wrap dimrr-wrap">
			<div class="dimrr-app">
				<header class="dimrr-top"><div><h1 class="dimrr-title">Diagnostics</h1><p class="dimrr-sub">Setup checks and live tests.</p></div></header>
				<div class="dimrr-card">
					<h2 class="dimrr-h2">Setup checks</h2>
					<ul class="dimrr-checks">
					<?php
					if ( ! $locs ) {
						self::row( 'bad', 'Locations', 'No locations set up.' );
					}
					foreach ( $locs as $loc ) {
						$rhost = strtolower( (string) wp_parse_url( $loc['review_url'], PHP_URL_HOST ) );
						if ( $loc['review_url'] && ! preg_match( '/(^|\.)(g\.page|google\.com|goo\.gl|g\.co)$/', $rhost ) ) {
							self::row( 'warn', 'Review link for ' . $loc['name'] . ' is not a Google address', esc_html( $loc['review_url'] ) . ' Double-check it was pasted from Google Business Profile.' );
						}
						self::row( $loc['review_url'] ? 'ok' : 'bad', 'Location: ' . $loc['name'], $loc['review_url'] ? esc_html( $loc['review_url'] ) . '<br>Branded link: <code>' . esc_html( DIM_RR_Settings::review_link( $loc ) ) . '</code>' : 'No Google review link.' );
					}
					self::row( is_ssl() ? 'ok' : 'warn', 'HTTPS', is_ssl() ? '' : 'Twilio status callbacks and branded links need HTTPS.' );
					$logo_ok = $s['logo_url'] && ! preg_match( '/\.svg(\?|$)/i', $s['logo_url'] );
					self::row( $logo_ok ? 'ok' : 'warn', 'Email logo', $logo_ok ? '' : 'Use a PNG or JPG. SVG does not show in Gmail or Outlook.' );

					$smtp = class_exists( 'WPMailSMTP\Core' ) || defined( 'WPMS_PLUGIN_VER' ) || defined( 'FLUENTMAIL' ) || defined( 'POST_SMTP_VER' ) || class_exists( 'PostmanOptions' ) || class_exists( 'Easy_WP_SMTP' );
					self::row( $smtp ? 'ok' : 'bad', 'SMTP plugin', $smtp ? 'Active. Use its Email Test and confirm SPF, DKIM and DMARC pass.' : 'No SMTP plugin found. Emails go through the server\'s PHP mail() and often land in spam.' );
					if ( $s['from_email'] ) {
						$dom = strtolower( substr( strrchr( $s['from_email'], '@' ), 1 ) );
						self::row( $dom === strtolower( $host ) ? 'ok' : 'warn', 'From domain', esc_html( $s['from_email'] ) . ( $dom === strtolower( $host ) ? '' : ' is not on ' . esc_html( $host ) . '. Make sure your SMTP service is authorized for ' . esc_html( $dom ) . '.' ) );
					}
					self::row( DIM_RR_Settings::twilio_ready() ? 'ok' : 'bad', 'Twilio settings', DIM_RR_Settings::twilio_ready() ? ( DIM_RR_Settings::is_constant( 'twilio_api_key_secret' ) ? 'Credentials are in wp-config.php.' : 'Saved in the database. wp-config.php is safer.' ) : 'Account SID, API Key, secret and a Messaging Service (or From number) are required.' );
					if ( 0 === strpos( (string) $s['twilio_api_key_sid'], 'AC' ) ) {
						self::row( 'warn', 'Using the main Twilio Auth Token', 'This works, but the same token is on every site. Create a Restricted API Key for this website and replace it.' );
					}
					self::row( false !== stripos( $s['sms_template'], 'STOP' ) ? 'ok' : 'warn', 'Opt-out wording', false !== stripos( $s['sms_template'], 'STOP' ) ? '' : 'Add "Reply STOP to opt out" to the text.' );
					self::row( ! empty( $s['lookup_line_type'] ) ? 'ok' : 'warn', 'Landline check', ! empty( $s['lookup_line_type'] ) ? 'On.' : 'Off. Texts to landlines (error 30006) will keep failing.' );
					foreach ( array( 'googlereviews.php', 'googlereviews-gp.php', 'googlereviews-gr.php', 'sendmail.php', 'sendmail-gp.php', 'sendmail-gr.php', 'twilio' ) as $old ) {
						if ( file_exists( ABSPATH . $old ) ) {
							self::row( 'bad', 'Old file still on the server: ' . $old, 'Public and unprotected. Delete it once this plugin is working.' );
						}
					}
					$m = class_exists( 'DIM_RR_Updater' ) ? DIM_RR_Updater::manifest() : null;
					if ( ! $m ) {
						self::row( 'warn', 'Updates', 'Could not reach the DIM update server just now. Updates will be checked again automatically.' );
					} elseif ( version_compare( $m['version'], DIM_RR_VERSION, '>' ) ) {
						self::row( 'warn', 'Updates', 'Version ' . esc_html( $m['version'] ) . ' is available (this site has ' . esc_html( DIM_RR_VERSION ) . '). Go to Plugins and click Update now.' );
					} else {
						self::row( 'ok', 'Updates', 'Up to date (version ' . esc_html( DIM_RR_VERSION ) . '). One-click updates are on.' );
					}
					self::row( 'info', 'Delivery status webhook', 'Twilio posts results to <code>/wp-json/dim-rr/v1/status</code>. If a security plugin blocks the REST API for visitors, allow that path.' );
					?>
					</ul>
				</div>

				<div class="dimrr-card">
					<h2 class="dimrr-h2">Live tests</h2>
					<form method="post" class="dimrr-actions">
						<?php wp_nonce_field( 'dim_rr_diag' ); ?>
						<button class="dimrr-btn is-primary" name="dim_rr_diag" value="twilio">Check Twilio &amp; A2P</button>
						<button class="dimrr-btn" name="dim_rr_diag" value="failures">Recent failed texts</button>
						<button class="dimrr-btn" name="dim_rr_diag" value="email">Send me a test email</button>
						<button class="dimrr-btn" name="dim_rr_diag" value="secret" title="Use if the Twilio account was shared or exposed">Reset webhook secret</button>
					</form>
					<?php
					if ( 'twilio' === $action ) {
						self::diag_twilio();
					} elseif ( 'failures' === $action ) {
						self::diag_failures();
					} elseif ( 'secret' === $action ) {
						$opt                    = get_option( DIM_RR_Settings::OPTION );
						$opt['callback_secret'] = wp_generate_password( 32, false, false );
						DIM_RR_Settings::raw_update( $opt );
						echo '<div class="dimrr-alert is-success">Webhook secret reset. New texts use the new secret. Delivery updates for texts sent before now will no longer be recorded.</div>';
					} elseif ( 'email' === $action && $locs ) {
						$u = wp_get_current_user();
						$r = DIM_RR_Email::send( $u->user_email, $u->first_name, DIM_RR_Settings::location(), '' );
						echo '<div class="dimrr-alert ' . ( $r['ok'] ? 'is-success' : 'is-error' ) . '">' . esc_html( $r['ok'] ? 'Test email sent to ' . $u->user_email . '. Check inbox and spam. In Gmail, "Show original" should say PASS for SPF, DKIM and DMARC.' : 'Failed: ' . $r['error'] ) . '</div>';
					}
					?>
				</div>
			</div>
		</div>
		<?php
	}

	private static function diag_twilio() {
		if ( ! DIM_RR_Settings::twilio_ready() ) {
			echo '<div class="dimrr-alert is-error">Finish the Twilio settings first.</div>';
			return;
		}
		echo '<ul class="dimrr-checks">';
		$acct       = DIM_RR_Twilio::account();
		$restricted = ! $acct['ok'] && false !== stripos( (string) $acct['error_message'], 'permission' );
		if ( ! $acct['ok'] && ! $restricted ) {
			self::row( 'bad', 'Login', esc_html( DIM_RR_Twilio::explain( $acct['error_code'], $acct['error_message'] ) ) );
			echo '</ul>';
			return;
		}
		if ( $restricted ) {
			// A Restricted API key normally can't read account details; that's expected.
			self::row( 'ok', 'Login', 'Restricted API key accepted (it can\'t read account details, which is expected).' );
		} else {
			$status = isset( $acct['body']['status'] ) ? $acct['body']['status'] : '';
			self::row( 'active' === $status ? 'ok' : 'bad', 'Account', esc_html( ( isset( $acct['body']['friendly_name'] ) ? $acct['body']['friendly_name'] : '' ) . ' (' . $status . ')' ) );
		}
		$s = DIM_RR_Settings::all();
		if ( $s['twilio_messaging_service_sid'] ) {
			$svc = DIM_RR_Twilio::messaging_service();
			self::row( $svc['ok'] ? 'ok' : 'bad', 'Messaging Service', $svc['ok'] ? esc_html( isset( $svc['body']['friendly_name'] ) ? $svc['body']['friendly_name'] : $s['twilio_messaging_service_sid'] ) : esc_html( DIM_RR_Twilio::explain( $svc['error_code'], $svc['error_message'] ) ) );
			$nums = DIM_RR_Twilio::messaging_service_numbers();
			if ( $nums['ok'] ) {
				$list = array();
				foreach ( (array) ( isset( $nums['body']['phone_numbers'] ) ? $nums['body']['phone_numbers'] : array() ) as $n ) {
					if ( isset( $n['phone_number'] ) ) {
						$list[] = $n['phone_number'];
					}
				}
				self::row( $list ? 'ok' : 'bad', 'Sender pool', $list ? esc_html( implode( ', ', $list ) ) : 'No numbers in this Messaging Service.' );
			}
			$camp = DIM_RR_Twilio::a2p_campaigns();
			if ( $camp['ok'] ) {
				$items = isset( $camp['body']['compliance'] ) ? $camp['body']['compliance'] : array();
				if ( ! $items ) {
					self::row( 'bad', 'A2P 10DLC campaign', 'None attached. US carriers block unregistered texts (30034).' );
				}
				foreach ( $items as $c ) {
					$cs = isset( $c['campaign_status'] ) ? $c['campaign_status'] : 'unknown';
					self::row( 'VERIFIED' === strtoupper( $cs ) ? 'ok' : 'bad', 'A2P 10DLC campaign', esc_html( ( isset( $c['us_app_to_person_usecase'] ) ? $c['us_app_to_person_usecase'] : '' ) . ': ' . $cs ) );
				}
			} else {
				self::row( 'warn', 'A2P 10DLC campaign', 'Could not read campaign status (a Restricted key may not allow it). Check in Twilio Console.' );
			}
		}
		echo '</ul>';
	}

	private static function diag_failures() {
		if ( ! DIM_RR_Settings::twilio_ready() ) {
			echo '<div class="dimrr-alert is-error">Finish the Twilio settings first.</div>';
			return;
		}
		$r = DIM_RR_Twilio::recent_messages( 200 );
		if ( ! $r['ok'] ) {
			echo '<div class="dimrr-alert is-error">' . esc_html( DIM_RR_Twilio::explain( $r['error_code'], $r['error_message'] ) ) . '</div>';
			return;
		}
		$counts = array();
		$total  = 0;
		foreach ( (array) ( isset( $r['body']['messages'] ) ? $r['body']['messages'] : array() ) as $m ) {
			if ( ! is_array( $m ) || ! isset( $m['direction'], $m['status'] ) || 'outbound-api' !== $m['direction'] ) {
				continue;
			}
			$total++;
			if ( in_array( $m['status'], array( 'failed', 'undelivered' ), true ) ) {
				$code            = isset( $m['error_code'] ) ? (string) $m['error_code'] : '';
				$counts[ $code ] = isset( $counts[ $code ] ) ? $counts[ $code ] + 1 : 1;
			}
		}
		arsort( $counts );
		echo '<p><strong>Last ' . (int) $total . ' outgoing texts in this Twilio account</strong> (includes every site that shares the account).</p>';
		if ( ! $counts ) {
			echo '<p>No failed or undelivered texts.</p>';
			return;
		}
		echo '<table class="dimrr-table"><thead><tr><th>Error</th><th>Count</th><th>What it means</th></tr></thead><tbody>';
		foreach ( $counts as $code => $n ) {
			echo '<tr><td><a href="https://www.twilio.com/docs/api/errors/' . esc_attr( $code ) . '" target="_blank" rel="noopener">' . esc_html( $code ) . '</a></td><td>' . (int) $n . '</td><td>' . esc_html( DIM_RR_Twilio::explain( $code ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}
}
