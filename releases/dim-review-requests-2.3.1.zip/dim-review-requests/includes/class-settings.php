<?php
/**
 * Settings storage, defaults, locations, credentials and message templating.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Settings {

	const OPTION = 'dim_rr_settings';

	/**
	 * Credentials that can live in wp-config.php instead of the database.
	 * Constants always win over saved settings.
	 */
	const CONSTANTS = array(
		'twilio_account_sid'           => 'DIM_RR_TWILIO_ACCOUNT_SID',
		'twilio_api_key_sid'           => 'DIM_RR_TWILIO_API_KEY_SID',
		'twilio_api_key_secret'        => 'DIM_RR_TWILIO_API_KEY_SECRET',
		'twilio_messaging_service_sid' => 'DIM_RR_TWILIO_MESSAGING_SERVICE_SID',
		'twilio_from_number'           => 'DIM_RR_TWILIO_FROM_NUMBER',
	);

	const LOCATION_FIELDS = array( 'slug', 'name', 'sms_name', 'review_url', 'map_embed_url', 'address', 'phone', 'feedback_url', 'reply_to' );

	const SOCIALS = array(
		'facebook'  => 'Facebook',
		'instagram' => 'Instagram',
		'youtube'   => 'YouTube',
		'linkedin'  => 'LinkedIn',
		'x'         => 'X',
		'tiktok'    => 'TikTok',
		'nextdoor'  => 'Nextdoor',
		'houzz'     => 'Houzz',
		'yelp'      => 'Yelp',
		'bbb'       => 'BBB',
	);

	const COLOR_KEYS = array( 'brand_color', 'accent_color', 'header_bg_color', 'email_bg_color', 'star_color' );

	public static function defaults() {
		return array(
			// Business.
			'business_name'     => get_bloginfo( 'name' ),
			'audience'          => 'customer', // customer | patient | client.
			'website_url'       => home_url( '/' ),
			'business_phone'    => '',
			'business_email'    => '',
			'signoff'           => "Thank you,\nThe {business} team",
			'footer_note'       => 'You are receiving this one-time email because you recently worked with {business}.',
			'socials'           => array(),
			'show_socials'      => 1,
			'privacy_url'       => '',
			'terms_url'         => '',
			'alert_email'       => '',
			'sender_page_id'    => 0,
			'brand_login'       => 1,

			// Brand & style.
			'logo_url'          => '',
			'logo_id'           => 0,
			'email_logo_url'    => '',
			'logo_width'        => 200,
			'brand_color'       => '#1a73e8', // Buttons.
			'button_text'       => 'auto',    // auto | light | dark.
			'accent_color'      => '',        // Top bar + links. Blank = brand color.
			'header_style'      => 'white',   // white | color.
			'header_bg_color'   => '',        // Blank = brand color.
			'email_bg_color'    => '#f1f3f4',
			'star_color'        => '#fbbc04',
			'show_stars'        => 1,
			'button_shape'      => 'rounded', // square | rounded | pill.
			'email_font'        => 'system',  // system | arial | helvetica | georgia | verdana | trebuchet.
			'show_credit'       => 1,

			// Locations (one Google Business Profile each).
			'locations'         => array(),

			// Links.
			'link_mode'         => 'branded', // branded | direct.
			'branded_slug'      => 'review',

			// Text message.
			'sms_template'      => 'Hi {first_name}, thanks for choosing {business}! Would you leave us a quick Google review? {link} Reply STOP to opt out',
			'lookup_line_type'  => 1,

			// Email.
			'email_subject'     => '{first_name}, how did we do?',
			'email_heading'     => 'How did we do{name_comma}?',
			'email_body'        => "Thank you for choosing {business}. We hope everything went great.\n\nWould you take a minute to share your experience on Google? Your review helps others find us, and it means a lot to our team.",
			'email_button'      => 'Write a Google review',
			'email_feedback'    => 'Questions or concerns? Call or message us. We want to make it right.',
			'from_name'         => '',

			// Review page & QR card.
			'page_heading'      => 'Thanks for choosing {business}!',
			'page_intro'        => 'If you have a minute, please share your experience on Google. Your review helps others find us.',
			'qr_title'          => 'Enjoyed working with us?',
			'from_email'        => '',
			'reply_to'          => '',

			// Twilio.
			'twilio_account_sid'           => '',
			'twilio_api_key_sid'           => '',
			'twilio_api_key_secret'        => '',
			'twilio_messaging_service_sid' => '',
			'twilio_from_number'           => '',

			// Guard rails.
			'cooldown_days'     => 60,
			'daily_limit'       => 100,
			'user_hourly_limit' => 40,

			// Internal.
			'callback_secret'   => '',
		);
	}

	public static function ensure_defaults() {
		$current = get_option( self::OPTION );
		$current = is_array( $current ) ? $current : array();
		$merged  = array_merge( self::defaults(), $current );
		if ( empty( $merged['callback_secret'] ) ) {
			$merged['callback_secret'] = wp_generate_password( 32, false, false );
		}
		// v1 -> v2: single-location fields become the first location.
		if ( empty( $merged['locations'] ) && ! empty( $current['review_url'] ) ) {
			$merged['locations'] = array(
				array(
					'slug'          => 'main',
					'name'          => $merged['business_name'],
					'sms_name'      => isset( $current['sms_name'] ) ? $current['sms_name'] : '',
					'review_url'    => $current['review_url'],
					'map_embed_url' => isset( $current['map_embed_url'] ) ? $current['map_embed_url'] : '',
					'address'       => isset( $current['business_address'] ) ? $current['business_address'] : '',
					'phone'         => isset( $current['business_phone'] ) ? $current['business_phone'] : '',
					'feedback_url'  => isset( $current['feedback_url'] ) ? $current['feedback_url'] : '',
				),
			);
		}
		self::raw_update( $merged );
	}

	private static $cache = null;

	public static function flush_cache() {
		self::$cache = null;
	}

	/**
	 * Save the option without running the settings-form sanitizer
	 * (for internal writes such as resetting the webhook secret).
	 */
	public static function raw_update( $value ) {
		$cb  = array( __CLASS__, 'sanitize' );
		$had = has_filter( 'sanitize_option_' . self::OPTION, $cb );
		if ( false !== $had ) {
			remove_filter( 'sanitize_option_' . self::OPTION, $cb, $had );
		}
		update_option( self::OPTION, $value, true );
		if ( false !== $had ) {
			add_filter( 'sanitize_option_' . self::OPTION, $cb, $had );
		}
		self::flush_cache();
	}

	public static function all() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}
		$saved = get_option( self::OPTION );
		$saved = is_array( $saved ) ? $saved : array();
		$all   = array_merge( self::defaults(), $saved );
		foreach ( self::CONSTANTS as $key => $const ) {
			if ( defined( $const ) && constant( $const ) ) {
				$all[ $key ] = constant( $const );
			}
		}
		self::$cache = $all;
		return $all;
	}

	/**
	 * Site-specific key for hashing recipients. Stored once, so it survives
	 * security plugins rotating the WordPress salts.
	 */
	public static function hash_key() {
		$k = get_option( 'dim_rr_hash_key' );
		if ( ! $k ) {
			global $wpdb;
			// Sites that already logged sends keep their old key so history still matches.
			$has_rows = (bool) $wpdb->get_var( 'SELECT id FROM ' . DIM_RR_Log::table() . ' LIMIT 1' ); // phpcs:ignore
			$new      = $has_rows ? wp_salt( 'auth' ) : wp_generate_password( 64, true, true );
			add_option( 'dim_rr_hash_key', $new, '', true );
			$k = get_option( 'dim_rr_hash_key' );
			$k = $k ? $k : $new;
		}
		return $k;
	}

	/** Fields that identify this client's own sending setup: never exported or imported. */
	const SITE_ONLY = array( 'sender_page_id', 'twilio_account_sid', 'twilio_api_key_sid', 'twilio_api_key_secret', 'twilio_messaging_service_sid', 'twilio_from_number', 'from_email', 'from_name', 'reply_to', 'privacy_url', 'terms_url', 'alert_email', 'callback_secret', 'logo_id' );

	/** Client identity fields: optional in exports and imports. */
	const CLIENT_FIELDS = array( 'locations', 'business_name', 'business_phone', 'business_email', 'website_url', 'socials', 'logo_url', 'email_logo_url' );

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	public static function is_constant( $key ) {
		return isset( self::CONSTANTS[ $key ] ) && defined( self::CONSTANTS[ $key ] ) && constant( self::CONSTANTS[ $key ] );
	}

	public static function twilio_ready() {
		$s = self::all();
		return $s['twilio_account_sid'] && $s['twilio_api_key_sid'] && $s['twilio_api_key_secret']
			&& ( $s['twilio_messaging_service_sid'] || $s['twilio_from_number'] );
	}

	/**
	 * Front-end staff page URL, or '' when none is set up.
	 */
	public static function sender_page_url() {
		$id = (int) self::get( 'sender_page_id' );
		if ( $id && 'publish' === get_post_status( $id ) ) {
			return get_permalink( $id );
		}
		return '';
	}

	/**
	 * Staff who may send requests but not edit the site (front-desk role).
	 */
	public static function is_sender_only( $user = null ) {
		$user = $user ? $user : wp_get_current_user();
		return $user instanceof WP_User && $user->exists() && $user->has_cap( DIM_RR_CAP ) && ! $user->has_cap( 'edit_posts' ) && ! $user->has_cap( 'manage_options' );
	}

	/* ---------------------------------------------------------------- */
	/* Locations                                                        */
	/* ---------------------------------------------------------------- */

	/**
	 * Locations that have a review link, keyed by slug.
	 */
	public static function locations() {
		$out = array();
		foreach ( (array) self::get( 'locations' ) as $loc ) {
			if ( empty( $loc['slug'] ) || empty( $loc['name'] ) ) {
				continue;
			}
			$out[ $loc['slug'] ] = array_merge( array_fill_keys( self::LOCATION_FIELDS, '' ), $loc );
		}
		return $out;
	}

	public static function location( $slug = '' ) {
		$locs = self::locations();
		if ( $slug && isset( $locs[ $slug ] ) ) {
			return $locs[ $slug ];
		}
		return $locs ? reset( $locs ) : null;
	}

	/**
	 * Public link for a location, optionally with a per-message tracking token.
	 */
	public static function review_link( $loc, $token = '' ) {
		if ( ! $loc ) {
			return '';
		}
		$s = self::all();
		if ( 'branded' === $s['link_mode'] && $s['branded_slug'] ) {
			$base = home_url( '/' . trim( $s['branded_slug'], '/' ) . '/' );
			// A tracking token already identifies the location, so texts stay short.
			return $token ? $base . rawurlencode( $token ) . '/' : $base . $loc['slug'] . '/';
		}
		return $loc['review_url'];
	}

	public static function audience_word( $plural = false ) {
		$w = self::get( 'audience' );
		$w = in_array( $w, array( 'customer', 'patient', 'client' ), true ) ? $w : 'customer';
		return $plural ? $w . 's' : $w;
	}

	/* ---------------------------------------------------------------- */
	/* Templates                                                        */
	/* ---------------------------------------------------------------- */

	/**
	 * Fill {placeholders}.
	 *
	 * @param string $template Template text.
	 * @param array  $vars     first_name, link, location (array), sms (bool).
	 */
	public static function render( $template, $vars ) {
		$s    = self::all();
		$loc  = isset( $vars['location'] ) && is_array( $vars['location'] ) ? $vars['location'] : array();
		$name = isset( $vars['first_name'] ) ? trim( $vars['first_name'] ) : '';

		$business = $s['business_name'] ? $s['business_name'] : ( isset( $loc['name'] ) ? $loc['name'] : '' );
		if ( ! empty( $vars['sms'] ) && ! empty( $loc['sms_name'] ) ) {
			$business = $loc['sms_name'];
		}

		$map = array(
			'{first_name}' => '' !== $name ? $name : 'there',
			'{name_comma}' => '' !== $name ? ', ' . $name : '',
			'{business}'   => $business,
			'{phone}'      => ! empty( $loc['phone'] ) ? $loc['phone'] : $s['business_phone'],
			'{website}'    => $s['website_url'],
			'{link}'       => isset( $vars['link'] ) ? $vars['link'] : '',
		);
		$out = strtr( (string) $template, $map );
		// "there, how did we do?" reads badly in a subject line; tidy the common case.
		if ( '' === $name ) {
			$out = preg_replace( '/^there,\s*/i', '', $out );
			$out = ucfirst( $out );
		}
		return $out;
	}

	/**
	 * Keep texts in the GSM-7 character set (160 chars per segment, not 70).
	 */
	public static function sms_safe( $text ) {
		$swap = array(
			"\u{2018}" => "'", "\u{2019}" => "'", "\u{201C}" => '"', "\u{201D}" => '"',
			"\u{2013}" => '-', "\u{2014}" => '-', "\u{2026}" => '...', "\u{00A0}" => ' ',
		);
		return trim( preg_replace( '/[ \t]+/', ' ', strtr( $text, $swap ) ) );
	}

	/* ---------------------------------------------------------------- */
	/* Style helpers                                                    */
	/* ---------------------------------------------------------------- */

	/**
	 * Resolved style values used by the email, review page and send screen.
	 */
	public static function style() {
		$s      = self::all();
		$brand  = $s['brand_color'] ? $s['brand_color'] : '#1a73e8';
		$fonts  = array(
			'system'    => "-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif",
			'arial'     => 'Arial,Helvetica,sans-serif',
			'helvetica' => "'Helvetica Neue',Helvetica,Arial,sans-serif",
			'georgia'   => "Georgia,'Times New Roman',serif",
			'verdana'   => 'Verdana,Geneva,sans-serif',
			'trebuchet' => "'Trebuchet MS',Tahoma,sans-serif",
		);
		$radius = array( 'square' => '3px', 'rounded' => '8px', 'pill' => '999px' );
		$btn_tx = 'light' === $s['button_text'] ? '#ffffff' : ( 'dark' === $s['button_text'] ? '#111111' : self::contrast( $brand ) );
		$head   = $s['header_bg_color'] ? $s['header_bg_color'] : $brand;
		return array(
			'brand'       => $brand,
			'button_text' => $btn_tx,
			'accent'      => $s['accent_color'] ? $s['accent_color'] : $brand,
			'header'      => 'color' === $s['header_style'] ? $head : '#ffffff',
			'header_on'   => 'color' === $s['header_style'] ? self::contrast( $head ) : '#202124',
			'bg'          => $s['email_bg_color'] ? $s['email_bg_color'] : '#f1f3f4',
			'stars'       => $s['star_color'] ? $s['star_color'] : '#fbbc04',
			'radius'      => isset( $radius[ $s['button_shape'] ] ) ? $radius[ $s['button_shape'] ] : '8px',
			'font'        => isset( $fonts[ $s['email_font'] ] ) ? $fonts[ $s['email_font'] ] : $fonts['system'],
			'logo'        => ( 'color' === $s['header_style'] && $s['email_logo_url'] ) ? $s['email_logo_url'] : $s['logo_url'],
			'logo_width'  => (int) $s['logo_width'] ? (int) $s['logo_width'] : 200,
		);
	}

	/**
	 * White or near-black text for a background colour.
	 */
	public static function contrast( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) ) {
			return '#ffffff';
		}
		$c = array();
		foreach ( array( 0, 2, 4 ) as $i ) {
			$v   = hexdec( substr( $hex, $i, 2 ) ) / 255;
			$c[] = $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
		}
		$lum = 0.2126 * $c[0] + 0.7152 * $c[1] + 0.0722 * $c[2];
		// Pick whichever gives more contrast.
		return ( 1.05 / ( $lum + 0.05 ) ) >= ( ( $lum + 0.05 ) / 0.0617 ) ? '#ffffff' : '#111111';
	}

	/**
	 * Wording presets by industry (applied in the settings screen).
	 */
	public static function presets() {
		return array(
			'home'       => array(
				'label'          => 'Home services / contractor',
				'audience'       => 'customer',
				'sms_template'   => 'Hi {first_name}, thanks for choosing {business}! Would you leave us a quick Google review? {link} Reply STOP to opt out',
				'email_subject'  => '{first_name}, how did we do?',
				'email_heading'  => 'How did we do{name_comma}?',
				'email_body'     => "Thank you for choosing {business}. We hope you love the finished work.\n\nWould you take a minute to share your experience on Google? Your review helps neighbors find a contractor they can trust, and it means a lot to our crew.",
				'email_button'   => 'Write a Google review',
				'email_feedback' => 'Questions or concerns about your project? Call or message us. We want to make it right.',
				'page_heading'   => 'Thanks for choosing {business}!',
				'page_intro'     => 'If you have a minute, please share your experience on Google. Your review helps neighbors find a contractor they can trust.',
				'qr_title'       => 'Happy with your project?',
			),
			'medical'    => array(
				'label'          => 'Medical / clinic',
				'audience'       => 'patient',
				'sms_template'   => 'Hi {first_name}, thank you for visiting {business}. Would you share your experience in a quick Google review? {link} Reply STOP to opt out',
				'email_subject'  => 'How was your visit{name_comma}?',
				'email_heading'  => 'How was your visit{name_comma}?',
				'email_body'     => "Thank you for trusting {business} with your care.\n\nIf you have a minute, we would be grateful if you shared your experience on Google. Your review helps other patients find the care they need.",
				'email_button'   => 'Share your experience',
				'email_feedback' => 'Questions about your visit or care? Please call our office. We are here to help.',
				'page_heading'   => 'Thank you for visiting {business}',
				'page_intro'     => 'Your feedback helps other patients find the care they need. It only takes a minute.',
				'qr_title'       => 'Enjoyed your visit?',
			),
			'dental'     => array(
				'label'          => 'Dental',
				'audience'       => 'patient',
				'sms_template'   => 'Hi {first_name}, thanks for visiting {business}! Would you leave us a quick Google review? {link} Reply STOP to opt out',
				'email_subject'  => 'How was your visit{name_comma}?',
				'email_heading'  => 'Thanks for visiting{name_comma}!',
				'email_body'     => "Thank you for choosing {business} for your dental care.\n\nWould you take a minute to share your experience on Google? Your review helps families in our community find a dentist they can trust.",
				'email_button'   => 'Write a Google review',
				'email_feedback' => 'Questions about your visit? Call our office anytime.',
				'page_heading'   => 'Thanks for visiting {business}!',
				'page_intro'     => 'Your review helps families in our community find a dentist they can trust.',
				'qr_title'       => 'Love your smile?',
			),
			'legal'      => array(
				'label'          => 'Legal / professional services',
				'audience'       => 'client',
				'sms_template'   => 'Hi {first_name}, thank you for choosing {business}. Would you consider sharing your experience in a Google review? {link} Reply STOP to opt out',
				'email_subject'  => 'Thank you{name_comma}',
				'email_heading'  => 'Thank you for your trust{name_comma}',
				'email_body'     => "It was a privilege to work with you.\n\nIf you were pleased with our service, would you consider sharing your experience on Google? Reviews help others find the help they need.",
				'email_button'   => 'Leave a Google review',
				'email_feedback' => 'If anything needs our attention, please call our office directly.',
				'page_heading'   => 'Thank you for choosing {business}',
				'page_intro'     => 'If you were pleased with our service, please consider sharing your experience on Google.',
				'qr_title'       => 'Share your experience',
			),
			'hospitality' => array(
				'label'          => 'Restaurant / retail / hospitality',
				'audience'       => 'customer',
				'sms_template'   => 'Thanks for visiting {business}, {first_name}! Mind leaving us a quick Google review? {link} Reply STOP to opt out',
				'email_subject'  => 'Thanks for visiting{name_comma}!',
				'email_heading'  => 'Thanks for stopping by{name_comma}!',
				'email_body'     => "We hope you enjoyed your visit to {business}.\n\nGot a minute? A quick Google review helps more people discover us, and our team reads every one.",
				'email_button'   => 'Leave a review',
				'email_feedback' => 'Something not right? Let us know and we will make it right.',
				'page_heading'   => 'Thanks for visiting {business}!',
				'page_intro'     => 'A quick Google review helps more people discover us. Our team reads every one.',
				'qr_title'       => 'Enjoyed your visit?',
			),
			'general'    => array(
				'label'          => 'General business',
				'audience'       => 'customer',
				'sms_template'   => 'Hi {first_name}, thanks for choosing {business}! Would you leave us a quick Google review? {link} Reply STOP to opt out',
				'email_subject'  => '{first_name}, how did we do?',
				'email_heading'  => 'How did we do{name_comma}?',
				'email_body'     => "Thank you for choosing {business}. We hope everything went great.\n\nWould you take a minute to share your experience on Google? Your review helps others find us, and it means a lot to our team.",
				'email_button'   => 'Write a Google review',
				'email_feedback' => 'Questions or concerns? Call or message us. We want to make it right.',
				'page_heading'   => 'Thanks for choosing {business}!',
				'page_intro'     => 'If you have a minute, please share your experience on Google. Your review helps others find us.',
				'qr_title'       => 'Enjoyed working with us?',
			),
		);
	}

	/**
	 * Settings that can be exported and copied to another client site.
	 * Secrets and site-specific internals are never exported.
	 */
	public static function export_data( $include_locations = true ) {
		$s = get_option( self::OPTION );
		$s = is_array( $s ) ? $s : array();
		foreach ( self::SITE_ONLY as $k ) {
			unset( $s[ $k ] );
		}
		if ( ! $include_locations ) {
			foreach ( self::CLIENT_FIELDS as $k ) {
				unset( $s[ $k ] );
			}
		}
		return array(
			'plugin'   => 'dim-review-requests',
			'version'  => DIM_RR_VERSION,
			'exported' => gmdate( 'c' ),
			'site'     => home_url(),
			'settings' => $s,
		);
	}

	/* ---------------------------------------------------------------- */
	/* Sanitize                                                         */
	/* ---------------------------------------------------------------- */

	public static function sanitize( $input ) {
		$old = get_option( self::OPTION );
		$old = is_array( $old ) ? $old : array();
		$out = array_merge( self::defaults(), $old );
		$in  = is_array( $input ) ? wp_unslash( $input ) : array();

		// Only scalars are valid for plain fields; nested arrays only where expected.
		foreach ( $in as $k => $v ) {
			if ( in_array( $k, array( 'locations', 'socials' ), true ) ) {
				if ( ! is_array( $v ) ) {
					unset( $in[ $k ] );
				}
			} elseif ( ! is_scalar( $v ) ) {
				unset( $in[ $k ] );
			} else {
				$in[ $k ] = (string) $v;
			}
		}
		if ( isset( $in['socials'] ) ) {
			$in['socials'] = array_map(
				function ( $v ) {
					return is_scalar( $v ) ? (string) $v : '';
				},
				$in['socials']
			);
		}
		if ( isset( $in['locations'] ) ) {
			foreach ( $in['locations'] as $i => $row ) {
				if ( ! is_array( $row ) ) {
					unset( $in['locations'][ $i ] );
					continue;
				}
				foreach ( $row as $rk => $rv ) {
					$in['locations'][ $i ][ $rk ] = is_scalar( $rv ) ? (string) $rv : '';
				}
			}
		}

		foreach ( array( 'business_name', 'page_heading', 'qr_title', 'from_name', 'email_subject', 'email_heading', 'email_button', 'twilio_account_sid', 'twilio_api_key_sid', 'twilio_messaging_service_sid' ) as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$out[ $f ] = sanitize_text_field( $in[ $f ] );
			}
		}
		foreach ( array( 'sms_template', 'email_body', 'email_feedback', 'page_intro' ) as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$out[ $f ] = sanitize_textarea_field( $in[ $f ] );
			}
		}
		if ( isset( $in['logo_url'] ) ) {
			$out['logo_url'] = esc_url_raw( trim( $in['logo_url'] ) );
		}
		foreach ( array( 'from_email', 'reply_to' ) as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$out[ $f ] = sanitize_email( $in[ $f ] );
			}
		}
		if ( isset( $in['brand_color'] ) ) {
			$c                  = sanitize_hex_color( $in['brand_color'] );
			$out['brand_color'] = $c ? $c : '#1a73e8';
		}
		if ( isset( $in['audience'] ) ) {
			$out['audience'] = in_array( $in['audience'], array( 'customer', 'patient', 'client' ), true ) ? $in['audience'] : 'customer';
		}
		if ( isset( $in['link_mode'] ) ) {
			$out['link_mode'] = 'direct' === $in['link_mode'] ? 'direct' : 'branded';
		}
		if ( isset( $in['branded_slug'] ) ) {
			$slug = sanitize_title( $in['branded_slug'] );
			$slug = $slug ? $slug : 'review';
			if ( $slug !== $out['branded_slug'] && function_exists( 'get_page_by_path' ) && get_page_by_path( $slug ) ) {
				if ( function_exists( 'add_settings_error' ) ) {
					add_settings_error( self::OPTION, 'dim_rr_slug', 'The link path "' . $slug . '" is already used by a page on this site, so it was not changed.' );
				}
				$slug = $out['branded_slug'];
			}
			if ( $slug !== $out['branded_slug'] ) {
				update_option( 'dim_rr_flush_rewrite', 1 );
			}
			$out['branded_slug'] = $slug;
		}
		if ( isset( $in['twilio_from_number'] ) ) {
			$n                         = DIM_RR_Sender::normalize_phone( $in['twilio_from_number'] );
			$out['twilio_from_number'] = $n ? $n : '';
		}
		if ( isset( $in['twilio_api_key_secret'] ) && '' !== trim( $in['twilio_api_key_secret'] ) ) {
			$out['twilio_api_key_secret'] = sanitize_text_field( $in['twilio_api_key_secret'] );
		}
		foreach ( array( 'cooldown_days' => array( 0, 3650 ), 'daily_limit' => array( 1, 5000 ), 'user_hourly_limit' => array( 1, 1000 ) ) as $f => $r ) {
			if ( isset( $in[ $f ] ) ) {
				$out[ $f ] = max( $r[0], min( $r[1], absint( $in[ $f ] ) ) );
			}
		}
		if ( isset( $in['_form'] ) ) { // Checkboxes only exist in the submitted settings form.
			$out['show_credit']      = empty( $in['show_credit'] ) ? 0 : 1;
			$out['lookup_line_type'] = empty( $in['lookup_line_type'] ) ? 0 : 1;
			$out['show_stars']       = empty( $in['show_stars'] ) ? 0 : 1;
			$out['show_socials']     = empty( $in['show_socials'] ) ? 0 : 1;
			$out['brand_login']      = empty( $in['brand_login'] ) ? 0 : 1;
		}

		foreach ( array( 'business_phone', 'button_text', 'header_style', 'button_shape', 'email_font' ) as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$out[ $f ] = sanitize_text_field( $in[ $f ] );
			}
		}
		$enums = array(
			'button_text'  => array( 'auto', 'light', 'dark' ),
			'header_style' => array( 'white', 'color' ),
			'button_shape' => array( 'square', 'rounded', 'pill' ),
			'email_font'   => array( 'system', 'arial', 'helvetica', 'georgia', 'verdana', 'trebuchet' ),
		);
		foreach ( $enums as $f => $allowed ) {
			if ( ! in_array( $out[ $f ], $allowed, true ) ) {
				$out[ $f ] = $allowed[0];
			}
		}
		foreach ( array( 'signoff', 'footer_note' ) as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$out[ $f ] = sanitize_textarea_field( $in[ $f ] );
			}
		}
		foreach ( array( 'website_url', 'email_logo_url', 'privacy_url', 'terms_url' ) as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$out[ $f ] = esc_url_raw( trim( $in[ $f ] ) );
			}
		}
		foreach ( array( 'business_email', 'alert_email' ) as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$out[ $f ] = sanitize_email( $in[ $f ] );
			}
		}
		if ( isset( $in['sender_page_id'] ) ) {
			$out['sender_page_id'] = absint( $in['sender_page_id'] );
		}
		if ( isset( $in['logo_id'] ) ) {
			$out['logo_id'] = absint( $in['logo_id'] );
		}
		if ( isset( $in['logo_width'] ) ) {
			$out['logo_width'] = max( 80, min( 400, absint( $in['logo_width'] ) ) );
		}
		foreach ( self::COLOR_KEYS as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$c         = sanitize_hex_color( trim( $in[ $f ] ) );
				$out[ $f ] = $c ? $c : ( 'brand_color' === $f ? '#1a73e8' : ( 'email_bg_color' === $f ? '#f1f3f4' : ( 'star_color' === $f ? '#fbbc04' : '' ) ) );
			}
		}
		if ( isset( $in['socials'] ) && is_array( $in['socials'] ) ) {
			$soc = array();
			foreach ( self::SOCIALS as $k => $label ) {
				if ( ! empty( $in['socials'][ $k ] ) ) {
					$soc[ $k ] = esc_url_raw( trim( $in['socials'][ $k ] ) );
				}
			}
			$out['socials'] = $soc;
		}

		if ( isset( $in['locations'] ) && is_array( $in['locations'] ) ) {
			$locs = array();
			$used = array();
			foreach ( $in['locations'] as $row ) {
				if ( ! is_array( $row ) || '' === trim( (string) ( isset( $row['name'] ) ? $row['name'] : '' ) ) ) {
					continue;
				}
				$loc = array(
					'name'          => sanitize_text_field( $row['name'] ),
					'sms_name'      => sanitize_text_field( isset( $row['sms_name'] ) ? $row['sms_name'] : '' ),
					'review_url'    => esc_url_raw( trim( isset( $row['review_url'] ) ? $row['review_url'] : '' ) ),
					'address'       => sanitize_textarea_field( isset( $row['address'] ) ? $row['address'] : '' ),
					'phone'         => sanitize_text_field( isset( $row['phone'] ) ? $row['phone'] : '' ),
					'feedback_url'  => esc_url_raw( trim( isset( $row['feedback_url'] ) ? $row['feedback_url'] : '' ) ),
					'reply_to'      => sanitize_email( isset( $row['reply_to'] ) ? $row['reply_to'] : '' ),
					'map_embed_url' => '',
				);
				$map = isset( $row['map_embed_url'] ) ? trim( $row['map_embed_url'] ) : '';
				if ( preg_match( '/src=["\']([^"\']+)["\']/', $map, $m ) ) {
					$map = html_entity_decode( $m[1] );
				}
				$loc['map_embed_url'] = esc_url_raw( $map );

				$slug = sanitize_title( isset( $row['slug'] ) && '' !== $row['slug'] ? $row['slug'] : $loc['name'] );
				$slug = $slug ? $slug : 'location';
				$base = $slug;
				$i    = 2;
				while ( isset( $used[ $slug ] ) ) {
					$slug = $base . '-' . $i++;
				}
				$used[ $slug ] = true;
				$loc['slug']   = $slug;
				$locs[]        = $loc;
			}
			$out['locations'] = $locs;
		}

		if ( empty( $out['callback_secret'] ) ) {
			$out['callback_secret'] = wp_generate_password( 32, false, false );
		}
		unset( $out['_form'] );
		self::flush_cache();
		return $out;
	}
}
