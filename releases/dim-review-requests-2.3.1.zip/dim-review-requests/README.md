# DIM Review Requests (v2.3)

A WordPress plugin that replaces `googlereviews-gr.php`, `sendmail-gr.php` and the `/twilio/` SDK folder.

**What's new in v2**

- **Multiple locations.** Add one location per Google Business Profile, e.g. Roseville and Grosse Pointe Park. Staff pick the location on the send screen.
- **New send screen.** It shows a live preview of the text and the email subject, plus recent requests with delivery status that updates by itself. A "Send by email instead" button appears when a number turns out to be a landline.
- **Redesigned email.** Brand color bar, a row of clickable stars (all of them go to the same Google form), a button that also works in Outlook, and a contact box.
- **Short tracked links.** Texts use `site.com/review/Ab3dE7gH/`, and QR codes use `site.com/review/{location}/`.
- **Landline check on by default.** Landlines were the #1 Twilio error on the shared account.
- **Settings in tabs.** Business & locations, Messages (with an email preview), Email delivery, Twilio and Limits.
- **Old files flagged.** Diagnostics warns if old `googlereviews*.php`, `sendmail*.php` files or the `twilio/` folder are still on the server.

**What it adds**

- Staff must log in to send. There is a "Review Request Sender" role for front-desk staff.
- Texts go through Twilio's REST API with a per-site **API Key**. There is no SDK folder to maintain and the main Auth Token never goes on a website.
- Phone numbers are cleaned up to +1XXXXXXXXXX format. Opt-outs (STOP), landlines and numbers that failed before are blocked up front. The same person can't be asked twice within N days, and double-clicks don't send twice.
- Staff see plain-English error messages, and every send is logged with its Twilio delivery status (delivered or failed, plus the reason).
- A branded, tracked review link such as `https://clientsite.com/review-us/`, so you can see who opened it.
- An email that renders in Gmail and Outlook (PNG logo, plain-text version, neutral wording).
- A `[dim_review_page]` shortcode for a public review page with logo, review button, Google Map and QR code.
- A QR code page with a printable counter card and PNG download.
- A Diagnostics page that checks the Twilio login, the A2P 10DLC campaign status and the sender pool, groups recent failed texts by error code, and sends a test email.

## Per-client setup: the Setup checklist

Settings opens with a **Setup checklist** that ticks itself off as each item is done, with a button next to anything missing:

1. Business name and PNG/JPG logo
2. Location(s) with Google review link
3. Twilio connected (Restricted key in wp-config.php)
4. Email sending plugin (WP Mail SMTP) active
5. Problem alert email set
6. Privacy policy linked
7. SMS terms page: **one-click create**
8. Public "Leave a Review" page: **one-click create**
9. Staff send page: **one-click create** (hidden, noindexed, no site header or footer)
10. Staff login(s) with the Review Request Sender role (leave "Send the new user an email" unticked)
11. Test text delivered and test email sent
12. Old review files removed

Pages the plugin creates are tagged, so they can be removed cleanly later.

**Fastest way to set up a new client:** on a finished client site, go to Settings → Import / export / remove → **Export style & wording only**. On the new site, upload the plugin, import that file, then work down the checklist.

## Updating the plugin

From 2.3.0 on, client sites update themselves the normal WordPress way: when DIM publishes a new version, it shows on **Plugins** with an **Update now** button (and in Dashboard → Updates; "Check again" there forces a fresh check). Settings, pages, logs and logins are kept. Sites check about every 12 hours; the update notice can take up to a few hours to appear.

How it works: each site reads `update.json` from DIM's public releases repository (`DetroitInternetMarketingDev/dim-review-requests-releases`). That file names the new version, the zip's address, and the zip's SHA-256 fingerprint. The plugin only downloads from GitHub over HTTPS and refuses any zip whose fingerprint doesn't match, so a corrupted or swapped file can't be installed. The source code stays in the private repository; only built zips are public, and they hold no keys or client data.

**Publishing a release (DIM only):**
1. In the private repo, make the change, bump `Version:` and `DIM_RR_VERSION`, and add a CHANGELOG entry.
2. Run `./build.sh`. It lints, runs the tests, and writes `dist/dim-review-requests-<version>.zip` and `dist/update.json`.
3. In the releases repo, add the zip under `releases/`, replace `update.json`, and commit to `main`. Every client site sees the update within hours.

To roll back, publish the previous version's files again with a higher version number (WordPress only offers versions newer than what's installed).

Manual install still works: Plugins → Add New → Upload → **Replace current with uploaded**. **Never Delete the plugin to update it**: deleting runs the full removal below.

The plugin's `Update URI` header means WordPress.org is never asked about it and can never offer a different plugin with the same name as an "update".

## Removing the plugin from a client site

Settings → Import / export / remove → **Remove from this site** lists everything to do:

1. **Pages that use the plugin:** move them to the Trash with one click. Pages that also have other content are flagged, so you can remove just the shortcode.
2. **Staff logins:** listed. Deleting the plugin removes logins that only existed for it.
3. **Twilio:** remove the `DIM_RR_TWILIO_*` lines from wp-config.php and revoke the site's API key in Twilio.
4. **Privacy policy:** remove any review-request or SMS wording added for the service.
5. **Plugins → Deactivate → Delete.**

When the plugin is **deleted**, it automatically removes its settings, send log table, transients, rewrite rules, the staff role and its logins, and moves its pages to the Trash. Pages are only trashed if they contain nothing but its shortcode, so they can still be restored. Nothing else on the site depends on it.

Deactivating alone keeps everything, so the plugin can be turned back on. Any page still using its shortcodes would show the raw `[dim_...]` text while it's off.

## Per-client customization (Settings tabs)

| Tab | What you can change |
|---|---|
| Brand & style | Branded WordPress login page (on by default); logo, picked from the Media Library; an optional light logo for a colored header; logo width; button, accent, header band, email background and star colors; button text color (auto contrast); header style (logo on white, or logo on a color band); button shape (square, rounded or pill); email font; whether to show the star row, social links and DIM credit. Includes a live email preview. |
| Business & locations | Business name; what to call the people you serve (customers, clients or patients); website, main phone and main email; privacy policy and SMS terms page links; 10 social profiles; unlimited locations. Each location has its own review link, short name for texts, phone, address, contact page, reply-to email and map. |
| Messages | Wording presets (home services, medical, dental, legal, hospitality, general); text message template with a character counter; landline check; email subject, heading, body, button, sign-off, contact line and footer note; review page heading and intro; QR card title. |
| Email delivery | From name, From address, Reply-To. |
| Twilio | Account SID, Messaging Service SID, API Key SID and secret, From number. Any of these can be locked in wp-config.php. |
| Limits & alerts | How long before the same person can be asked again; daily and hourly caps; branded or direct links; an **alert email** for problems that stop every send. |
| Import / export / remove | Download a site's setup (never includes keys or the client's sending setup). Use "style & wording only" as a template for a new client. The **Remove from this site** checklist is here too. |

Placeholders you can use in any wording: `{first_name}` `{name_comma}` `{business}` `{phone}` `{website}` `{link}`.

## When something fails

- **Send screen:** a plain-English reason right away (landline, opted out, invalid number, carrier blocked, etc.), plus a "Send by email instead" button when it applies.
- **Recent requests list:** updates itself as Twilio reports Delivered, Not delivered or Failed, with the reason.
- **Activity page:** every request, its status, the reason it failed, and whether the link was opened.
- **WordPress dashboard widget:** 30-day totals and the latest problems.
- **Alert email (optional):** only for problems that stop *every* send: a bad or revoked API key (20003), an unregistered number (30034), carrier spam blocking (30007), an empty sender pool (21703), an unverified toll-free number, or email not sending. At most one email per problem every 6 hours.

## Texting compliance helpers

- `[dim_sms_terms]`: a ready-made SMS terms page (what the program is, how people opt in, how often they get texts, rates, STOP/HELP, carrier disclaimer, privacy line). Carriers ask for this page when they approve your texting registration.
- `[dim_sms_privacy]`: the paragraph carriers look for in a privacy policy ("no mobile information will be shared with third parties…").
- The privacy policy link appears in the email footer and on the review page.
- Your current texting registration (A2P campaign) is under the Detroit Internet Marketing brand, so its privacy and terms URLs need to point to pages on detroitinternetmarketing.com. The same shortcodes work there if the plugin is installed on that site; otherwise copy the text.

## Twilio security and separating clients

- **Per-site keys:** create a *Restricted* API Key named after each website, limited to Messaging and Lookups. Put it in wp-config.php, or in Settings → Twilio.
- **Switching without downtime:** while a site is still on the old shared token, you can temporarily enter the Account SID as the "API Key SID" and the Auth Token as the secret. Diagnostics shows a warning until you replace it. Once every site has its own key, go to Twilio → API keys & tokens → Request a secondary token, promote it, and the old shared token stops working everywhere.
- **Separate Twilio setup per client (optional, later):** every Twilio field is set per site, so moving a client to its own subaccount, Messaging Service, number and registration means changing only that site's Account SID, API Key and Messaging Service SID. No code changes needed.

## 1. Install

1. Zip the `dim-review-requests` folder (or use the zip you were given). Then go to **Plugins → Add New → Upload Plugin** and activate it.
2. Put the Twilio credentials in `wp-config.php`, above the line `/* That's all, stop editing! */`:

```php
define( 'DIM_RR_TWILIO_ACCOUNT_SID',           'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' );
define( 'DIM_RR_TWILIO_API_KEY_SID',           'SKxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' );
define( 'DIM_RR_TWILIO_API_KEY_SECRET',        'your-api-key-secret' );
define( 'DIM_RR_TWILIO_MESSAGING_SERVICE_SID', 'MGxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' );
// Only if there is no Messaging Service:
// define( 'DIM_RR_TWILIO_FROM_NUMBER', '+12485550000' );
```

   You can enter these under Settings instead, but wp-config.php keeps them out of the database and out of backups.

3. Go to **Review Requests → Settings** and fill in the business name, the Google review link, the map embed, a PNG logo, the phone number and the address. If the business name is long, also set a short name for texts.
4. Go to **Review Requests → Diagnostics** and fix anything that isn't green.
5. Delete the old files from the site root: `googlereviews-gr.php`, `sendmail-gr.php` and the `twilio/` folder.

## 2. Twilio setup (one time per client)

1. **API Key:** go to Twilio Console → Account → API keys & tokens → Create API key (Standard) and name it after the website. If a site is ever compromised, revoke that one key. The other sites keep working.
2. **Messaging Service:** go to Messaging → Services. Create one for this client and add the client's number to its Sender Pool. Integration settings can stay at their defaults, because the plugin sends a status callback with every message.
3. **A2P 10DLC:** the client's brand and a campaign must be registered and **Verified**, and the campaign must be linked to that Messaging Service. Unregistered 10DLC numbers are blocked by US carriers (error 30034). If you send for several clients, each client needs its own brand and campaign. Twilio's ISV / secondary-customer-profile flow covers this, ideally with one subaccount per client.
   - Use case: "Customer Care" or "Mixed".
   - Sample message: copy the text template from Settings.
   - Opt-in description: describe how patients agree to texts (intake form wording, verbal consent at check-out, etc.).
   - Privacy policy and terms URLs on the client's site are now required for campaign approval (error 30934).
4. **Alarms:** change the alarm so it emails on account-level problems only, such as 20003, 30034, 30007 and 21703. Per-patient errors like 30006 (landline), 21610 (STOP) and 30003 (phone off) are normal and are now shown to staff in the Activity log.

## 3. Email setup

WordPress on its own sends through the web server's PHP `mail()`, and those messages often land in spam or get rejected. Do this instead:

1. Install **WP Mail SMTP** or **FluentSMTP**.
2. Connect it to a mailbox or service authorized for the From domain: Google Workspace, Microsoft 365, SendGrid, Postmark, Brevo or Mailgun.
3. Make sure SPF, DKIM and DMARC pass for that domain. Check at mxtoolbox.com, or in Gmail use "Show original" on the test email from Diagnostics.
4. Send from the practice's own domain, e.g. `reviews@clientdomain.com`, with a reply-to of the front desk.

## 4. Pages

| Page | Shortcode | Notes |
|---|---|---|
| Public review page, e.g. `/leave-a-review/` | `[dim_review_page]` | Shows every location as its own card. Show just one with `location="roseville"`. Other options: `qr="no"`, `map="no"`, `heading="..."`, `intro="..."` |
| Staff sender for a front-desk tablet (optional) | `[dim_review_sender]` | Shows a login form to logged-out visitors. Set to noindex automatically. |

The branded links (`/review/{location}/`, plus short tracked links in messages) are created automatically and needs no page. It redirects to Google. If you change the slug in Settings, the rewrite rules are flushed for you.

## 5. Front-desk staff

**Staff send page (v2.1+):** go to Settings → Limits & alerts → Staff send page → "Create the staff page for me". This makes a hidden, noindexed page with no site header, menu, title, sidebar or footer (on GeneratePress sites the plugin also skips header, page-hero, sidebar and footer Elements on that page) at `/staff-review-requests/` with a sign-in box. Staff with the "Review Request Sender" role who sign in there see only the send screen and their recent requests. They get no admin bar or dashboard, and opening `/wp-admin/` sends them back to the page. Bookmark the page on the front-desk computer.

**Creating staff logins:** in Users → Add New, leave "Send the new user an email" **unticked**, set the password yourself, and give it to the office when you're ready.


Go to **Users → Add New** and choose the role **Review Request Sender**. After logging in, those users land on the send screen. In wp-admin they see only the send screen, their own sends on the Activity page, the Dashboard and their profile. Admins see everyone's activity. Administrators and Editors can send too.

## Message wording and Google policy

Google's review policy says businesses must not "discourage or prohibit negative reviews or selectively solicit positive reviews from customers." The FTC's rule on consumer reviews (16 CFR Part 465) also targets review suppression. That's why the default wording:

- asks everyone for a review on Google, not for a "5-star" review
- offers a private contact option *alongside* the Google button, never instead of it and never conditioned on how happy the person is

## Privacy (healthcare clients)

- The log stores a salted hash plus a masked recipient (`***-***-1234`, `j***@gmail.com`). Names, full numbers and full email addresses are never stored.
- The default messages say nothing about treatment.
- A patient's phone number, combined with the practice's name, can still count as PHI. If a practice needs HIPAA coverage for texting and email, confirm it has a BAA with Twilio and with its email provider. Twilio offers BAAs only on some account tiers.
