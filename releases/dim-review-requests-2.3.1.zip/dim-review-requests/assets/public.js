/* DIM Review Requests: QR codes (uses qrcodejs) and PNG download. */
(function () {
	'use strict';

	function render() {
		if (typeof window.QRCode === 'undefined') { return; }
		document.querySelectorAll('[data-dim-rr-qr]').forEach(function (box) {
			if (box.getAttribute('data-done')) { return; }
			var size = parseInt(box.getAttribute('data-size'), 10) || 200;
			/* global QRCode */
			new QRCode(box, {
				text: box.getAttribute('data-dim-rr-qr'),
				width: size,
				height: size,
				colorDark: '#000000',
				colorLight: '#ffffff',
				correctLevel: QRCode.CorrectLevel.M
			});
			box.setAttribute('data-done', '1');
		});
	}

	document.addEventListener('click', function (e) {
		var btn = e.target.closest('[data-dim-rr-download]');
		if (!btn) { return; }
		var scope = document.getElementById(btn.getAttribute('data-dim-rr-download')) || document;
		var canvas = scope.querySelector('[data-dim-rr-qr] canvas');
		if (!canvas) { return; }
		// Add a white quiet zone so the code scans reliably when printed.
		var pad = 32;
		var out = document.createElement('canvas');
		out.width = canvas.width + pad * 2;
		out.height = canvas.height + pad * 2;
		var ctx = out.getContext('2d');
		ctx.fillStyle = '#ffffff';
		ctx.fillRect(0, 0, out.width, out.height);
		ctx.drawImage(canvas, pad, pad);
		var a = document.createElement('a');
		a.download = btn.getAttribute('data-filename') || 'google-review-qr.png';
		a.href = out.toDataURL('image/png');
		document.body.appendChild(a);
		a.click();
		a.remove();
	});

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', render);
	} else {
		render();
	}
})();
