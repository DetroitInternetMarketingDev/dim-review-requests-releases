/* DIM Review Requests v2: send screen, settings tabs, locations editor. No jQuery. */
(function () {
	'use strict';

	var CFG = window.DIM_RR || {};

	function $(sel, root) { return (root || document).querySelector(sel); }
	function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
	function el(tag, cls, text) {
		var n = document.createElement(tag);
		if (cls) { n.className = cls; }
		if (text !== undefined && text !== null) { n.textContent = text; }
		return n;
	}

	/* ------------------------------------------------------------ */
	/* Send screen                                                  */
	/* ------------------------------------------------------------ */

	function digits(v) { return (v || '').replace(/\D/g, ''); }
	function looksLikePhone(v) {
		var d = digits(v);
		return d.length === 10 || (d.length === 11 && d.charAt(0) === '1');
	}
	function looksLikeEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v); }
	function formatPhone(input) {
		var d = digits(input.value);
		if (d.length === 11 && d.charAt(0) === '1') { d = d.slice(1); }
		if (d.length !== 10) { return; }
		input.value = '(' + d.slice(0, 3) + ') ' + d.slice(3, 6) + '-' + d.slice(6);
	}

	function renderRecent(list, rows) {
		list.innerHTML = '';
		if (!rows || !rows.length) {
			list.appendChild(el('li', 'dimrr-recent-empty', 'Nothing sent yet. Requests you send show up here with their delivery status.'));
			return;
		}
		rows.forEach(function (r) {
			var li = el('li', 'dimrr-recent-row');
			var icon = el('span', 'dimrr-recent-icon is-' + r.channel, r.channel === 'sms' ? 'SMS' : '@');
			var main = el('div', 'dimrr-recent-main');
			main.appendChild(el('span', 'dimrr-recent-to', r.to));
			main.appendChild(el('span', 'dimrr-recent-meta', (r.location ? r.location + ' · ' : '') + r.when));
			if (r.detail) { main.appendChild(el('span', 'dimrr-recent-detail', r.detail)); }
			var pill = el('span', 'dimrr-pill is-' + r.tone, r.clicked ? 'Opened link' : r.status);
			li.appendChild(icon); li.appendChild(main); li.appendChild(pill);
			list.appendChild(li);
		});
	}

	function needsRefresh(rows) {
		return (rows || []).some(function (r) { return ['Sending', 'Queued', 'Sent to carrier'].indexOf(r.status) !== -1; });
	}

	$$('.dimrr-form').forEach(function (form) {
		var app = form.closest('.dimrr-app');
		var btn = $('.dimrr-submit', form);
		var label = $('.dimrr-submit-label', form);
		var out = $('.dimrr-results', form);
		var phone = $('[name="phone"]', form);
		var email = $('[name="email"]', form);
		var first = $('[name="first_name"]', form);
		var force = $('[name="force"]', form);
		var bubble = $('[data-preview="sms"]', app);
		var subject = $('[data-preview="subject"]', app);
		var list = $('.dimrr-recent-list', app);
		var timer = null;

		function currentLoc() {
			var r = $('[name="location"]:checked', form) || $('[name="location"]', form);
			return r ? r.value : '';
		}

		function preview() {
			var loc = (CFG.locations || {})[currentLoc()];
			if (!loc) { return; }
			var n = first.value.trim();
			if (bubble) { bubble.textContent = loc.sms.replace(/__NAME__/g, n || 'there'); }
			if (subject) {
				var sub = loc.subject;
				sub = n ? sub.replace(/__NAME__/g, n) : sub.replace(/^__NAME__,\s*/, '').replace(/,\s*__NAME__/g, '').replace(/__NAME__/g, 'there');
				subject.textContent = sub.charAt(0).toUpperCase() + sub.slice(1);
			}
		}

		function show(items) {
			out.innerHTML = '';
			items.forEach(function (r) {
				var box = el('div', 'dimrr-alert is-' + (r.level || (r.ok ? 'success' : 'error')));
				if (r.channel) { box.appendChild(el('strong', '', (r.channel === 'sms' ? 'Text' : 'Email') + ': ')); }
				box.appendChild(document.createTextNode(r.message));
				if (r.hint === 'use_email' && email && !email.value) {
					var a = el('button', 'dimrr-inline-btn', 'Send by email instead');
					a.type = 'button';
					a.addEventListener('click', function () { email.focus(); if (phone) { phone.value = ''; } });
					box.appendChild(document.createTextNode(' '));
					box.appendChild(a);
				}
				out.appendChild(box);
			});
		}

		var limit = 8;
		var more = $('[data-recent-more]', app);

		function toggleMore(rows) {
			if (!more) { return; }
			more.hidden = !rows || rows.length < limit || limit >= 100;
		}

		function refresh() {
			var data = new FormData();
			data.append('action', 'dim_rr_recent');
			data.append('nonce', CFG.nonce);
			data.append('limit', String(limit));
			fetch(CFG.ajax, { method: 'POST', body: data, credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (j) { if (j && j.success) { renderRecent(list, j.data.recent); toggleMore(j.data.recent); schedule(j.data.recent); } })
				.catch(function () {});
		}

		function schedule(rows) {
			clearTimeout(timer);
			if (needsRefresh(rows)) { timer = setTimeout(refresh, 8000); }
		}

		if (list) {
			var initial = [];
			try { initial = JSON.parse(list.getAttribute('data-recent') || '[]'); } catch (e) {}
			renderRecent(list, initial);
			toggleMore(initial);
			schedule(initial);
			if (more) {
				more.addEventListener('click', function () {
					limit = Math.min(100, limit + 25);
					more.textContent = 'Loading\u2026';
					refresh();
					setTimeout(function () { more.textContent = 'Show more'; }, 800);
				});
			}
		}

		$$('[name="location"]', form).forEach(function (r) { r.addEventListener('change', preview); });
		first.addEventListener('input', preview);
		if (phone) { phone.addEventListener('blur', function () { formatPhone(phone); }); }
		preview();

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var p = phone && !phone.disabled ? phone.value.trim() : '';
			var m = email ? email.value.trim() : '';
			var errs = [];
			var loc = (CFG.locations || {})[currentLoc()];

			if (loc && !loc.ready) { errs.push({ ok: false, message: 'This location has no Google review link yet. An administrator needs to add it in Settings.' }); }
			if (!p && !m) { errs.push({ ok: false, message: 'Enter a mobile number, an email address, or both.' }); }
			if (p && !looksLikePhone(p)) { errs.push({ ok: false, channel: 'sms', message: 'That number does not look right. Enter 10 digits, e.g. 586-555-1234.' }); }
			if (m && !looksLikeEmail(m)) { errs.push({ ok: false, channel: 'email', message: 'That email address does not look right.' }); }
			if (errs.length) { show(errs); return; }

			var data = new FormData();
			data.append('action', 'dim_rr_send');
			data.append('nonce', CFG.nonce);
			data.append('location', currentLoc());
			data.append('first_name', first.value.trim());
			data.append('phone', p);
			data.append('email', m);
			if (force && force.checked) { data.append('force', '1'); }

			btn.disabled = true;
			btn.classList.add('is-busy');
			label.textContent = 'Sending…';
			out.innerHTML = '';

			fetch(CFG.ajax, { method: 'POST', body: data, credentials: 'same-origin' })
				.then(function (res) {
					return res.json().catch(function () { throw new Error('The server returned an unexpected response (HTTP ' + res.status + ').'); });
				})
				.then(function (json) {
					if (!json || !json.success) {
						show([{ ok: false, message: (json && json.data && json.data.message) || 'Something went wrong. Please try again.' }]);
						return;
					}
					var results = json.data.results || [];
					show(results);
					var allOk = results.length > 0;
					results.forEach(function (r) {
						if (r.ok && r.channel === 'sms' && phone) { phone.value = ''; }
						if (r.ok && r.channel === 'email' && email) { email.value = ''; }
						if (!r.ok) { allOk = false; }
					});
					if (allOk) {
						first.value = '';
						if (force) { force.checked = false; }
						preview();
						btn.classList.add('is-done');
						setTimeout(function () { btn.classList.remove('is-done'); }, 1600);
					}
					if (list && json.data.recent) { renderRecent(list, json.data.recent); schedule(json.data.recent); }
				})
				.catch(function (err) {
					show([{ ok: false, message: err && err.message ? err.message : 'Network error. Check the connection and try again.' }]);
				})
				.finally(function () {
					btn.disabled = false;
					btn.classList.remove('is-busy');
					label.textContent = 'Send review request';
				});
		});
	});

	/* ------------------------------------------------------------ */
	/* Settings: tabs                                               */
	/* ------------------------------------------------------------ */

	var tabs = $$('.dimrr-tab');
	if (tabs.length) {
		var activate = function (name) {
			var names = tabs.map(function (t) { return t.getAttribute('data-tab'); });
			if (names.indexOf(name) === -1) { name = names[0]; }
			tabs.forEach(function (t) { t.classList.toggle('is-active', t.getAttribute('data-tab') === name); t.setAttribute('aria-selected', t.getAttribute('data-tab') === name); });
			$$('.dimrr-panel').forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== name; });
			var bar = $('[data-savebar]');
			if (bar) { bar.hidden = name === 'tools'; }
			var ref = $('[name="_wp_http_referer"]');
			if (ref) { ref.value = ref.value.replace(/#.*$/, '') + '#' + name; }
		};
		tabs.forEach(function (t) {
			t.addEventListener('click', function (e) {
				e.preventDefault();
				var n = t.getAttribute('data-tab');
				history.replaceState(null, '', '#' + n);
				activate(n);
			});
		});
		activate((location.hash || '').replace('#', '') || tabs[0].getAttribute('data-tab'));
	}

	document.addEventListener('click', function (e) {
		var g = e.target.closest('[data-goto-tab]');
		if (!g) { return; }
		var t = $('.dimrr-tab[data-tab="' + g.getAttribute('data-goto-tab') + '"]');
		if (t) { e.preventDefault(); t.click(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
	});

	/* ------------------------------------------------------------ */
	/* Settings: locations editor                                   */
	/* ------------------------------------------------------------ */

	var locList = $('[data-locs]');
	var tpl = $('[data-loc-template]');
	if (locList && tpl) {
		var counter = $$('[data-loc-card]', locList).length + 100;
		var wire = function (card) {
			var name = $('[data-loc-name]', card);
			var title = $('[data-loc-title]', card);
			if (name && title) { name.addEventListener('input', function () { title.textContent = name.value || 'New location'; }); }
			var rm = $('[data-loc-remove]', card);
			if (rm) {
				rm.addEventListener('click', function () {
					if ($$('[data-loc-card]', locList).length <= 1) { name.value = ''; title.textContent = 'New location'; return; }
					card.remove();
				});
			}
		};
		$$('[data-loc-card]', locList).forEach(wire);
		$('[data-loc-add]').addEventListener('click', function () {
			var html = tpl.innerHTML.replace(/__i__/g, String(counter++));
			var wrap = document.createElement('div');
			wrap.innerHTML = html.trim();
			var card = wrap.firstElementChild;
			locList.appendChild(card);
			wire(card);
			var n = $('[data-loc-name]', card);
			if (n) { n.focus(); }
		});
	}

	/* Settings: live text length */
	var smsTpl = document.getElementById('dim-rr-sms_template');
	var smsCount = $('[data-sms-count]');
	if (smsTpl && smsCount) {
		var count = function () {
			var sample = smsTpl.value
				.replace(/\{first_name\}/g, 'Jennifer')
				.replace(/\{business\}/g, (($('[data-loc-card] [name$="[sms_name]"]') || {}).value || ($('[data-loc-card] [data-loc-name]') || {}).value || ''))
				.replace(/\{link\}/g, (CFG.origin || location.origin) + '/review/Ab3dE7gH/')
				.replace(/\{phone\}/g, '(586) 555-1234');
			var uni = /[^\x00-\x7F]/.test(sample);
			var per = uni ? 70 : 160;
			var segs = sample.length <= per ? 1 : Math.ceil(sample.length / (uni ? 67 : 153));
			smsCount.textContent = 'About ' + sample.length + ' characters = ' + segs + ' segment' + (segs > 1 ? 's' : '') + (uni ? ' (special characters shorten segments to 70)' : '') + '.';
			smsCount.className = segs > 1 ? 'is-warn' : '';
		};
		smsTpl.addEventListener('input', count);
		count();
	}


	/* ------------------------------------------------------------ */
	/* Settings: color pickers, logo picker, presets                */
	/* ------------------------------------------------------------ */

	$$('[data-color-for]').forEach(function (picker) {
		var text = document.getElementById(picker.getAttribute('data-color-for'));
		if (!text) { return; }
		picker.addEventListener('input', function () { text.value = picker.value; });
		text.addEventListener('input', function () {
			if (/^#[0-9a-f]{6}$/i.test(text.value)) { picker.value = text.value; }
		});
	});

	$$('[data-media-target]').forEach(function (btn) {
		var input = document.getElementById(btn.getAttribute('data-media-target'));
		var prev = $('[data-media-preview="' + btn.getAttribute('data-media-target') + '"]');
		var showPrev = function () {
			if (!prev) { return; }
			prev.innerHTML = '';
			if (input.value) { var img = new Image(); img.src = input.value; img.alt = ''; prev.appendChild(img); }
		};
		input.addEventListener('change', showPrev);
		if (!(window.wp && window.wp.media)) { btn.hidden = true; return; }
		var frame = null;
		btn.addEventListener('click', function () {
			if (!frame) {
				frame = window.wp.media({ title: 'Choose a logo (PNG or JPG)', button: { text: 'Use this image' }, library: { type: ['image/png', 'image/jpeg', 'image/gif', 'image/webp'] }, multiple: false });
				frame.on('select', function () {
					var a = frame.state().get('selection').first().toJSON();
					var url = (a.sizes && a.sizes.medium_large ? a.sizes.medium_large.url : a.url);
					if (a.width && a.width <= 800) { url = a.url; }
					input.value = url;
					showPrev();
				});
			}
			frame.open();
		});
	});

	var presetBtn = $('[data-preset-apply]');
	if (presetBtn && CFG.presets) {
		presetBtn.addEventListener('click', function () {
			var key = $('[data-preset-select]').value;
			var p = CFG.presets[key];
			if (!p) { return; }
			if (!window.confirm('Replace the current wording with the "' + p.label + '" preset? Nothing is saved until you click Save settings.')) { return; }
			Object.keys(p).forEach(function (k) {
				if (k === 'label') { return; }
				var f = document.getElementById('dim-rr-' + k);
				if (f) { f.value = p[k]; f.dispatchEvent(new Event('input')); }
			});
			presetBtn.textContent = 'Applied. Review, then save';
			setTimeout(function () { presetBtn.textContent = 'Apply wording'; }, 2500);
		});
	}

	/* ------------------------------------------------------------ */
	/* QR page: copy + print                                        */
	/* ------------------------------------------------------------ */

	document.addEventListener('click', function (e) {
		var c = e.target.closest('[data-copy]');
		if (c) {
			var input = c.parentNode.querySelector('input');
			input.select();
			(navigator.clipboard ? navigator.clipboard.writeText(input.value) : Promise.reject()).catch(function () { document.execCommand('copy'); });
			c.textContent = 'Copied';
			setTimeout(function () { c.textContent = 'Copy'; }, 1500);
		}
		var p = e.target.closest('[data-print]');
		if (p) {
			var id = p.getAttribute('data-print');
			document.body.setAttribute('data-printing', id);
			$$('.dimrr-print-card').forEach(function (card) { card.classList.toggle('is-printing', card.id === id); });
			window.print();
		}
	});
})();
