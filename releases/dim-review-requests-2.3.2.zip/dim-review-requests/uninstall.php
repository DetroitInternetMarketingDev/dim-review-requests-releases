<?php
/**
 * Runs when the plugin is DELETED (not just deactivated) from Plugins.
 * Removes everything it added so nothing is left behind:
 * settings, send log, transients, rewrite rules, the staff role and its
 * logins, and pages that contain nothing but one of its shortcodes
 * (moved to the Trash, so they can still be restored).
 * Runs for every site on multisite.
 *
 * Not touched (cannot be safely automated; listed in Settings > Import / export / remove):
 * lines in wp-config.php, the Twilio API key, and wording added to the privacy policy.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

function dim_rr_uninstall_only_shortcode( $content ) {
	$c = preg_replace( '/<!--.*?-->/s', '', (string) $content );
	if ( preg_match( '/<(img|iframe|video|audio|figure|form|svg)\b/i', $c ) ) {
		return false;
	}
	$c     = trim( wp_strip_all_tags( $c ) );
	$count = 0;
	$c     = preg_replace( '/\[(dim_review_page|dim_review_sender|dim_sms_terms|dim_sms_privacy)\b[^\]]*\]/', '', $c, -1, $count );
	return 1 === $count && '' === trim( $c );
}

function dim_rr_uninstall_site() {
	global $wpdb;

	// 1. Pages the plugin created, or that contain only its shortcode -> Trash.
	$ids  = array_map( 'intval', (array) get_option( 'dim_rr_created_pages', array() ) );
	$rows = $wpdb->get_results( "SELECT ID, post_content FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status <> 'trash' AND post_content LIKE '%[dim\\_%'" ); // phpcs:ignore
	foreach ( (array) $rows as $r ) {
		if ( dim_rr_uninstall_only_shortcode( $r->post_content ) ) {
			$ids[] = (int) $r->ID;
		}
	}
	foreach ( array_unique( $ids ) as $id ) {
		if ( $id && get_post( $id ) && 'trash' !== get_post_status( $id ) ) {
			wp_trash_post( $id );
		}
	}

	// 2. Staff logins that only existed for this plugin (no posts) are removed;
	//    anyone else loses just the role.
	//    Anything a removed login owned (of any type) goes to an administrator.
	require_once ABSPATH . 'wp-admin/includes/user.php';
	$admins   = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID', 'orderby' => 'ID' ) );
	$reassign = $admins ? (int) $admins[0] : 0;
	foreach ( get_users( array( 'role' => 'dim_review_sender' ) ) as $user ) {
		$only = array_values( array_diff( (array) $user->roles, array( 'dim_review_sender' ) ) );
		if ( ! $only && $reassign ) {
			wp_delete_user( $user->ID, $reassign );
		} else {
			$user->remove_role( 'dim_review_sender' );
		}
	}
	remove_role( 'dim_review_sender' );
	global $wp_roles;
	if ( $wp_roles instanceof WP_Roles ) {
		foreach ( array_keys( $wp_roles->roles ) as $name ) {
			$role = get_role( $name );
			if ( $role && $role->has_cap( 'dim_rr_send' ) ) {
				$role->remove_cap( 'dim_rr_send' );
			}
		}
	}

	// 3. Settings, internal options, transients, table, rewrite rules.
	foreach ( array( 'dim_rr_settings', 'dim_rr_db_version', 'dim_rr_flush_rewrite', 'dim_rr_roles_version', 'dim_rr_hash_key', 'dim_rr_created_pages', 'rewrite_rules' ) as $opt ) {
		delete_option( $opt );
	}
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_dim\\_rr\\_%' OR option_name LIKE '\\_transient\\_timeout\\_dim\\_rr\\_%'" ); // phpcs:ignore
	$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_dim_rr_page'" ); // phpcs:ignore
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}dim_rr_log" ); // phpcs:ignore
}

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids', 'number' => 0 ) ) as $site_id ) {
		switch_to_blog( $site_id );
		dim_rr_uninstall_site();
		restore_current_blog();
	}
} else {
	dim_rr_uninstall_site();
}
delete_site_transient( 'dim_rr_update_manifest' );
