<?php
/**
 * Validates and sends review requests (AJAX endpoints for logged-in staff).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DIM_RR_Sender {

	/** Non-US/Canada +1 countries, toll-free and premium area codes. */
	const BLOCKED_AREA_CODES = array( '242', '246', '264', '268', '284', '345', '441', '473', '649', '658', '664', '721', '758', '767', '784', '809', '829', '849', '868', '869', '876', '800', '833', '844', '855', '866', '877', '888', '900', '976' );

	/** Remove phone numbers and email addresses from provider error text before it is stored. */
	public static function scrub( $text ) {
		$text = preg_replace( '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', '[email]', (string) $text );
		$text = preg_replace_callback(
			'/\+?\(?\d[\d\s().\-]{6,}\d/',
			function ( $m ) {
				return strlen( preg_replace( '/\D/', '', $m[0] ) ) >= 10 ? '[number]' : $m[0];
			},
			$text
		);
		return mb_substr( $text, 0, 255 );
	}

	/**
	 * Normalize to E.164. US/Canada only (matches the Twilio geo permissions).
	 * Returns '' when the number cannot be valid.
	 */
	public static function normalize_phone( $raw ) {
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return '';
		}
		$plus   = 0 === strpos( $raw, '+' );
		$digits = preg_replace( '/\D/', '', $raw );

		if ( $plus ) {
			if ( 0 !== strpos( $digits, '1' ) ) {
				return '';
			}
			$digits = substr( $digits, 1 );
		} elseif ( 11 === strlen( $digits ) && '1' === $digits[0] ) {
			$digits = substr( $digits, 1 );
		}
		if ( 10 !== strlen( $digits ) ) {
			return '';
		}
		if ( in_array( $digits[0], array( '0', '1' ), true ) || in_array( $digits[3], array( '0', '1' ), true ) ) {
			return '';
		}
		if ( preg_match( '/^\d{3}55501\d{2}$/', $digits ) ) {
			return '';
		}
		// +1 also covers Caribbean countries (international rates, a common
		// SMS-fraud target), toll-free and premium numbers. Block those.
		if ( in_array( substr( $digits, 0, 3 ), self::BLOCKED_AREA_CODES, true ) ) {
			return '';
		}
		return '+1' . $digits;
	}

	public static function release( $lock ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
	}

	public static function format_phone( $e164 ) {
		if ( preg_match( '/^\+1(\d{3})(\d{3})(\d{4})$/', $e164, $m ) ) {
			return "($m[1]) $m[2]-$m[3]";
		}
		return $e164;
	}

	private static function token() {
		return wp_generate_password( 8, false, false );
	}

	public static function status_callback_url() {
		return add_query_arg( 'k', rawurlencode( (string) DIM_RR_Settings::get( 'callback_secret' ) ), rest_url( 'dim-rr/v1/status' ) );
	}

	private static function guard() {
		if ( ! current_user_can( DIM_RR_CAP ) ) {
			wp_send_json_error( array( 'message' => 'You do not have permission to send review requests.' ), 403 );
		}
		if ( ! check_ajax_referer( 'dim_rr_send', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'Your session expired. Reload the page and try again.' ), 403 );
		}
	}

	/**
	 * AJAX: action=dim_rr_send
	 */
	public static function ajax_send() {
		self::guard();

		$s          = DIM_RR_Settings::all();
		$first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
		$first_name = mb_substr( trim( preg_replace( '/[^\p{L}\p{M}\' -]/u', '', $first_name ) ), 0, 30 );
		$phone_raw  = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$email_raw  = isset( $_POST['email'] ) ? sanitize_text_field( wp_unslash( $_POST['email'] ) ) : '';
		$loc_slug   = isset( $_POST['location'] ) && is_string( $_POST['location'] ) ? sanitize_title( wp_unslash( $_POST['location'] ) ) : '';
		$force      = ! empty( $_POST['force'] ) && current_user_can( 'manage_options' );

		$loc = DIM_RR_Settings::location( $loc_slug );
		if ( ! $loc || empty( $loc['review_url'] ) ) {
			wp_send_json_error( array( 'message' => 'This location has no Google review link yet (Review Requests > Settings > Locations).' ) );
		}
		if ( '' === $phone_raw && '' === $email_raw ) {
			wp_send_json_error( array( 'message' => 'Enter a mobile number, an email address, or both.' ) );
		}

		$user_id = get_current_user_id();
		// One send at a time per site, so parallel requests can't slip past the limits.
		global $wpdb;
		$lock = 'dim_rr_send_' . get_current_blog_id();
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 15)', $lock ) ) ) {
			wp_send_json_error( array( 'message' => 'Another request is being sent. Try again in a moment.' ) );
		}
		register_shutdown_function( array( __CLASS__, 'release' ), $lock );
		if ( DIM_RR_Log::count_since( HOUR_IN_SECONDS, $user_id ) >= (int) $s['user_hourly_limit'] ) {
			wp_send_json_error( array( 'message' => 'Hourly sending limit reached for your login. Try again later.' ) );
		}
		if ( DIM_RR_Log::count_since( DAY_IN_SECONDS ) >= (int) $s['daily_limit'] ) {
			wp_send_json_error( array( 'message' => 'Daily sending limit for this site has been reached. An administrator can raise it in Settings.' ) );
		}

		$results = array();
		if ( '' !== $phone_raw ) {
			$results[] = self::send_sms( $phone_raw, $first_name, $loc, $force );
		}
		if ( '' !== $email_raw ) {
			$results[] = self::send_email( $email_raw, $first_name, $loc, $force );
		}
		wp_send_json_success(
			array(
				'results' => $results,
				'recent'  => self::recent_rows( $user_id ),
			)
		);
	}

	/**
	 * AJAX: action=dim_rr_recent  (refreshes delivery status on the send screen)
	 */
	public static function ajax_recent() {
		self::guard();
		$limit = isset( $_POST['limit'] ) ? max( 8, min( 100, absint( $_POST['limit'] ) ) ) : 8;
		wp_send_json_success( array( 'recent' => self::recent_rows( current_user_can( 'manage_options' ) ? 0 : get_current_user_id(), $limit ) ) );
	}

	/**
	 * Recent sends formatted for the send screen.
	 */
	public static function recent_rows( $user_id = 0, $limit = 8 ) {
		$locs = DIM_RR_Settings::locations();
		$out  = array();
		foreach ( DIM_RR_Log::recent( $limit, $user_id ) as $r ) {
			$bad   = in_array( $r->status, array( 'failed', 'undelivered', 'error', 'blocked' ), true );
			$label = array(
				'sending'     => 'Sending',
				'accepted'    => 'Queued',
				'queued'      => 'Queued',
				'sent'        => 'sent' === $r->status && 'email' === $r->channel ? 'Sent' : 'Sent to carrier',
				'delivered'   => 'Delivered',
				'read'        => 'Read',
				'undelivered' => 'Not delivered',
				'failed'      => 'Failed',
				'error'       => 'Not sent',
				'blocked'     => 'Not sent',
			);
			$out[] = array(
				'when'     => human_time_diff( strtotime( $r->created_at . ' UTC' ), time() ) . ' ago',
				'channel'  => $r->channel,
				'to'       => $r->recipient_masked,
				'location' => isset( $locs[ $r->location ] ) ? $locs[ $r->location ]['name'] : $r->location,
				'status'   => isset( $label[ $r->status ] ) ? $label[ $r->status ] : $r->status,
				'tone'     => $bad ? 'bad' : ( in_array( $r->status, array( 'delivered', 'read' ), true ) || $r->clicked_at ? 'good' : 'neutral' ),
				'clicked'  => (bool) $r->clicked_at,
				'detail'   => $r->error_code ? DIM_RR_Twilio::explain( $r->error_code, $r->error_message ) : '',
			);
		}
		return $out;
	}

	private static function result( $channel, $ok, $message, $level = '', $hint = '' ) {
		return array(
			'channel' => $channel,
			'ok'      => (bool) $ok,
			'level'   => $level ? $level : ( $ok ? 'success' : 'error' ),
			'message' => $message,
			'hint'    => $hint, // e.g. "use_email" so the screen can point staff to the email field.
		);
	}

	public static function send_sms( $raw, $first_name, $loc, $force = false ) {
		$s = DIM_RR_Settings::all();

		if ( ! DIM_RR_Settings::twilio_ready() ) {
			return self::result( 'sms', false, 'Texting is not set up yet. An administrator needs to add the Twilio details in Settings.' );
		}
		$to = self::normalize_phone( $raw );
		if ( ! $to ) {
			return self::result( 'sms', false, 'That does not look like a valid US mobile number. Enter 10 digits, for example 586-555-1234.' );
		}
		$pretty = self::format_phone( $to );
		$hash   = DIM_RR_Log::hash( $to );

		if ( DIM_RR_Log::is_opted_out( $hash ) ) {
			return self::result( 'sms', false, $pretty . ' has opted out of texts (they replied STOP).', 'error', 'use_email' );
		}
		$bad = DIM_RR_Log::bad_number_code( $hash );
		if ( $bad && ! $force ) {
			return self::result( 'sms', false, 'An earlier text to ' . $pretty . ' failed: ' . DIM_RR_Twilio::explain( $bad ), 'error', 'use_email' );
		}
		if ( ! $force && (int) $s['cooldown_days'] > 0 ) {
			$prev = DIM_RR_Log::last_success( 'sms', $hash, $s['cooldown_days'] );
			if ( $prev ) {
				return self::result( 'sms', false, sprintf( '%s was already sent a request on %s. Skipped so they are not asked twice.', $pretty, self::local_date( $prev->created_at ) ), 'warning' );
			}
		}

		// Write the row first so paid lookups count toward the hourly and daily limits.
		$token  = self::token();
		$log_id = DIM_RR_Log::insert(
			array(
				'channel'          => 'sms',
				'location'         => $loc['slug'],
				'recipient_hash'   => $hash,
				'recipient_masked' => DIM_RR_Log::mask( 'sms', $to ),
				'status'           => 'sending',
				'token'            => $token,
			)
		);

		if ( ! empty( $s['lookup_line_type'] ) ) {
			$lk = DIM_RR_Twilio::lookup( $to );
			if ( false === $lk['valid'] ) {
				DIM_RR_Log::update( $log_id, array( 'status' => 'blocked', 'error_code' => '21211', 'error_message' => 'Lookup: not a valid number' ) );
				return self::result( 'sms', false, $pretty . ' is not a working phone number. Check it for typos.' );
			}
			if ( $lk['country'] && ! in_array( $lk['country'], array( 'US', 'CA', 'PR', 'VI', 'GU', 'AS', 'MP' ), true ) ) {
				DIM_RR_Log::update( $log_id, array( 'status' => 'blocked', 'error_code' => '21408', 'error_message' => 'Lookup: outside US/Canada' ) );
				return self::result( 'sms', false, $pretty . ' is not a US or Canadian number. Use email instead.', 'error', 'use_email' );
			}
			if ( in_array( $lk['type'], array( 'landline', 'fixedVoip', 'tollFree', 'voicemail', 'sharedCost', 'premium', 'uan', 'pager' ), true ) ) {
				DIM_RR_Log::update( $log_id, array( 'status' => 'blocked', 'error_code' => '30006', 'error_message' => 'Lookup: ' . $lk['type'] ) );
				return self::result( 'sms', false, sprintf( '%s is a %s and cannot get texts.', $pretty, 'fixedVoip' === $lk['type'] ? 'business/VoIP line' : 'landline' ), 'error', 'use_email' );
			}
		}

		$body = DIM_RR_Settings::sms_safe(
			DIM_RR_Settings::render(
				$s['sms_template'],
				array(
					'first_name' => $first_name,
					'link'       => DIM_RR_Settings::review_link( $loc, $token ),
					'location'   => $loc,
					'sms'        => true,
				)
			)
		);

		$r = DIM_RR_Twilio::send_sms( $to, $body, self::status_callback_url() );
		if ( $r['ok'] ) {
			DIM_RR_Log::update(
				$log_id,
				array(
					'status'      => isset( $r['body']['status'] ) ? sanitize_key( $r['body']['status'] ) : 'queued',
					'provider_id' => isset( $r['body']['sid'] ) ? sanitize_text_field( $r['body']['sid'] ) : '',
				)
			);
			return self::result( 'sms', true, 'Text sent to ' . $pretty . '.' );
		}

		DIM_RR_Log::update(
			$log_id,
			array(
				'status'        => 'error',
				'error_code'    => substr( $r['error_code'], 0, 16 ),
				'error_message' => self::scrub( $r['error_message'] ),
			)
		);
		DIM_RR_Alerts::maybe( $r['error_code'], self::scrub( $r['error_message'] ) );
		$hint = in_array( $r['error_code'], array( '21610', '21612', '21614', '30006' ), true ) ? 'use_email' : '';
		return self::result( 'sms', false, 'Text not sent. ' . DIM_RR_Twilio::explain( $r['error_code'], $r['error_message'] ), 'error', $hint );
	}

	public static function send_email( $raw, $first_name, $loc, $force = false ) {
		$s     = DIM_RR_Settings::all();
		$email = sanitize_email( $raw );
		if ( ! $email || ! is_email( $email ) ) {
			return self::result( 'email', false, 'That email address does not look right. Check it for typos.' );
		}
		$hash = DIM_RR_Log::hash( $email );
		if ( ! $force && (int) $s['cooldown_days'] > 0 ) {
			$prev = DIM_RR_Log::last_success( 'email', $hash, $s['cooldown_days'] );
			if ( $prev ) {
				return self::result( 'email', false, sprintf( '%s was already emailed on %s. Skipped so they are not asked twice.', $email, self::local_date( $prev->created_at ) ), 'warning' );
			}
		}

		$token  = self::token();
		$log_id = DIM_RR_Log::insert(
			array(
				'channel'          => 'email',
				'location'         => $loc['slug'],
				'recipient_hash'   => $hash,
				'recipient_masked' => DIM_RR_Log::mask( 'email', $email ),
				'status'           => 'sending',
				'token'            => $token,
			)
		);

		$r = DIM_RR_Email::send( $email, $first_name, $loc, $token );
		if ( $r['ok'] ) {
			DIM_RR_Log::update( $log_id, array( 'status' => 'sent' ) );
			return self::result( 'email', true, 'Email sent to ' . $email . '.' );
		}
		DIM_RR_Log::update(
			$log_id,
			array(
				'status'        => 'error',
				'error_code'    => 'mail',
				'error_message' => self::scrub( $r['error'] ),
			)
		);
		DIM_RR_Alerts::maybe( 'mail', self::scrub( $r['error'] ) );
		return self::result( 'email', false, 'Email not sent. ' . $r['error'] );
	}

	public static function local_date( $gmt ) {
		return get_date_from_gmt( $gmt, (string) get_option( 'date_format', 'M j, Y' ) );
	}
}
