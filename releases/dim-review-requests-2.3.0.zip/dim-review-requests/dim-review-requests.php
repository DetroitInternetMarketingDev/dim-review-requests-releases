<?php
/**
 * Plugin Name:       DIM Review Requests
 * Description:       Staff-only tool to send Google review requests by text (Twilio) and email for one or more Google Business Profile locations, with delivery tracking, branded review links, review pages with map and QR code, and diagnostics.
 * Version:           2.3.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Tested up to:      7.1
 * Update URI:        https://raw.githubusercontent.com/DetroitInternetMarketingDev/dim-review-requests-releases/main/update.json
 * Author:            Detroit Internet Marketing
 * Author URI:        https://detroitinternetmarketing.com/
 * License:           GPL-2.0-or-later
 * Text Domain:       dim-review-requests
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DIM_RR_VERSION', '2.3.0' );
define( 'DIM_RR_FILE', __FILE__ );
define( 'DIM_RR_DIR', plugin_dir_path( __FILE__ ) );
define( 'DIM_RR_URL', plugin_dir_url( __FILE__ ) );
define( 'DIM_RR_CAP', 'dim_rr_send' );

require_once DIM_RR_DIR . 'includes/class-settings.php';
require_once DIM_RR_DIR . 'includes/class-log.php';
require_once DIM_RR_DIR . 'includes/class-twilio.php';
require_once DIM_RR_DIR . 'includes/class-email.php';
require_once DIM_RR_DIR . 'includes/class-alerts.php';
require_once DIM_RR_DIR . 'includes/class-sender.php';
require_once DIM_RR_DIR . 'includes/class-public.php';
require_once DIM_RR_DIR . 'includes/class-admin.php';
require_once DIM_RR_DIR . 'includes/class-login.php';
require_once DIM_RR_DIR . 'includes/class-updater.php';

register_activation_hook( __FILE__, 'dim_rr_activate' );
register_deactivation_hook( __FILE__, 'dim_rr_deactivate' );

define( 'DIM_RR_ROLES_VERSION', '2' );

/**
 * Roles and capabilities. Runs on activation and again whenever the stored
 * version differs (multisite subsites, role resets, file-only deploys).
 */
function dim_rr_setup_roles() {
	foreach ( array( 'administrator', 'editor' ) as $role_name ) {
		$role = get_role( $role_name );
		if ( $role ) {
			$role->add_cap( DIM_RR_CAP );
		}
	}
	// Front-desk staff: log in and send requests, nothing else.
	// view_admin_dashboard keeps WooCommerce from redirecting them away from wp-admin.
	$caps   = array(
		'read'                 => true,
		'view_admin_dashboard' => true,
		DIM_RR_CAP             => true,
	);
	$sender = get_role( 'dim_review_sender' );
	if ( $sender ) {
		foreach ( array_keys( $caps ) as $cap ) {
			$sender->add_cap( $cap ); // Keeps any capabilities an admin added by hand.
		}
	} else {
		add_role( 'dim_review_sender', 'Review Request Sender', $caps );
	}
	update_option( 'dim_rr_roles_version', DIM_RR_ROLES_VERSION );
}

/**
 * Activation: table, settings, roles, rewrite rules.
 */
function dim_rr_activate() {
	DIM_RR_Log::install();
	DIM_RR_Settings::ensure_defaults();
	dim_rr_setup_roles();

	// Don't take over an existing page at /review/.
	$slug = DIM_RR_Settings::get( 'branded_slug' );
	if ( $slug && get_page_by_path( $slug ) ) {
		foreach ( array( 'leave-a-review', 'review-us', 'google-review', 'rate-us' ) as $alt ) {
			if ( ! get_page_by_path( $alt ) ) {
				$opt                 = get_option( DIM_RR_Settings::OPTION );
				$opt['branded_slug'] = $alt;
				DIM_RR_Settings::raw_update( $opt );
				break;
			}
		}
	}

	DIM_RR_Public::add_rewrite();
	flush_rewrite_rules( false );
}

/**
 * Deactivation: drop our rewrite rules (WordPress rebuilds the rest).
 */
function dim_rr_deactivate() {
	delete_option( 'rewrite_rules' );
}

add_action(
	'plugins_loaded',
	function () {
		if ( get_option( 'dim_rr_roles_version' ) !== DIM_RR_ROLES_VERSION ) {
			dim_rr_setup_roles();
		}
	}
);

add_action( 'update_option_' . DIM_RR_Settings::OPTION, array( 'DIM_RR_Settings', 'flush_cache' ) );
add_action( 'add_option_' . DIM_RR_Settings::OPTION, array( 'DIM_RR_Settings', 'flush_cache' ) );

// WooCommerce: let review senders reach the send screen.
add_filter(
	'woocommerce_prevent_admin_access',
	function ( $prevent ) {
		return current_user_can( DIM_RR_CAP ) ? false : $prevent;
	}
);

add_action( 'plugins_loaded', array( 'DIM_RR_Log', 'maybe_upgrade' ) );
add_action( 'init', array( 'DIM_RR_Public', 'init' ) );
DIM_RR_Login::init();
DIM_RR_Updater::init();
add_action( 'rest_api_init', array( 'DIM_RR_Public', 'register_rest' ) );
add_action( 'wp_ajax_dim_rr_send', array( 'DIM_RR_Sender', 'ajax_send' ) );
add_action( 'wp_ajax_dim_rr_recent', array( 'DIM_RR_Sender', 'ajax_recent' ) );

if ( is_admin() ) {
	DIM_RR_Admin::init();
}

/**
 * Front-desk staff ("Review Request Sender" role) never see wp-admin when a
 * staff page is set: after login they land on it, wp-admin sends them back
 * to it, and the admin bar is hidden. AJAX and logout keep working.
 */
add_filter(
	'login_redirect',
	function ( $redirect_to, $requested, $user ) {
		if ( $user instanceof WP_User && DIM_RR_Settings::is_sender_only( $user ) ) {
			$page = DIM_RR_Settings::sender_page_url();
			return $page ? $page : admin_url( 'admin.php?page=dim-review-requests' );
		}
		return $redirect_to;
	},
	10,
	3
);

add_action(
	'admin_init',
	function () {
		if ( wp_doing_ajax() || ! DIM_RR_Settings::is_sender_only() ) {
			return;
		}
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( sanitize_text_field( wp_unslash( $_SERVER['SCRIPT_NAME'] ) ) ) : ''; // phpcs:ignore
		if ( in_array( $script, array( 'admin-ajax.php', 'admin-post.php', 'async-upload.php' ), true ) ) {
			return;
		}
		$page = DIM_RR_Settings::sender_page_url();
		if ( $page ) {
			wp_safe_redirect( $page );
			exit;
		}
	},
	1
);

add_filter(
	'show_admin_bar',
	function ( $show ) {
		return DIM_RR_Settings::is_sender_only() ? false : $show;
	}
);
